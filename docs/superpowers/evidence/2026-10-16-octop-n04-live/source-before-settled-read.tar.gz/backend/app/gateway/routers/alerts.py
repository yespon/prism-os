"""Alerting API routes — ingest, incident list/detail, source management."""

import logging
import os

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.alerting import diagnosis_authorization
from app.alerting.ai_analysis import DEFAULT_AUTO_SEVERITIES
from app.alerting.incident_manager import suppress_incident
from app.alerting.ingest import process_alert
from app.alerting.ticket_config import redact_ticket_config, restore_ticket_config, validate_ticket_ref_config
from app.gateway.authorization import require_tenant_admin, require_tenant_context
from app.models.alerting import AlertingSettings, AlertRule, AlertSource, ChangeEvent, Incident, IncidentSignalLink, RawAlert, Signal
from app.platform.execution.trust import attach_execution_capability
from deerflow.database.session import get_session, get_session_factory

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["alerting"])

# Global manager for ongoing background diagnostic tasks
class DiagnosisTaskManager:
    def __init__(self):
        self._tasks = {}         # incident_id -> asyncio.Task
        self._queues = {}        # incident_id -> Set[asyncio.Queue]
        self._stream_states = {} # incident_id -> StreamState
        self._thread_ids = {}    # incident_id -> str
        self._agent_names = {}   # incident_id -> str
        self._identities = {}    # active task -> (tenant, actor, native Agent ID)

    def get_thread_id(self, incident_id: str) -> str | None:
        return self._thread_ids.get(incident_id)

    def get_agent_name(self, incident_id: str) -> str | None:
        return self._agent_names.get(incident_id)

    def get_identity(self, incident_id: str):
        return self._identities.get(incident_id)

    def is_running(self, incident_id: str) -> bool:
        task = self._tasks.get(incident_id)
        return task is not None and not task.done()

    def get_stream_state(self, incident_id: str):
        return self._stream_states.get(incident_id)

    def register_queue(self, incident_id: str, queue):
        self._queues.setdefault(incident_id, set()).add(queue)

    def unregister_queue(self, incident_id: str, queue):
        if incident_id in self._queues:
            self._queues[incident_id].discard(queue)
            if not self._queues[incident_id]:
                del self._queues[incident_id]

    def broadcast(self, incident_id: str, message: str):
        if incident_id in self._queues:
            for q in self._queues[incident_id]:
                q.put_nowait(message)

    def start_task(self, incident_id: str, coro):
        import asyncio
        if incident_id in self._tasks:
            self._tasks[incident_id].cancel()
        
        task = asyncio.create_task(coro)
        self._tasks[incident_id] = task

        def _cleanup(t):
            if incident_id in self._tasks and self._tasks[incident_id] == t:
                del self._tasks[incident_id]
                self._identities.pop(incident_id, None)
        
        task.add_done_callback(_cleanup)

    def cancel_task(self, incident_id: str):
        if incident_id in self._tasks:
            self._tasks[incident_id].cancel()

diagnosis_task_manager = DiagnosisTaskManager()

# ---------------------------------------------------------------------------
# Ingest (unauthenticated — source-level token auth in provider)
# ---------------------------------------------------------------------------


class IngestResponse(BaseModel):
    """Response returned after successful alert ingestion."""

    ingest_id: str | None = None
    incident_key: str | None = None
    is_new_incident: bool = False
    disposition: str = "created"  # "created", "merged", "suppressed"


@router.post(
    "/alerts/ingest/{source_id}",
    response_model=IngestResponse,
    status_code=202,
    summary="Ingest alert (generic)",
    description="Receive an alert from a configured source. The provider "
    "is determined by the source's type field.",
)
async def ingest_alert(
    source_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> IngestResponse:
    """Ingest an alert payload from a configured source."""
    source = await session.get(AlertSource, source_id)
    if source is None:
        raise HTTPException(status_code=404, detail=f"Alert source '{source_id}' not found")
    if source.status != "active":
        raise HTTPException(status_code=403, detail="Alert source is disabled")

    body = await request.json()
    headers = {k.lower(): v for k, v in request.headers.items()}

    try:
        incident, is_new, disposition = await process_alert(session, source, body, headers)
    except PermissionError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return IngestResponse(
        ingest_id=incident.id if incident else None,
        incident_key=incident.incident_key if incident else None,
        is_new_incident=is_new,
        disposition=disposition,
    )


@router.post(
    "/alerts/ingest/webhook/{source_id}",
    response_model=IngestResponse,
    status_code=202,
    summary="Ingest webhook alert",
    description="Dedicated webhook ingest endpoint.  Alias for generic ingest.",
)
async def ingest_webhook(
    source_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> IngestResponse:
    return await ingest_alert(source_id, request, session)


# ---------------------------------------------------------------------------
# Incidents
# ---------------------------------------------------------------------------


class IncidentSummary(BaseModel):
    """Lightweight incident row for list views."""

    id: str
    incident_key: str
    title: str | None
    severity: str
    priority: str
    status: str
    service: str | None
    environment: str | None
    signal_count: int
    first_seen_at: str
    last_seen_at: str
    agent_id: str | None
    diagnosis_status: str | None = None
    owner_user_id: str | None = None


class IncidentListResponse(BaseModel):
    incidents: list[IncidentSummary]
    total: int


class IncidentStatsResponse(BaseModel):
    firing: int
    resolved: int
    suppressed: int
    total: int
    severity_distribution: dict[str, int]
    top_services: list[dict]
    recent_incidents: list[IncidentSummary]


@router.get(
    "/incidents/stats",
    response_model=IncidentStatsResponse,
    summary="Get incident statistics",
    description="Get aggregated incident stats, severity distribution, top services, and recent firing incidents for the tenant.",
)
async def get_incident_stats(
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> IncidentStatsResponse:
    tenant_id = require_tenant_context(request)

    # 1. Counts
    firing_res = await session.exec(
        select(func.count(Incident.id)).where(Incident.tenant_id == tenant_id, Incident.status == "firing")
    )
    firing = firing_res.scalar() or 0

    resolved_res = await session.exec(
        select(func.count(Incident.id)).where(Incident.tenant_id == tenant_id, Incident.status == "resolved")
    )
    resolved = resolved_res.scalar() or 0

    suppressed_res = await session.exec(
        select(func.count(Incident.id)).where(Incident.tenant_id == tenant_id, Incident.status == "suppressed")
    )
    suppressed = suppressed_res.scalar() or 0

    total_res = await session.exec(
        select(func.count(Incident.id)).where(Incident.tenant_id == tenant_id)
    )
    total = total_res.scalar() or 0

    # 2. Severity distribution
    severity_res = await session.exec(
        select(Incident.severity, func.count(Incident.id))
        .where(Incident.tenant_id == tenant_id)
        .group_by(Incident.severity)
    )
    severity_distribution = {row[0]: row[1] for row in severity_res.all()}

    # 3. Top services
    services_res = await session.exec(
        select(Incident.service, func.count(Incident.id))
        .where(Incident.tenant_id == tenant_id, Incident.service.is_not(None), Incident.service != "")
        .group_by(Incident.service)
        .order_by(func.count(Incident.id).desc())
        .limit(5)
    )
    top_services = [{"service": row[0], "count": row[1]} for row in services_res.all()]

    # 4. Recent firing incidents
    recent_res = await session.exec(
        select(Incident)
        .where(Incident.tenant_id == tenant_id, Incident.status == "firing")
        .order_by(Incident.last_seen_at.desc())
        .limit(5)
    )
    recent_rows = recent_res.scalars().all()

    return IncidentStatsResponse(
        firing=firing,
        resolved=resolved,
        suppressed=suppressed,
        total=total,
        severity_distribution=severity_distribution,
        top_services=top_services,
        recent_incidents=[
            IncidentSummary(
                id=r.id,
                incident_key=r.incident_key,
                title=r.title,
                severity=r.severity,
                priority=r.priority,
                status=r.status,
                service=r.service,
                environment=r.environment,
                signal_count=r.signal_count,
                first_seen_at=r.first_seen_at.isoformat() if r.first_seen_at else "",
                last_seen_at=r.last_seen_at.isoformat() if r.last_seen_at else "",
                agent_id=r.agent_id,
                diagnosis_status=r.diagnosis_status,
                owner_user_id=r.owner_user_id,
            )
            for r in recent_rows
        ]
    )


@router.get(
    "/incidents",
    response_model=IncidentListResponse,
    summary="List incidents",
    description="List incidents for the current tenant, newest first.",
)
async def list_incidents(
    request: Request,
    session: AsyncSession = Depends(get_session),
    status: str | None = None,
    severity: str | None = None,
    service: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> IncidentListResponse:
    tenant_id = require_tenant_context(request)

    conditions = [Incident.tenant_id == tenant_id]
    if status:
        conditions.append(Incident.status == status)
    if severity:
        conditions.append(Incident.severity == severity)
    if service:
        conditions.append(Incident.service == service)

    total_result = await session.exec(
        select(func.count()).select_from(Incident).where(*conditions)
    )
    total = total_result.scalar() or 0

    result = await session.exec(
        select(Incident)
        .where(*conditions)
        .order_by(Incident.last_seen_at.desc())
        .offset(offset)
        .limit(limit)
    )
    rows = result.scalars().all()

    return IncidentListResponse(
        incidents=[
            IncidentSummary(
                id=r.id,
                incident_key=r.incident_key,
                title=r.title,
                severity=r.severity,
                priority=r.priority,
                status=r.status,
                service=r.service,
                environment=r.environment,
                signal_count=r.signal_count,
                first_seen_at=r.first_seen_at.isoformat() if r.first_seen_at else "",
                last_seen_at=r.last_seen_at.isoformat() if r.last_seen_at else "",
                agent_id=r.agent_id,
                diagnosis_status=r.diagnosis_status,
                owner_user_id=r.owner_user_id,
            )
            for r in rows
        ],
        total=total,
    )


class IncidentDetail(BaseModel):
    """Full incident detail with signals, AI fields, and context."""

    id: str
    incident_key: str
    title: str | None
    summary: str | None
    severity: str
    priority: str
    status: str
    service: str | None
    environment: str | None
    owner_user_id: str | None = None
    owner_team_id: str | None = None
    signal_count: int
    first_seen_at: str
    last_seen_at: str
    resolved_at: str | None
    suppressed: bool
    ai_summary: str | None
    ai_impact: str | None
    ai_suggestion: str | None
    ai_analysis_enabled: bool = False
    agent_id: str | None
    thread_id: str | None
    diagnosis_agent_configured: bool = False
    diagnosis_status: str | None = None
    diagnosis_result: str | None = None
    diagnosis_error: str | None = None
    ticket_id: str | None = None
    ticket_url: str | None = None
    ticket_provider: str | None = None
    signals: list[dict]
    related_incidents: list[IncidentSummary] = []
    recent_changes: list[dict] = []
    created_at: str
    updated_at: str


@router.get(
    "/incidents/{incident_id}",
    response_model=IncidentDetail,
    summary="Get incident detail",
    description="Full incident detail including linked signals.",
)
async def get_incident(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> IncidentDetail:
    tenant_id = require_tenant_context(request)

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    links_result = await session.exec(
        select(IncidentSignalLink).where(
            IncidentSignalLink.incident_id == incident_id,
            IncidentSignalLink.tenant_id == tenant_id,
        )
    )
    link_rows = links_result.scalars().all()
    signal_ids = [link.signal_id for link in link_rows]

    signals: list[dict] = []
    if signal_ids:
        sig_result = await session.exec(
            select(Signal).where(Signal.id.in_(signal_ids))
        )
        for s in sig_result.scalars().all():
            raw_payload = None
            if s.raw_alert_id:
                raw_alert = await session.get(RawAlert, s.raw_alert_id)
                if raw_alert:
                    raw_payload = raw_alert.payload_json
            signals.append({
                "id": s.id,
                "source": s.source,
                "service": s.service,
                "severity": s.severity,
                "status": s.status,
                "title": s.title,
                "fingerprint": s.fingerprint,
                "occurred_at": s.occurred_at.isoformat() if s.occurred_at else None,
                "labels_json": s.labels_json,
                "raw_payload": raw_payload,
            })

    # Context: similar incidents (same service, last 7 days)
    from datetime import UTC, datetime, timedelta
    related: list[IncidentSummary] = []
    if incident.service:
        cutoff = datetime.now(UTC) - timedelta(days=7)
        related_result = await session.exec(
            select(Incident).where(
                Incident.tenant_id == tenant_id,
                Incident.service == incident.service,
                Incident.id != incident_id,
                Incident.created_at >= cutoff,
            ).order_by(Incident.created_at.desc()).limit(5)
        )
        related = [
            IncidentSummary(
                id=r.id, incident_key=r.incident_key, title=r.title,
                severity=r.severity, priority=r.priority, status=r.status,
                service=r.service, environment=r.environment,
                signal_count=r.signal_count,
                first_seen_at=r.first_seen_at.isoformat() if r.first_seen_at else "",
                last_seen_at=r.last_seen_at.isoformat() if r.last_seen_at else "",
                agent_id=r.agent_id,
                diagnosis_status=r.diagnosis_status,
                owner_user_id=r.owner_user_id,
            )
            for r in related_result.scalars().all()
        ]

    # Context: recent changes (same service, last 24h)
    changes_cutoff = datetime.now(UTC) - timedelta(hours=24)
    changes_result = await session.exec(
        select(ChangeEvent).where(
            ChangeEvent.tenant_id == tenant_id,
            ChangeEvent.service == incident.service,
            ChangeEvent.changed_at >= changes_cutoff,
        ).order_by(ChangeEvent.changed_at.desc()).limit(5)
    )
    recent_changes: list[dict] = []
    for c in changes_result.scalars().all():
        recent_changes.append({
            "id": c.id,
            "change_type": c.change_type,
            "summary": c.summary,
            "service": c.service,
            "environment": c.environment,
            "changed_by": c.changed_by,
            "changed_at": c.changed_at.isoformat() if c.changed_at else "",
        })

    # Determine AI analysis + diagnosis agent config from the incident's source(s).
    # Signal.source is the provider type (e.g. "webhook"), NOT the AlertSource name.
    # We trace through RawAlert.source_id → AlertSource.id to find the actual source.
    ai_analysis_enabled = False
    diagnosis_agent_configured = False
    if signal_ids:
        # Collect unique raw_alert_ids from linked signals
        sigs_with_raw = await session.exec(
            select(Signal.raw_alert_id).where(
                Signal.id.in_(signal_ids),
                Signal.raw_alert_id.isnot(None),
            )
        )
        raw_alert_ids = list({r for r in sigs_with_raw.scalars().all()})
        if raw_alert_ids:
            raw_alerts_result = await session.exec(
                select(RawAlert.source_id).where(
                    RawAlert.id.in_(raw_alert_ids),
                    RawAlert.source_id.isnot(None),
                )
            )
            source_ids = list({r for r in raw_alerts_result.scalars().all()})
            if source_ids:
                src_result = await session.exec(
                    select(AlertSource).where(
                        AlertSource.tenant_id == tenant_id,
                        AlertSource.id.in_(source_ids),
                    )
                )
                for src in src_result.scalars().all():
                    enabled, _, _, diag_id = _extract_ai_analysis_from_config(src.config_json)
                    if enabled:
                        ai_analysis_enabled = True
                    if diag_id:
                        diagnosis_agent_configured = True

    return IncidentDetail(
        id=incident.id,
        incident_key=incident.incident_key,
        title=incident.title,
        summary=incident.summary,
        severity=incident.severity,
        priority=incident.priority,
        status=incident.status,
        service=incident.service,
        environment=incident.environment,
        owner_user_id=incident.owner_user_id,
        owner_team_id=incident.owner_team_id,
        signal_count=incident.signal_count,
        first_seen_at=incident.first_seen_at.isoformat() if incident.first_seen_at else "",
        last_seen_at=incident.last_seen_at.isoformat() if incident.last_seen_at else "",
        resolved_at=incident.resolved_at.isoformat() if incident.resolved_at else None,
        suppressed=incident.suppressed,
        ai_summary=incident.ai_summary,
        ai_impact=incident.ai_impact,
        ai_suggestion=incident.ai_suggestion,
        ai_analysis_enabled=ai_analysis_enabled,
        agent_id=incident.agent_id,
        thread_id=incident.thread_id,
        diagnosis_agent_configured=diagnosis_agent_configured,
        diagnosis_status=incident.diagnosis_status,
        diagnosis_result=incident.diagnosis_result,
        diagnosis_error=incident.diagnosis_error,
        ticket_id=incident.ticket_id,
        ticket_url=incident.ticket_url,
        ticket_provider=incident.ticket_provider,
        signals=signals,
        related_incidents=related,
        recent_changes=recent_changes,
        created_at=incident.created_at.isoformat() if incident.created_at else "",
        updated_at=incident.updated_at.isoformat() if incident.updated_at else "",
    )


class TimelineEvent(BaseModel):
    type: str  # signal, ai_analysis, diagnosis, action, status_change
    timestamp: str
    title: str
    detail: str | None = None
    actor: str | None = None
    metadata: dict | None = None


async def _governed_ticket_status(incident_id: str, tenant_id: str, user_id: str | None = None) -> dict:
    """Read durable Decision, Approval and Submission facts for the current diagnosis."""
    from datetime import UTC, datetime

    from app.alerting.governed_ticket_tool import ticket_canary_enabled, ticket_request_id
    from app.platform.approval.repository import ApprovalRepository
    from app.platform.policy.repository import PolicyDecisionRepository
    from app.platform.submission.repository import ActionSubmissionRepository

    if not ticket_canary_enabled(tenant_id):
        return {"enabled": False, "status": None}
    async with get_session_factory()() as session:
        incident = (await session.exec(select(Incident).where(
            Incident.id == incident_id, Incident.tenant_id == tenant_id,
        ))).scalars().first()
    if incident is None:
        raise HTTPException(404, "Incident not found")
    if not incident.thread_id:
        return {"enabled": True, "status": None}
    decision = await PolicyDecisionRepository().get_by_request(
        tenant_id, ticket_request_id(incident.thread_id, incident_id),
    )
    if decision is None or decision.action != "ticket.create" or decision.resource_id != incident_id:
        return {"enabled": True, "status": None}
    found = await ApprovalRepository().get_by_decision(tenant_id, decision.decision_id)
    approval = found[0] if found else None
    submission = await ActionSubmissionRepository().get(tenant_id, decision.decision_id)
    if submission:
        status = "submitted" if submission.status == "submitted" else "unknown"
    elif decision.verdict == "deny":
        status = "denied"
    elif approval:
        expired = approval.expires_at <= datetime.now(UTC) or decision.expires_at <= datetime.now(UTC)
        status = "expired" if expired and approval.status in ("pending", "approved") else (
            "awaiting_approval" if approval.status == "pending" else
            "unknown" if approval.status == "consumed" else approval.status
        )
    else:
        status = "unknown"
    return {
        "enabled": True, "status": status, "decision_id": decision.decision_id,
        "approval_id": approval.approval_id if approval else None,
        "tenant_id": decision.tenant_id, "actor_id": decision.execution.actor.id if decision.execution.actor else None,
        "workload_id": decision.execution.workload.id, "run_id": decision.execution.run_id,
        "policy_id": decision.policy_id, "policy_version": decision.policy_version,
        "reason_code": decision.reason_code, "ticket_id": submission.ticket_id if submission else None,
        "can_resume": (approval is not None and approval.status == "approved" and submission is None
                       and decision.expires_at > datetime.now(UTC) and decision.execution.actor is not None
                       and decision.execution.actor.id == user_id),
    }


@router.get("/incidents/{incident_id}/governed-ticket")
async def get_governed_incident_ticket(incident_id: str, request: Request) -> dict:
    tenant_id = require_tenant_context(request)
    return await _governed_ticket_status(incident_id, tenant_id, getattr(request.state, "user_id", None))


@router.post("/incidents/{incident_id}/governed-ticket/resume")
async def resume_governed_incident_ticket(incident_id: str, request: Request) -> dict:
    from app.alerting.governed_ticket_tool import execute_ticket_scope

    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not isinstance(user_id, str) or not user_id:
        raise HTTPException(401, "Authentication required")
    status = await _governed_ticket_status(incident_id, tenant_id, user_id)
    if not status.get("enabled") or not status.get("decision_id"):
        raise HTTPException(404, "Governed Action unavailable")
    if status["actor_id"] != user_id:
        raise HTTPException(403, "Only the requesting user can resume this Action")
    if status["status"] not in ("approved", "rejected", "expired", "submitted", "unknown"):
        raise HTTPException(409, "Approval has not been decided")
    async with get_session_factory()() as session:
        incident = (await session.exec(select(Incident).where(
            Incident.id == incident_id, Incident.tenant_id == tenant_id,
        ))).scalars().first()
    if incident is None or not incident.thread_id or not status["workload_id"].startswith("diagnosis-agent:"):
        raise HTTPException(409, "Diagnosis context changed")
    from app.alerting.governed_ticket_tool import ticket_request_id
    from app.platform.policy.repository import PolicyDecisionRepository

    decision = await PolicyDecisionRepository(get_session_factory()).get_by_request(
        tenant_id, ticket_request_id(incident.thread_id, incident_id),
    )
    if decision is None or decision.decision_id != status["decision_id"]:
        raise HTTPException(409, "Diagnosis decision changed")
    attributes = decision.execution.attributes
    if attributes.get("agent_id") is not None and incident.agent_id != attributes["agent_id"]:
        raise HTTPException(409, "Diagnosis Agent changed")
    scope = {"tenant_id": tenant_id, "user_id": user_id, "thread_id": incident.thread_id,
             "incident_id": incident_id, "agent_name": status["workload_id"].removeprefix("diagnosis-agent:")}
    # Only immutable server-side decision facts may restore protected context.
    # Client fields and the current replacement Agent cannot rewrite an old Action.
    scope.update({key: attributes[key] for key in (
        "agent_id", "diagnosis_source_id", "diagnosis_source_revision", "diagnosis_incident_id",
    ) if attributes.get(key) is not None})
    try:
        await execute_ticket_scope(scope)
    except PermissionError as exc:
        raise HTTPException(403, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    return await _governed_ticket_status(incident_id, tenant_id, user_id)


@router.get(
    "/incidents/{incident_id}/timeline",
    response_model=list[TimelineEvent],
    summary="Get incident timeline",
    description="Get a unified timeline of signals, AI analysis, diagnosis, and user actions for an incident.",
)
async def get_incident_timeline(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> list[TimelineEvent]:
    tenant_id = require_tenant_context(request)

    # Verify incident exists and belongs to tenant
    inc_result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = inc_result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    events: list[TimelineEvent] = []

    # 1. Signal events
    links_result = await session.exec(
        select(IncidentSignalLink).where(
            IncidentSignalLink.incident_id == incident_id,
            IncidentSignalLink.tenant_id == tenant_id,
        )
    )
    signal_ids = [link.signal_id for link in links_result.scalars().all()]
    if signal_ids:
        sig_result = await session.exec(
            select(Signal).where(Signal.id.in_(signal_ids)).order_by(Signal.occurred_at.asc())
        )
        for s in sig_result.scalars().all():
            status_label = "告警触发" if s.status == "firing" else "告警恢复"

            # Fetch raw_payload from linked RawAlert if available
            raw_payload = None
            if s.raw_alert_id:
                raw_alert = await session.get(RawAlert, s.raw_alert_id)
                if raw_alert:
                    raw_payload = raw_alert.payload_json

            events.append(TimelineEvent(
                type="signal",
                timestamp=s.occurred_at.isoformat() if s.occurred_at else s.created_at.isoformat(),
                title=f"{status_label}: {s.title or 'Untitled Signal'}",
                detail=s.summary,
                actor="system",
                metadata={
                    "signal_id": s.id,
                    "severity": s.severity,
                    "source": s.source,
                    "service": s.service,
                    "status": s.status,
                    "labels_json": s.labels_json,
                    "raw_payload": raw_payload,
                },
            ))

    # 2. AI analysis events
    if incident.ai_summary:
        events.append(TimelineEvent(
            type="ai_analysis",
            timestamp=incident.updated_at.isoformat(),
            title="AI 智能解读完成",
            detail=incident.ai_summary[:200] if incident.ai_summary else None,
            actor="system",
            metadata={"ai_impact": incident.ai_impact, "ai_suggestion": incident.ai_suggestion},
        ))

    # 3. Diagnosis events
    if incident.diagnosis_status:
        status_labels = {
            "running": "Agent 诊断进行中",
            "completed": "Agent 诊断已完成",
            "failed": "Agent 诊断失败",
            "cancelled": "Agent 诊断已取消",
            "partial": "Agent 部分诊断完成",
        }
        events.append(TimelineEvent(
            type="diagnosis",
            timestamp=incident.updated_at.isoformat(),
            title=status_labels.get(incident.diagnosis_status, f"Agent 诊断: {incident.diagnosis_status}"),
            detail=incident.diagnosis_result[:300] if incident.diagnosis_result else incident.diagnosis_error,
            actor=incident.agent_id or "system",
            metadata={
                "diagnosis_status": incident.diagnosis_status,
                "agent_id": incident.agent_id,
                "thread_id": incident.thread_id,
            },
        ))

    # 4. User actions (from incident_actions table)
    from app.models.alerting import IncidentAction
    actions_result = await session.exec(
        select(IncidentAction).where(
            IncidentAction.incident_id == incident_id,
            IncidentAction.tenant_id == tenant_id,
        ).order_by(IncidentAction.created_at.asc())
    )
    action_labels = {
        "suppressed": "标记为误报 (Suppressed)",
        "unsuppressed": "撤销误报标记",
        "claimed": "认领告警",
        "assigned": "指派告警",
        "manual_resolved": "手动标记已恢复",
        "ticket_created": "创建外部工单",
    }
    for a in actions_result.scalars().all():
        label = action_labels.get(a.action_type, a.action_type)
        detail = None
        if a.action_type == "assigned":
            detail = f"指派给 {a.action_payload.get('owner_user_id', 'unknown')}"
        elif a.action_type == "ticket_created":
            detail = f"工单: {a.action_payload.get('ticket_id', 'unknown')}"
        elif a.action_type == "manual_resolved":
            note = a.action_payload.get("resolution_note")
            detail = f"恢复备注: {note}" if note else None
        events.append(TimelineEvent(
            type="action",
            timestamp=a.created_at.isoformat(),
            title=label,
            detail=detail,
            actor=a.actor_id,
            metadata={"action_type": a.action_type, "action_payload": a.action_payload},
        ))

    # 5. Status change event (when incident was resolved automatically or via manual action)
    if incident.resolved_at and incident.status == "resolved":
        events.append(TimelineEvent(
            type="status_change",
            timestamp=incident.resolved_at.isoformat(),
            title="告警已恢复",
            detail="Incident 状态变更为 resolved",
            actor="system",
            metadata={"previous_status": "firing", "new_status": "resolved"},
        ))

    # Sort all events by timestamp
    events.sort(key=lambda e: e.timestamp)

    return events


@router.post(
    "/incidents/{incident_id}/suppress",
    status_code=200,
    summary="Suppress incident",
    description="Mark an incident as suppressed (noise).",
)
async def suppress_incident_endpoint(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    await suppress_incident(session, incident, user_id or "unknown")
    await session.commit()

    return {"status": "suppressed", "incident_id": incident_id}


@router.post(
    "/incidents/{incident_id}/unsuppress",
    status_code=200,
    summary="Unsuppress incident",
    description="Revert the suppression of an incident (mark back as active/firing).",
)
async def unsuppress_incident_endpoint(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    incident.status = "firing"
    incident.suppressed = False
    session.add(incident)

    import uuid

    from app.models.alerting import IncidentAction
    action = IncidentAction(
        id=str(uuid.uuid4()),
        tenant_id=incident.tenant_id,
        incident_id=incident.id,
        actor_id=user_id or "unknown",
        action_type="unsuppressed",
        action_payload={},
    )
    session.add(action)
    await session.commit()

    return {"status": "firing", "incident_id": incident_id}


@router.post(
    "/incidents/{incident_id}/claim",
    status_code=200,
    summary="Claim incident",
    description="Claim ownership of an incident (set owner to current user).",
)
async def claim_incident(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    if incident.status not in ("firing", "suppressed"):
        raise HTTPException(status_code=400, detail=f"Cannot claim incident with status '{incident.status}'")

    incident.owner_user_id = user_id
    session.add(incident)

    import uuid

    from app.models.alerting import IncidentAction
    action = IncidentAction(
        id=str(uuid.uuid4()),
        tenant_id=incident.tenant_id,
        incident_id=incident.id,
        actor_id=user_id,
        action_type="claimed",
        action_payload={"owner_user_id": user_id},
    )
    session.add(action)
    await session.commit()

    return {"status": "claimed", "incident_id": incident_id, "owner_user_id": user_id}


class AssignIncidentBody(BaseModel):
    owner_user_id: str


@router.post(
    "/incidents/{incident_id}/assign",
    status_code=200,
    summary="Assign incident",
    description="Assign an incident to a specific user.",
)
async def assign_incident(
    incident_id: str,
    body: AssignIncidentBody,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    incident.owner_user_id = body.owner_user_id
    session.add(incident)

    import uuid

    from app.models.alerting import IncidentAction
    action = IncidentAction(
        id=str(uuid.uuid4()),
        tenant_id=incident.tenant_id,
        incident_id=incident.id,
        actor_id=user_id,
        action_type="assigned",
        action_payload={"owner_user_id": body.owner_user_id, "assigned_by": user_id},
    )
    session.add(action)
    await session.commit()

    return {"status": "assigned", "incident_id": incident_id, "owner_user_id": body.owner_user_id}


class ResolveIncidentBody(BaseModel):
    resolution_note: str | None = None


@router.post(
    "/incidents/{incident_id}/resolve",
    status_code=200,
    summary="Resolve incident",
    description="Manually mark an incident as resolved.",
)
async def resolve_incident_endpoint(
    incident_id: str,
    body: ResolveIncidentBody | None = None,
    request: Request = None,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    if incident.status == "resolved":
        raise HTTPException(status_code=400, detail="Incident is already resolved")

    from datetime import UTC
    from datetime import datetime as dt

    incident.status = "resolved"
    incident.resolved_at = dt.now(UTC)
    session.add(incident)

    note = body.resolution_note if body else None

    import uuid

    from app.models.alerting import IncidentAction
    action = IncidentAction(
        id=str(uuid.uuid4()),
        tenant_id=incident.tenant_id,
        incident_id=incident.id,
        actor_id=user_id,
        action_type="manual_resolved",
        action_payload={"resolution_note": note} if note else {},
    )
    session.add(action)
    await session.commit()

    # Trigger IM notification for resolution if configured
    try:
        from datetime import UTC
        from datetime import datetime as dt

        from app.alerting.notify import send_incident_resolved
        now = dt.now(UTC)
        first_seen = incident.first_seen_at.replace(tzinfo=UTC) if incident.first_seen_at and incident.first_seen_at.tzinfo is None else incident.first_seen_at
        if first_seen:
            duration_minutes = int((now - first_seen).total_seconds() / 60)
        else:
            duration_minutes = 0
        await send_incident_resolved(incident, duration_minutes)
    except Exception:
        logger.exception("Failed to send resolved notification for incident=%s", incident_id)

    return {"status": "resolved", "incident_id": incident_id}


class CreateTicketBody(BaseModel):
    provider: str = "webhook"


@router.post(
    "/incidents/{incident_id}/ticket",
    status_code=200,
    summary="Create external ticket",
    description="Create an external ticket for this incident via configured webhook or provider.",
)
async def create_incident_ticket(
    incident_id: str,
    body: CreateTicketBody | None = None,
    request: Request = None,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    if incident.ticket_id:
        raise HTTPException(status_code=400, detail="Ticket already exists for this incident")

    from app.alerting.governed_ticket import resolve_ticket_target
    from app.alerting.ticket_provider import create_ticket as do_create_ticket

    try:
        target = await resolve_ticket_target(tenant_id, incident_id, session=session)
        ticket_result = await do_create_ticket(incident, target.config, target.signals, source_id=target.source_id)
    except (ValueError, PermissionError):
        raise HTTPException(status_code=400, detail="Ticket configuration or credentials unavailable") from None
    except RuntimeError:
        raise HTTPException(status_code=502, detail="Ticket creation failed") from None

    incident.ticket_id = ticket_result.ticket_id
    incident.ticket_url = ticket_result.ticket_url
    incident.ticket_provider = ticket_result.provider
    session.add(incident)

    import uuid

    from app.models.alerting import IncidentAction
    action = IncidentAction(
        id=str(uuid.uuid4()),
        tenant_id=incident.tenant_id,
        incident_id=incident.id,
        actor_id=user_id,
        action_type="ticket_created",
        action_payload={
            "ticket_id": ticket_result.ticket_id,
            "ticket_url": ticket_result.ticket_url,
            "provider": ticket_result.provider,
        },
    )
    session.add(action)
    await session.commit()

    return {
        "ticket_id": ticket_result.ticket_id,
        "ticket_url": ticket_result.ticket_url,
        "provider": ticket_result.provider,
        "incident_id": incident_id,
    }


@router.post(
    "/incidents/{incident_id}/analyze",
    status_code=202,
    summary="Trigger AI analysis",
    description="Manually trigger AI analysis for an incident. The analysis runs asynchronously.",
)
async def analyze_incident(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> dict:
    tenant_id = require_tenant_context(request)

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    # Check if AI analysis is enabled for this incident's source(s).
    # Signal.source is the provider type — trace through RawAlert.source_id instead.
    links_chk = await session.exec(
        select(IncidentSignalLink).where(
            IncidentSignalLink.incident_id == incident_id,
            IncidentSignalLink.tenant_id == tenant_id,
        )
    )
    chk_signal_ids = [link.signal_id for link in links_chk.scalars().all()]
    ai_enabled_for_incident = False
    if chk_signal_ids:
        raw_ids_result = await session.exec(
            select(Signal.raw_alert_id).where(
                Signal.id.in_(chk_signal_ids),
                Signal.raw_alert_id.isnot(None),
            )
        )
        raw_alert_ids = list({r for r in raw_ids_result.scalars().all()})
        if raw_alert_ids:
            src_ids_result = await session.exec(
                select(RawAlert.source_id).where(
                    RawAlert.id.in_(raw_alert_ids),
                    RawAlert.source_id.isnot(None),
                )
            )
            source_ids = list({r for r in src_ids_result.scalars().all()})
            if source_ids:
                src_chk = await session.exec(
                    select(AlertSource).where(
                        AlertSource.tenant_id == tenant_id,
                        AlertSource.id.in_(source_ids),
                    )
                )
                for s in src_chk.scalars().all():
                    if _extract_ai_analysis_from_config(s.config_json)[0]:
                        ai_enabled_for_incident = True
                        break

    if not ai_enabled_for_incident:
        raise HTTPException(status_code=400, detail="AI analysis is not enabled for this incident's alert source")

    # Clear old AI analysis fields synchronously so that the frontend polling detects the new analysis run
    incident.ai_summary = None
    incident.ai_impact = None
    incident.ai_suggestion = None
    session.add(incident)

    # Collect signal data
    links_result = await session.exec(
        select(IncidentSignalLink).where(
            IncidentSignalLink.incident_id == incident_id,
            IncidentSignalLink.tenant_id == tenant_id,
        )
    )
    signal_ids = [link.signal_id for link in links_result.scalars().all()]

    signals_data: list[dict] = []
    raw_payload = None
    if signal_ids:
        sig_result = await session.exec(select(Signal).where(Signal.id.in_(signal_ids)))
        for s in sig_result.scalars().all():
            signals_data.append({
                "title": s.title,
                "severity": s.severity,
                "source": s.source,
                "fingerprint": s.fingerprint,
                "labels_json": s.labels_json,
            })
        # Get first raw payload for context (via signal's raw_alert_id)
        first_signal = await session.get(Signal, signal_ids[0])
        if first_signal and first_signal.raw_alert_id:
            raw_alert = await session.get(RawAlert, first_signal.raw_alert_id)
            if raw_alert:
                raw_payload = raw_alert.payload_json

    await session.commit()

    from app.alerting.ai_analysis import schedule_analysis
    from deerflow.config import get_app_config

    if not get_app_config().models:
        raise HTTPException(status_code=503, detail="No AI models configured — please add a model in tenant admin settings first")

    # Determine model override from the incident's alert source config
    # Trace through raw_alert_id → source_id (signal.source is provider type, not name)
    model_name: str | None = None
    if signal_ids:
        first_signal = await session.get(Signal, signal_ids[0])
        if first_signal and first_signal.raw_alert_id:
            raw_alert = await session.get(RawAlert, first_signal.raw_alert_id)
            if raw_alert and raw_alert.source_id:
                src = await session.get(AlertSource, raw_alert.source_id)
                if src:
                    trigger = (src.config_json or {}).get("analysis_trigger", {})
                    model_name = trigger.get("model") or None

    schedule_analysis(incident, signals_data, raw_payload, model_name)

    return {"status": "analyzing", "incident_id": incident_id}


async def _cancel_incident_diagnosis_run(client, thread_id: str, incident_id: str) -> None:
    """Cancel the active LangGraph run for a diagnosis thread, then update the incident."""
    try:
        # Find and cancel active runs for this thread
        runs = await client.runs.list(thread_id, limit=5, status="running")
        if not runs:
            runs = await client.runs.list(thread_id, limit=5, status="pending")
        for run in runs:
            run_id = run.get("run_id") if isinstance(run, dict) else getattr(run, "run_id", None)
            if run_id:
                await client.runs.cancel(thread_id, run_id, action="interrupt")
                logger.info("diagnose: cancelled run %s for incident=%s", run_id, incident_id)
    except Exception as exc:
        logger.error("diagnose: failed to cancel runs for incident=%s: %s", incident_id, exc)
async def _run_diagnosis_background_task(
    incident_id: str,
    agent_id: str,
    agent_name: str,
    diagnosis_prompt: str,
    user_id: str,
    tenant_id: str,
    task_manager: DiagnosisTaskManager,
    session_factory=None
):
    import asyncio
    import logging
    import os

    from app.alerting.diagnosis_sse import (
        msg_done,
        msg_error,
        msg_thread,
        parse_messages_tuple_event,
        parse_values_event,
    )
    from app.gateway.routers.alerts import _cancel_incident_diagnosis_run, logger
    from app.models.alerting import Incident
    
    agui_logger = logging.getLogger("agui")
    db_factory = session_factory or get_session_factory()
    
    def log_agui_event(event_type: str, data: dict | None = None):
        import json as _json
        payload = {"event": event_type, "incident_id": incident_id}
        if data:
            payload.update(data)
        agui_logger.info(_json.dumps(payload, ensure_ascii=False))

    thread_id = None
    client = None
    stream_state = task_manager.get_stream_state(incident_id)
    if stream_state is None:
        return

    try:
        from langgraph_sdk import get_client
        langgraph_url = os.getenv("LANGGRAPH_API_URL", "http://localhost:2025")
        client = get_client(url=langgraph_url)

        from app.alerting.diagnosis_helper import build_incident_diagnosis_prompt
        from app.integrations.agent_skill_references import current_skill_prompt
        from app.models.agents import CustomAgent
        from app.platform.execution.trust import ThreadBindingRepository
        from app.runtime_adapters import verify_native_selection

        async with db_factory() as read_session:
            current = await read_session.get(CustomAgent, agent_id)
            if current is None:
                raise ValueError("Current diagnosis Agent unavailable")
            agent_name = current.name
            await verify_native_selection(read_session, tenant_id, user_id, agent_name, agent_id, diagnosis_incident_id=incident_id)
            inc = await read_session.get(Incident, incident_id)
            old_thread_id = inc.thread_id

        # Only cancel a previous thread with proven current actor ownership.
        if old_thread_id:
            owned = await ThreadBindingRepository(db_factory).lookup(old_thread_id)
            allowed = owned is not None and owned.tenant_id == tenant_id and owned.user_id == user_id
            if owned is None:
                try:
                    previous = await client.threads.get(old_thread_id)
                    metadata = previous.get("metadata", {}) if isinstance(previous, dict) else {}
                    allowed = metadata.get("owner_tenant_id") == tenant_id and metadata.get("owner_user_id") == user_id
                except Exception:
                    allowed = False
            if allowed:
                await _cancel_incident_diagnosis_run(client, old_thread_id, incident_id)

        thread = await client.threads.create(metadata={
            "owner_user_id": user_id,
            "owner_tenant_id": tenant_id,
            "incident_id": incident_id,
        })
        thread_id = thread["thread_id"]

        # Establish original thread ownership before exposing any thread pointer.
        async with db_factory() as selection_session:
            current = await selection_session.get(CustomAgent, agent_id)
            if current is None:
                raise ValueError("Current diagnosis Agent unavailable")
            agent_name = current.name
            await verify_native_selection(selection_session, tenant_id, user_id, agent_name, agent_id, diagnosis_incident_id=incident_id)
        repository = ThreadBindingRepository(db_factory)
        await repository.create(thread_id, tenant_id, user_id)
        await repository.bind_agent(thread_id, tenant_id, user_id, agent_name)

        # Recheck current selection and resources after the network/DB waits.
        async with db_factory() as write_session:
            current = await write_session.get(CustomAgent, agent_id)
            if current is None:
                raise ValueError("Current diagnosis Agent unavailable")
            await verify_native_selection(write_session, tenant_id, user_id, agent_name, agent_id, diagnosis_incident_id=incident_id)
            await current_skill_prompt(write_session, agent_name, tenant_id, user_id, selected_agent_id=agent_id)
            fresh = await write_session.get(Incident, incident_id)
            diagnosis_prompt = await build_incident_diagnosis_prompt(write_session, fresh, tenant_id, include_agent_configuration=False)
            fresh.agent_id = agent_id
            fresh.thread_id = thread_id
            fresh.diagnosis_status = "running"
            write_session.add(fresh)
            await write_session.commit()
        task_manager._thread_ids[incident_id] = thread_id
        task_manager._agent_names[incident_id] = agent_name

        # Broadcast thread_id start event
        task_manager.broadcast(incident_id, msg_thread(thread_id, agent_name))
        log_agui_event("RUN_STARTED", {"thread_id": thread_id, "agent_name": agent_name})

        # Stream agent response
        async for chunk in client.runs.stream(
            thread_id,
            "lead_agent",
            input={"messages": [{"role": "human", "content": diagnosis_prompt}]},
            config={
                "recursion_limit": 500,
            },
            context=await attach_execution_capability({
                "agent_name": agent_name,
                "agent_id": agent_id,
                "diagnosis_incident_id": incident_id,
                "user_id": user_id,
                "tenant_id": tenant_id,
                "thread_id": thread_id,
            }, action_incident_id=incident_id, native_selection_validator=verify_native_selection, session_factory=db_factory),
            stream_mode=["messages-tuple", "values"],
        ):
            event = getattr(chunk, "event", "")
            data = getattr(chunk, "data", None)

            if event == "metadata":
                continue

            if event == "error":
                err_msg = str(data) if isinstance(data, str) else str(data.get("message", "Unknown error"))
                
                async with db_factory() as write_session:
                    fresh = await write_session.get(Incident, incident_id)
                    if fresh and fresh.tenant_id == tenant_id:
                        fresh.diagnosis_status = "failed"
                        fresh.diagnosis_error = err_msg
                        if stream_state.full_text_buffer:
                            fresh.diagnosis_result = stream_state.full_text_buffer
                        write_session.add(fresh)
                        await write_session.commit()

                task_manager.broadcast(incident_id, msg_error(err_msg))
                log_agui_event("RUN_ERROR", {"message": err_msg})
                return

            if event in ("messages", "messages-tuple"):
                sse_messages = parse_messages_tuple_event(data, stream_state)
                for sse_msg in sse_messages:
                    task_manager.broadcast(incident_id, sse_msg)

            elif event == "values":
                sse_messages = parse_values_event(data, stream_state)
                for sse_msg in sse_messages:
                    task_manager.broadcast(incident_id, sse_msg)

        # Finished successfully
        async with db_factory() as write_session:
            fresh = await write_session.get(Incident, incident_id)
            if fresh and fresh.tenant_id == tenant_id and fresh.diagnosis_status != "cancelled":
                fresh.diagnosis_status = "completed"
                fresh.diagnosis_result = stream_state.full_text_buffer or None
                fresh.diagnosis_error = None
                write_session.add(fresh)
                await write_session.commit()

        task_manager.broadcast(incident_id, msg_done(thread_id, stream_state.full_text_buffer))
        log_agui_event("RUN_FINISHED", {"thread_id": thread_id, "text_length": len(stream_state.full_text_buffer)})

    except asyncio.CancelledError:
        logger.info("diagnose: background task cancelled for incident=%s", incident_id)
        log_agui_event("RUN_CANCELLED", {"reason": "task_cancelled"})
        # Update status to cancelled in DB
        async with db_factory() as write_session:
            fresh = await write_session.get(Incident, incident_id)
            if fresh and fresh.tenant_id == tenant_id and fresh.diagnosis_status == "running":
                fresh.diagnosis_status = "cancelled"
                fresh.diagnosis_error = "诊断任务被手动终止"
                write_session.add(fresh)
                await write_session.commit()

    except Exception as e:
        from langgraph.errors import GraphRecursionError
        
        if isinstance(e, GraphRecursionError):
            err_msg = "诊断步骤过多，已自动终止。请尝试缩小排查范围后重新诊断。"
        else:
            err_msg = str(e)

        logger.error("diagnose: background task failed for incident=%s: %s", incident_id, e, exc_info=True)
        log_agui_event("RUN_ERROR", {"message": err_msg})
        
        try:
            async with db_factory() as write_session:
                fresh = await write_session.get(Incident, incident_id)
                if fresh and fresh.tenant_id == tenant_id:
                    fresh.diagnosis_status = "failed"
                    fresh.diagnosis_error = err_msg[:5000]
                    if stream_state.full_text_buffer:
                        fresh.diagnosis_result = stream_state.full_text_buffer
                    write_session.add(fresh)
                    await write_session.commit()
        except Exception as se:
            logger.error("diagnose: background task failed to update failure status in DB: %s", se)

        task_manager.broadcast(incident_id, msg_error(err_msg))

@router.post(
    "/incidents/{incident_id}/diagnose",
    status_code=202,
    summary="Stream agent diagnosis",
    description="Stream a depth diagnosis with the incident's bound custom agent via SSE.",
)
async def diagnose_incident(
    incident_id: str,
    request: Request,
    agent_id: str | None = Query(default=None),
    session: AsyncSession = Depends(get_session),
):
    from starlette.responses import StreamingResponse

    from app.alerting.diagnosis_helper import build_incident_diagnosis_prompt, get_diagnosis_agent_id_for_incident
    from app.models.agents import CustomAgent

    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    # Load incident
    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    # Determine agent_id to use
    if not agent_id:
        agent_id = await get_diagnosis_agent_id_for_incident(session, incident_id, tenant_id)
        if not agent_id:
            raise HTTPException(status_code=400, detail="No diagnosis agent configured for this incident's alert source")

    # Load the agent and verify permissions (must be owned by current user OR tenant-shared)
    agent_result = await session.exec(
        select(CustomAgent).where(
            CustomAgent.id == agent_id,
            CustomAgent.tenant_id == tenant_id,
            CustomAgent.enabled.is_(True),
            (CustomAgent.user_id == user_id) | (CustomAgent.user_id == "tenant-shared")
        )
    )
    agent = agent_result.scalars().first()
    if agent is None:
        raise HTTPException(status_code=400, detail=f"Diagnosis agent not found or permission denied: {agent_id}")

    agent_name = agent.name

    from app.integrations.agent_skill_references import current_skill_prompt
    from app.runtime_adapters import verify_native_selection
    from deerflow.runtime import ExecutionTrustError

    try:
        await verify_native_selection(session, tenant_id, user_id, agent_name, agent_id, diagnosis_incident_id=incident_id)
    except ExecutionTrustError:
        raise HTTPException(403, "Current diagnosis selection or membership unavailable") from None
    await current_skill_prompt(session, agent_name, tenant_id, user_id, selected_agent_id=agent_id)
    identity = (tenant_id, user_id, agent_id)
    if diagnosis_task_manager.is_running(incident_id) and diagnosis_task_manager.get_identity(incident_id) != identity:
        raise HTTPException(409, "A different diagnosis is already running for this incident")
    diagnosis_prompt = await build_incident_diagnosis_prompt(session, incident, tenant_id, include_agent_configuration=False)

    # Check if a diagnosis is already running. If not, start it.
    if not diagnosis_task_manager.is_running(incident_id):
        from app.alerting.diagnosis_sse import StreamState
        diagnosis_task_manager._stream_states[incident_id] = StreamState()
        diagnosis_task_manager._thread_ids.pop(incident_id, None)
        diagnosis_task_manager._identities[incident_id] = identity
        diagnosis_task_manager._agent_names[incident_id] = agent_name
        
        diagnosis_task_manager.start_task(
            incident_id,
            _run_diagnosis_background_task(
                incident_id=incident_id,
                agent_id=agent_id,
                agent_name=agent_name,
                diagnosis_prompt=diagnosis_prompt,
                user_id=user_id,
                tenant_id=tenant_id,
                task_manager=diagnosis_task_manager,
                session_factory=get_session_factory()
            )
        )

    async def event_stream():
        import asyncio

        from app.alerting.diagnosis_delivery import verify_delivery
        from app.alerting.diagnosis_sse import _step_finished, _step_started, _text_message_content, msg_done, msg_thread

        # Capture current length of text buffer
        stream_state = diagnosis_task_manager.get_stream_state(incident_id)
        initial_length = len(stream_state.full_text_buffer) if stream_state else 0
        sent_chars = initial_length
        yielded_run_started = False

        # Register queue BEFORE yielding catchup elements so we don't miss live events
        queue = asyncio.Queue()
        diagnosis_task_manager.register_queue(incident_id, queue)

        async def verify_current_delivery():
            return await verify_delivery(get_session_factory(), tenant_id, user_id, agent_name, agent_id, incident_id,
                diagnosis_task_manager.get_thread_id(incident_id),
                new_thread_pending=diagnosis_task_manager.is_running(incident_id) and not diagnosis_task_manager.get_thread_id(incident_id))

        try:
            thread_id = await verify_current_delivery()
            if thread_id:
                await verify_current_delivery()
                yield msg_thread(thread_id, diagnosis_task_manager.get_agent_name(incident_id) or agent_name)
                yielded_run_started = True

            # Replay historical steps from LangGraph checkpoint values (todos)
            if thread_id:
                try:
                    from langgraph_sdk import get_client
                    langgraph_url = os.getenv("LANGGRAPH_API_URL", "http://localhost:2025")
                    client = get_client(url=langgraph_url)
                    state = await client.threads.get_state(thread_id)
                    values = state.get("values", {}) if isinstance(state, dict) else getattr(state, "values", {})
                    todos = values.get("todos") or values.get("scratchpad") or []
                    for todo in todos:
                        if isinstance(todo, dict):
                            step_name = todo.get("name") or todo.get("title") or todo.get("content") or str(todo)
                            step_status = str(todo.get("status", "")).lower()
                            await verify_current_delivery()
                            yield _step_started(step_name)
                            if step_status in ("done", "completed", "finished", "success"):
                                await verify_current_delivery()
                                yield _step_finished(step_name)
                except ExecutionTrustError:
                    raise
                except Exception as ex:
                    logger.warning("diagnose reconnect: could not fetch thread state: %s", ex)

            # Replay accumulated text buffer so far
            if stream_state and stream_state.full_text_buffer:
                await verify_current_delivery()
                yield _text_message_content("catchup-msg-id", stream_state.full_text_buffer)

            # If task is not running anymore, yield final done and finish
            if not diagnosis_task_manager.is_running(incident_id):
                if stream_state and stream_state.full_text_buffer:
                    await verify_current_delivery()
                    yield msg_done(thread_id, stream_state.full_text_buffer)
                elif incident.diagnosis_status in ("completed", "failed", "cancelled"):
                    await verify_current_delivery()
                    yield msg_done(thread_id, incident.diagnosis_result or "")
                return

            # Live loop
            while True:
                msg = await queue.get()
                if "RUN_STARTED" in msg:
                    if yielded_run_started:
                        continue
                    else:
                        yielded_run_started = True
                
                # Deduplicate and stream live text content incrementally
                if "TEXT_MESSAGE_CONTENT" in msg:
                    current_text = stream_state.full_text_buffer if stream_state else ""
                    if len(current_text) > sent_chars:
                        new_delta = current_text[sent_chars:]
                        sent_chars = len(current_text)
                        await verify_current_delivery()
                        yield _text_message_content("live-msg-id", new_delta)
                else:
                    await verify_current_delivery()
                    yield msg

                if "RUN_FINISHED" in msg or "RUN_ERROR" in msg:
                    break

        except ExecutionTrustError:
            logger.info("diagnose: delivery authorization withdrawn for incident=%s", incident_id)
        except (asyncio.CancelledError, GeneratorExit):
            logger.info("diagnose: client disconnected from SSE stream for incident=%s", incident_id)
        finally:
            diagnosis_task_manager.unregister_queue(incident_id, queue)
    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-store",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post(
    "/incidents/{incident_id}/diagnose/cancel",
    status_code=200,
    summary="Cancel a running diagnosis",
    description="Cancel an in-progress agent diagnosis for this incident.",
)
async def cancel_diagnosis(
    incident_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
):
    tenant_id = require_tenant_context(request)
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    result = await session.exec(
        select(Incident).where(
            Incident.id == incident_id,
            Incident.tenant_id == tenant_id,
        )
    )
    incident = result.scalars().first()
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")

    if incident.diagnosis_status != "running":
        raise HTTPException(status_code=400, detail="No running diagnosis to cancel")

    thread_id = incident.thread_id
    if not thread_id:
        raise HTTPException(status_code=400, detail="No active diagnosis thread found")

    import uuid

    from langgraph_sdk import get_client

    from app.alerting.diagnosis_run_control import interrupt_owned_runs
    from app.gateway.file_authorization import require_thread_access
    from app.models.alerting import IncidentAction

    factory = get_session_factory()
    await require_thread_access(request, thread_id, factory=factory)
    # Persist stop intent before cancelling local delivery or waiting on the
    # network. Old workers can no longer admit tools or overwrite the result.
    incident.diagnosis_status = "failed"
    incident.diagnosis_error = "cancel_requested: remote interruption unknown; inspect external effects"
    session.add(incident)
    action = IncidentAction(id=str(uuid.uuid4()), tenant_id=tenant_id, incident_id=incident_id,
        actor_id=user_id, action_type="diagnosis_cancel_requested",
        action_payload={"thread_id": thread_id, "interruption": "unknown", "external_effects": "unknown"})
    session.add(action)
    await session.commit()
    diagnosis_task_manager.cancel_task(incident_id)

    client = get_client(url=os.getenv("LANGGRAPH_API_URL", "http://localhost:2025"))
    outcome = await interrupt_owned_runs(client, thread_id, tenant_id, user_id, factory)
    await session.refresh(incident)
    if incident.thread_id == thread_id and (incident.diagnosis_error or "").startswith("cancel_requested:"):
        incident.diagnosis_status = "cancelled" if outcome.status == "confirmed" else "failed"
        incident.diagnosis_error = "cancel_requested: interruption " + outcome.status + "; inspect external effects"
        session.add(incident)
    action.action_payload = {"thread_id": thread_id, "interruption": outcome.status,
        "run_ids": list(outcome.run_ids), "external_effects": "unknown"}
    session.add(action)
    await session.commit()
    return {"status": "cancelled" if outcome.status == "confirmed" else "unknown", "incident_id": incident_id,
        "external_effects": "unknown"}


# ---------------------------------------------------------------------------
# Alert Sources
# ---------------------------------------------------------------------------


def _merge_ai_analysis_into_config(
    config_json: dict, enabled: bool | None, severities: list[str] | None, model: str | None = None,
    diagnosis_agent_id: str | None = None,
) -> dict:
    """Merge AI analysis UI fields into config_json.analysis_trigger."""
    config = dict(config_json) if config_json else {}

    if enabled is None and severities is None and model is None and diagnosis_agent_id is None:
        return config

    existing = config.get("analysis_trigger", {})

    if enabled is not None:
        if enabled and severities:
            existing["mode"] = "conditional"
            existing["conditions"] = {"severity": severities}
        elif enabled:
            existing["mode"] = "conditional"
            existing["conditions"] = existing.get("conditions", {"severity": ["critical", "major"]})
        else:
            existing["mode"] = "manual"
            existing.pop("conditions", None)

    if severities is not None and enabled is None:
        existing["conditions"] = {"severity": severities}

    if model is not None:
        if model:
            existing["model"] = model
        else:
            existing.pop("model", None)

    if diagnosis_agent_id is not None:
        if diagnosis_agent_id:
            existing["diagnosis_agent_id"] = diagnosis_agent_id
        else:
            existing.pop("diagnosis_agent_id", None)

    config["analysis_trigger"] = existing
    return config


def _extract_ai_analysis_from_config(config_json: dict | None) -> tuple[bool, list[str], str | None, str | None]:
    """Extract AI analysis UI fields from config_json.analysis_trigger.

    Returns (enabled, severities, model, diagnosis_agent_id).
    """
    if not config_json:
        return False, [], None, None

    trigger = config_json.get("analysis_trigger", {})
    mode = trigger.get("mode", "conditional")

    if mode == "manual":
        return False, [], trigger.get("model") or None, trigger.get("diagnosis_agent_id") or None

    severities = list(
        trigger.get("conditions", {}).get("severity", list(DEFAULT_AUTO_SEVERITIES))
    )
    model = trigger.get("model") or None
    diagnosis_agent_id = trigger.get("diagnosis_agent_id") or None
    return True, severities, model, diagnosis_agent_id


async def _validate_diagnosis_agent(
    session: AsyncSession,
    tenant_id: str,
    agent_id: str,
) -> None:
    """Validate that a diagnosis agent exists and is a shared agent."""
    from app.models.agents import CustomAgent

    result = await session.exec(
        select(CustomAgent).where(
            CustomAgent.id == agent_id,
            CustomAgent.tenant_id == tenant_id,
        )
    )
    agent = result.scalars().first()
    if agent is None:
        raise HTTPException(status_code=400, detail=f"诊断 Agent ({agent_id}) 不存在或不属于该租户")
    if agent.user_id != "tenant-shared":
        raise HTTPException(status_code=400, detail=f"只能使用租户共享 Agent 作为诊断 Agent。Agent '{agent.name}' 是私有 Agent。")
    if not agent.enabled:
        raise HTTPException(status_code=400, detail=f"诊断 Agent '{agent.name}' 已被禁用，请先启用。")


class AlertSourceCreate(BaseModel):
    name: str
    type: str = "webhook"
    auth_mode: str = "none"
    config_json: dict = Field(default_factory=dict)
    ai_analysis_enabled: bool = False
    ai_analysis_severities: list[str] = Field(default_factory=lambda: ["critical", "major"])
    ai_analysis_model: str | None = None
    diagnosis_agent_id: str | None = None


class AlertSourceResponse(BaseModel):
    @field_validator("config_json", mode="before")
    @classmethod
    def hide_ticket_credentials(cls, value: dict) -> dict:
        return redact_ticket_config(value)

    id: str
    name: str
    type: str
    status: str
    auth_mode: str
    config_json: dict
    ai_analysis_enabled: bool = False
    ai_analysis_severities: list[str] = Field(default_factory=list)
    ai_analysis_model: str | None = None
    diagnosis_agent_id: str | None = None
    created_at: str


@router.get(
    "/alert-sources",
    response_model=list[AlertSourceResponse],
    summary="List alert sources",
)
async def list_alert_sources(
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> list[AlertSourceResponse]:
    tenant_id = require_tenant_context(request)
    result = await session.exec(
        select(AlertSource).where(AlertSource.tenant_id == tenant_id)
    )
    rows = result.scalars().all()
    return [
        AlertSourceResponse(
            id=r.id,
            name=r.name,
            type=r.type,
            status=r.status,
            auth_mode=r.auth_mode,
            config_json=r.config_json,
            ai_analysis_enabled=_extract_ai_analysis_from_config(r.config_json)[0],
            ai_analysis_severities=_extract_ai_analysis_from_config(r.config_json)[1],
            ai_analysis_model=_extract_ai_analysis_from_config(r.config_json)[2],
            diagnosis_agent_id=_extract_ai_analysis_from_config(r.config_json)[3],
            created_at=r.created_at.isoformat() if r.created_at else "",
        )
        for r in rows
    ]


@router.post(
    "/alert-sources",
    response_model=AlertSourceResponse,
    status_code=201,
    summary="Create alert source",
)
async def create_alert_source(
    body: AlertSourceCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> AlertSourceResponse:
    tenant_id = require_tenant_admin(request)
    user_id = getattr(request.state, "user_id", None)

    import uuid

    # Validate diagnosis_agent_id if provided
    if body.diagnosis_agent_id:
        await _validate_diagnosis_agent(session, tenant_id, body.diagnosis_agent_id)

    try:
        source_config = restore_ticket_config(body.config_json)
        validate_ticket_ref_config(source_config)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    merged_config = _merge_ai_analysis_into_config(
        source_config, body.ai_analysis_enabled, body.ai_analysis_severities, body.ai_analysis_model,
        body.diagnosis_agent_id,
    )

    merged_config = await diagnosis_authorization.configure(session, tenant_id, user_id, merged_config, confirm=True)

    source = AlertSource(
        id=str(uuid.uuid4()),
        tenant_id=tenant_id,
        name=body.name,
        type=body.type,
        auth_mode=body.auth_mode,
        config_json=merged_config,
        created_by=user_id,
    )
    session.add(source)
    await session.commit()
    await session.refresh(source)

    ai_enabled, ai_severities, ai_model, ai_agent = _extract_ai_analysis_from_config(source.config_json)
    return AlertSourceResponse(
        id=source.id,
        name=source.name,
        type=source.type,
        status=source.status,
        auth_mode=source.auth_mode,
        config_json=source.config_json,
        ai_analysis_enabled=ai_enabled,
        ai_analysis_severities=ai_severities,
        ai_analysis_model=ai_model,
        diagnosis_agent_id=ai_agent,
        created_at=source.created_at.isoformat() if source.created_at else "",
    )


class AlertSourceUpdate(BaseModel):
    name: str | None = None
    type: str | None = None
    status: str | None = None  # active / disabled
    auth_mode: str | None = None
    config_json: dict | None = None
    ai_analysis_enabled: bool | None = None
    ai_analysis_severities: list[str] | None = None
    ai_analysis_model: str | None = None
    diagnosis_agent_id: str | None = None


@router.put(
    "/alert-sources/{source_id}",
    response_model=AlertSourceResponse,
    summary="Update alert source",
)
async def update_alert_source(
    source_id: str,
    body: AlertSourceUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> AlertSourceResponse:
    tenant_id = require_tenant_admin(request)
    result = await session.exec(
        select(AlertSource).where(
            AlertSource.id == source_id,
            AlertSource.tenant_id == tenant_id,
        )
    )
    source = result.scalars().first()
    if source is None:
        raise HTTPException(status_code=404, detail="Alert source not found")

    from copy import deepcopy
    previous_config = deepcopy(source.config_json or {})

    # Validate diagnosis_agent_id if being changed
    if body.diagnosis_agent_id:
        await _validate_diagnosis_agent(session, tenant_id, body.diagnosis_agent_id)

    if body.name is not None:
        source.name = body.name
    if body.type is not None:
        source.type = body.type
    if body.status is not None:
        source.status = body.status
    if body.auth_mode is not None:
        source.auth_mode = body.auth_mode
    if body.config_json is not None:
        try:
            source_config = restore_ticket_config(body.config_json, source.config_json)
            validate_ticket_ref_config(source_config, source.config_json)
            source.config_json = source_config
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from None

    # Merge AI analysis fields into config_json
    source.config_json = _merge_ai_analysis_into_config(
        source.config_json or {},
        body.ai_analysis_enabled,
        body.ai_analysis_severities,
        body.ai_analysis_model,
        body.diagnosis_agent_id,
    )

    source.config_json = await diagnosis_authorization.configure(session, tenant_id, getattr(request.state,"user_id",None), source.config_json, previous_config,
        confirm=bool({"ai_analysis_enabled", "ai_analysis_severities", "ai_analysis_model", "diagnosis_agent_id"} & body.model_fields_set))

    session.add(source)
    await session.commit()
    await session.refresh(source)

    ai_enabled, ai_severities, ai_model, ai_agent = _extract_ai_analysis_from_config(source.config_json)
    return AlertSourceResponse(
        id=source.id,
        name=source.name,
        type=source.type,
        status=source.status,
        auth_mode=source.auth_mode,
        config_json=source.config_json,
        ai_analysis_enabled=ai_enabled,
        ai_analysis_severities=ai_severities,
        ai_analysis_model=ai_model,
        diagnosis_agent_id=ai_agent,
        created_at=source.created_at.isoformat() if source.created_at else "",
    )


@router.delete(
    "/alert-sources/{source_id}",
    status_code=204,
    summary="Delete alert source",
)
async def delete_alert_source(
    source_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> None:
    tenant_id = require_tenant_admin(request)
    result = await session.exec(
        select(AlertSource).where(
            AlertSource.id == source_id,
            AlertSource.tenant_id == tenant_id,
        )
    )
    source = result.scalars().first()
    if source is None:
        raise HTTPException(status_code=404, detail="Alert source not found")
    await session.delete(source)
    await session.commit()


class AlertSourceTestRequest(BaseModel):
    payload: dict


@router.post(
    "/alert-sources/{source_id}/test",
    summary="Test alert source with a sample payload",
    description="Send a test payload through the ingest pipeline and return the parsed signal without persisting.",
)
async def test_alert_source(
    source_id: str,
    body: AlertSourceTestRequest,
    request: Request,
    session: AsyncSession = Depends(get_session),
):
    tenant_id = require_tenant_admin(request)

    result = await session.exec(
        select(AlertSource).where(
            AlertSource.id == source_id,
            AlertSource.tenant_id == tenant_id,
        )
    )
    source = result.scalars().first()
    if source is None:
        raise HTTPException(status_code=404, detail="Alert source not found")

    from app.alerting.providers import get_provider

    provider = get_provider(source.type)
    if provider is None:
        raise HTTPException(status_code=400, detail=f"No provider for type '{source.type}'")

    try:
        raw_alert = provider.parse_raw_payload(body.payload, {})
        raw_alert.id = "test"
        raw_alert.tenant_id = tenant_id
        raw_alert.source_id = source_id

        signal = provider.normalize(raw_alert, source_config=source.config_json)

        return {
            "status": "ok",
            "source_type": source.type,
            "signal": {
                "title": signal.title,
                "summary": signal.summary,
                "severity": signal.severity,
                "status": signal.status,
                "service": signal.service,
                "environment": signal.environment,
                "labels": signal.labels_json,
            },
            "field_mapping": source.config_json.get("field_mapping", {}),
        }
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Normalization failed: {str(e)}")


# ---------------------------------------------------------------------------
# Alerting Settings (per-tenant config)
# ---------------------------------------------------------------------------


class AlertingNotificationPrefs(BaseModel):
    """Alerting-specific notification preferences (does NOT include channel config)."""
    severity_threshold: str = "major"
    on_resolved: bool = True
    digest: dict | None = None
    quiet_hours: dict | None = None


class AlertingSettingsResponse(BaseModel):
    raw_alert_retention_days: int = 30
    notification_config: dict = Field(default_factory=dict)


class AlertingSettingsUpdate(BaseModel):
    raw_alert_retention_days: int = 30
    notification_config: AlertingNotificationPrefs | None = None


@router.get(
    "/alerting-settings",
    response_model=AlertingSettingsResponse,
    summary="Get alerting settings",
)
async def get_alerting_settings(
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> AlertingSettingsResponse:
    from app.alerting.cleanup import get_retention_days

    tenant_id = require_tenant_context(request)
    days = await get_retention_days(session, tenant_id)

    result = await session.exec(
        select(AlertingSettings).where(AlertingSettings.tenant_id == tenant_id)
    )
    settings = result.scalars().first()
    notification = settings.notification_config if settings else {}

    return AlertingSettingsResponse(raw_alert_retention_days=days, notification_config=notification)


@router.put(
    "/alerting-settings",
    response_model=AlertingSettingsResponse,
    summary="Update alerting settings",
)
async def update_alerting_settings(
    body: AlertingSettingsUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> AlertingSettingsResponse:
    """Update only alerting-specific notification preferences.
    Does NOT overwrite channel config (channels, chat_ids) managed by IM settings."""
    from app.alerting.cleanup import clamp_retention_days

    tenant_id = require_tenant_admin(request)
    days = clamp_retention_days(body.raw_alert_retention_days)

    result = await session.exec(
        select(AlertingSettings).where(AlertingSettings.tenant_id == tenant_id)
    )
    settings = result.scalars().first()

    if settings is None:
        import uuid
        settings = AlertingSettings(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            raw_alert_retention_days=days,
            notification_config={},
        )

    settings.raw_alert_retention_days = days

    # Merge: only update alerting-specific notification keys, preserve channel keys
    if body.notification_config is not None:
        cfg = dict(settings.notification_config or {})
        cfg["severity_threshold"] = body.notification_config.severity_threshold
        cfg["on_resolved"] = body.notification_config.on_resolved
        if body.notification_config.digest is not None:
            cfg["digest"] = body.notification_config.digest
        if body.notification_config.quiet_hours is not None:
            cfg["quiet_hours"] = body.notification_config.quiet_hours
        settings.notification_config = cfg

    session.add(settings)
    await session.commit()

    return AlertingSettingsResponse(
        raw_alert_retention_days=settings.raw_alert_retention_days,
        notification_config=settings.notification_config,
    )


# ---------------------------------------------------------------------------
# Alert Rules CRUD
# ---------------------------------------------------------------------------


class AlertRuleCreate(BaseModel):
    name: str
    rule_type: str = "suppression"  # suppression, aggregation, dedup
    enabled: bool = True
    condition_json: dict = Field(default_factory=dict)
    action_json: dict = Field(default_factory=dict)


class AlertRuleUpdate(BaseModel):
    name: str | None = None
    rule_type: str | None = None
    enabled: bool | None = None
    condition_json: dict | None = None
    action_json: dict | None = None


class AlertRuleResponse(BaseModel):
    id: str
    name: str
    rule_type: str
    enabled: bool
    condition_json: dict
    action_json: dict
    created_at: str
    updated_at: str


@router.get(
    "/alert-rules",
    response_model=list[AlertRuleResponse],
    summary="List alert rules",
)
async def list_alert_rules(
    request: Request,
    session: AsyncSession = Depends(get_session),
    rule_type: str | None = None,
) -> list[AlertRuleResponse]:
    tenant_id = require_tenant_context(request)
    conditions = [AlertRule.tenant_id == tenant_id]
    if rule_type:
        conditions.append(AlertRule.rule_type == rule_type)
    result = await session.exec(
        select(AlertRule).where(*conditions).order_by(AlertRule.rule_type, AlertRule.name)
    )
    rows = result.scalars().all()
    return [
        AlertRuleResponse(
            id=r.id,
            name=r.name,
            rule_type=r.rule_type,
            enabled=r.enabled,
            condition_json=r.condition_json,
            action_json=r.action_json,
            created_at=r.created_at.isoformat() if r.created_at else "",
            updated_at=r.updated_at.isoformat() if r.updated_at else "",
        )
        for r in rows
    ]


@router.post(
    "/alert-rules",
    response_model=AlertRuleResponse,
    status_code=201,
    summary="Create alert rule",
)
async def create_alert_rule(
    body: AlertRuleCreate,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> AlertRuleResponse:
    tenant_id = require_tenant_admin(request)
    import uuid

    rule = AlertRule(
        id=str(uuid.uuid4()),
        tenant_id=tenant_id,
        name=body.name,
        rule_type=body.rule_type,
        enabled=body.enabled,
        condition_json=body.condition_json,
        action_json=body.action_json,
    )
    session.add(rule)
    await session.commit()
    await session.refresh(rule)

    return AlertRuleResponse(
        id=rule.id,
        name=rule.name,
        rule_type=rule.rule_type,
        enabled=rule.enabled,
        condition_json=rule.condition_json,
        action_json=rule.action_json,
        created_at=rule.created_at.isoformat() if rule.created_at else "",
        updated_at=rule.updated_at.isoformat() if rule.updated_at else "",
    )


@router.put(
    "/alert-rules/{rule_id}",
    response_model=AlertRuleResponse,
    summary="Update alert rule",
)
async def update_alert_rule(
    rule_id: str,
    body: AlertRuleUpdate,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> AlertRuleResponse:
    tenant_id = require_tenant_admin(request)
    result = await session.exec(
        select(AlertRule).where(AlertRule.id == rule_id, AlertRule.tenant_id == tenant_id)
    )
    rule = result.scalars().first()
    if rule is None:
        raise HTTPException(status_code=404, detail="Alert rule not found")

    if body.name is not None:
        rule.name = body.name
    if body.rule_type is not None:
        rule.rule_type = body.rule_type
    if body.enabled is not None:
        rule.enabled = body.enabled
    if body.condition_json is not None:
        rule.condition_json = body.condition_json
    if body.action_json is not None:
        rule.action_json = body.action_json

    session.add(rule)
    await session.commit()
    await session.refresh(rule)

    return AlertRuleResponse(
        id=rule.id,
        name=rule.name,
        rule_type=rule.rule_type,
        enabled=rule.enabled,
        condition_json=rule.condition_json,
        action_json=rule.action_json,
        created_at=rule.created_at.isoformat() if rule.created_at else "",
        updated_at=rule.updated_at.isoformat() if rule.updated_at else "",
    )


@router.delete(
    "/alert-rules/{rule_id}",
    status_code=204,
    summary="Delete alert rule",
)
async def delete_alert_rule(
    rule_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> None:
    tenant_id = require_tenant_admin(request)
    result = await session.exec(
        select(AlertRule).where(AlertRule.id == rule_id, AlertRule.tenant_id == tenant_id)
    )
    rule = result.scalars().first()
    if rule is None:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    await session.delete(rule)
    await session.commit()


# ---------------------------------------------------------------------------
# Change Events
# ---------------------------------------------------------------------------


@router.get(
    "/changes",
    response_model=list[dict],
    summary="List change events",
)
async def list_changes(
    request: Request,
    session: AsyncSession = Depends(get_session),
    service: str | None = None,
    limit: int = 20,
) -> list[dict]:
    tenant_id = require_tenant_context(request)
    conditions = [ChangeEvent.tenant_id == tenant_id]
    if service:
        conditions.append(ChangeEvent.service == service)
    result = await session.exec(
        select(ChangeEvent).where(*conditions).order_by(ChangeEvent.changed_at.desc()).limit(limit)
    )
    return [
        {
            "id": c.id, "change_type": c.change_type, "summary": c.summary,
            "service": c.service, "environment": c.environment,
            "changed_by": c.changed_by,
            "changed_at": c.changed_at.isoformat() if c.changed_at else "",
        }
        for c in result.scalars().all()
    ]


@router.post(
    "/changes/ingest/{source_id}",
    status_code=202,
    summary="Ingest change event",
)
async def ingest_change(
    source_id: str,
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> dict:
    """Ingest a deployment or config-change event from CI/CD pipelines."""
    source = await session.get(AlertSource, source_id)
    if source is None:
        raise HTTPException(status_code=404, detail="Source not found")
    if source.status != "active":
        raise HTTPException(status_code=403, detail="Source is disabled")

    body = await request.json()
    import uuid

    change = ChangeEvent(
        id=str(uuid.uuid4()),
        tenant_id=source.tenant_id,
        source_id=source_id,
        service=body.get("service"),
        environment=body.get("environment"),
        change_type=body.get("change_type", "deploy"),
        summary=body.get("summary", ""),
        detail_json=body.get("detail", {}),
        changed_by=body.get("changed_by"),
    )
    session.add(change)
    await session.commit()

    return {"id": change.id, "status": "ingested"}


# ── Dashboard / Stats ────────────────────────────────────────────────────────────

class IncidentStatsSummary(BaseModel):
    total_firing: int
    total_resolved: int
    total_suppressed: int
    severity_distribution: dict[str, int]  # e.g. {"critical": 3, "warning": 7}
    mttr_minutes: float | None = None  # Mean Time To Resolve
    mtta_minutes: float | None = None  # Mean Time To Acknowledge (claim/assign)
    recent_trend: list[dict]  # daily counts for last 7 days


@router.get(
    "/incidents/stats/summary",
    response_model=IncidentStatsSummary,
    summary="Get incident dashboard stats",
    description="Get summary statistics for the incident dashboard including MTTR, MTTA, severity distribution, and 7-day trend.",
)
async def get_incident_stats_summary(
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> IncidentStatsSummary:
    from datetime import UTC, timedelta
    from datetime import datetime as dt
    tenant_id = require_tenant_context(request)

    now = dt.now(UTC)

    # Count by status
    firing_count = 0
    resolved_count = 0
    suppressed_count = 0
    severity_dist: dict[str, int] = {}

    count_result = await session.exec(
        select(Incident).where(Incident.tenant_id == tenant_id)
    )
    for inc in count_result.scalars().all():
        if inc.status == "firing":
            firing_count += 1
        elif inc.status == "resolved":
            resolved_count += 1
        elif inc.status == "suppressed":
            suppressed_count += 1
        severity_dist[inc.severity] = severity_dist.get(inc.severity, 0) + 1

    thirty_days_ago = now - timedelta(days=30)

    # MTTR: average time from first_seen to resolved for resolved incidents
    mttr: float | None = None
    mttr_times: list[float] = []
    mttr_result = await session.exec(
        select(Incident).where(
            Incident.tenant_id == tenant_id,
            Incident.status == "resolved",
            Incident.resolved_at.isnot(None),
            Incident.first_seen_at >= thirty_days_ago,
        )
    )
    for inc in mttr_result.scalars().all():
        if inc.first_seen_at and inc.resolved_at:
            delta = (inc.resolved_at - inc.first_seen_at).total_seconds() / 60
            if delta > 0:
                mttr_times.append(delta)
    if mttr_times:
        mttr = sum(mttr_times) / len(mttr_times)

    # MTTA: average time from first_seen to first claim/assign
    from app.models.alerting import IncidentAction
    mtta: float | None = None
    mtta_times: list[float] = []
    mtta_result = await session.exec(
        select(Incident).where(
            Incident.tenant_id == tenant_id,
            Incident.first_seen_at >= thirty_days_ago,
        )
    )
    for inc in mtta_result.scalars().all():
        if not inc.first_seen_at:
            continue
        action_result = await session.exec(
            select(IncidentAction).where(
                IncidentAction.incident_id == inc.id,
                IncidentAction.tenant_id == tenant_id,
                IncidentAction.action_type.in_(["claimed", "assigned"]),
            ).order_by(IncidentAction.created_at.asc()).limit(1)
        )
        first_ack = action_result.scalars().first()
        if first_ack:
            delta = (first_ack.created_at - inc.first_seen_at).total_seconds() / 60
            if delta > 0:
                mtta_times.append(delta)
    if mtta_times:
        mtta = sum(mtta_times) / len(mtta_times)

    # 7-day trend: count incidents created per day
    recent_trend: list[dict] = []
    for day_offset in range(6, -1, -1):
        day_start = (now - timedelta(days=day_offset)).replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        day_count_result = await session.exec(
            select(Incident).where(
                Incident.tenant_id == tenant_id,
                Incident.created_at >= day_start,
                Incident.created_at < day_end,
            )
        )
        count = len(day_count_result.scalars().all())
        recent_trend.append({
            "date": day_start.strftime("%Y-%m-%d"),
            "count": count,
        })

    return IncidentStatsSummary(
        total_firing=firing_count,
        total_resolved=resolved_count,
        total_suppressed=suppressed_count,
        severity_distribution=severity_dist,
        mttr_minutes=round(mttr, 1) if mttr else None,
        mtta_minutes=round(mtta, 1) if mtta else None,
        recent_trend=recent_trend,
    )


# ── Source Health ──────────────────────────────────────────────────────────────

class SourceHealthItem(BaseModel):
    source_id: str
    source_name: str
    source_type: str
    status: str  # active, disabled
    last_received_at: str | None = None
    total_received_24h: int = 0
    total_errors_24h: int = 0
    health: str = "unknown"  # healthy, warning, error, unknown


@router.get(
    "/alert-sources/health",
    response_model=list[SourceHealthItem],
    summary="Get alert source health status",
    description="Return health metrics for all alert sources: last received time, 24h volume, error rate, and health status.",
)
async def get_source_health(
    request: Request,
    session: AsyncSession = Depends(get_session),
) -> list[SourceHealthItem]:
    from datetime import UTC, timedelta
    from datetime import datetime as dt
    tenant_id = require_tenant_context(request)

    now = dt.now(UTC)
    day_ago = now - timedelta(hours=24)

    # Fetch all sources for tenant
    sources_result = await session.exec(
        select(AlertSource).where(AlertSource.tenant_id == tenant_id)
    )
    sources = sources_result.scalars().all()

    # For each source, compute health metrics from raw_alerts
    result: list[SourceHealthItem] = []
    for source in sources:
        # Count 24h received
        count_24h_result = await session.exec(
            select(RawAlert).where(
                RawAlert.tenant_id == tenant_id,
                RawAlert.source_id == source.id,
                RawAlert.received_at >= day_ago,
            )
        )
        total_24h = len(count_24h_result.scalars().all())

        # Count 24h errors (ingest_status != "received" means error)
        errors_24h_result = await session.exec(
            select(RawAlert).where(
                RawAlert.tenant_id == tenant_id,
                RawAlert.source_id == source.id,
                RawAlert.received_at >= day_ago,
                RawAlert.ingest_status != "received",
            )
        )
        total_errors_24h = len(errors_24h_result.scalars().all())

        # Last received
        last_result = await session.exec(
            select(RawAlert).where(
                RawAlert.tenant_id == tenant_id,
                RawAlert.source_id == source.id,
            ).order_by(RawAlert.received_at.desc()).limit(1)
        )
        last_raw = last_result.scalars().first()
        last_received = last_raw.received_at.isoformat() if last_raw and last_raw.received_at else None

        # Health determination
        if source.status != "active":
            health = "unknown"
        elif total_24h == 0:
            health = "warning"  # active but no data in 24h
        elif total_errors_24h > 0:
            error_rate = total_errors_24h / max(total_24h, 1)
            health = "error" if error_rate > 0.5 else ("warning" if error_rate > 0.1 else "healthy")
        else:
            health = "healthy"

        result.append(SourceHealthItem(
            source_id=source.id,
            source_name=source.name,
            source_type=source.type,
            status=source.status,
            last_received_at=last_received,
            total_received_24h=total_24h,
            total_errors_24h=total_errors_24h,
            health=health,
        ))

    return result
