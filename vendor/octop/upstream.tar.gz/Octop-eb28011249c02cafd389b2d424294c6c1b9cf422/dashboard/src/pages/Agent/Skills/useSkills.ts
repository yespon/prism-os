import { useCallback, useState } from "react";
import { App } from "antd";

import { useTranslation } from "react-i18next";
import { request } from "../../../api/request";
import { useAsyncResource } from "../../../hooks/useAsyncResource";
import { parseApiError } from "../../../utils/apiError";
import { showApiError } from "../../../utils/showApiToast";

/**
 * SkillSpec mirrors the JSON shape returned by octop's
 * ``GET /api/agents/{aid}/skills`` (see ``octop/api/routers/skills.py``).
 *
 * Field-name reconciliation: finnie's UI treats the identifier as ``slug``
 * and uses ``kind`` (``builtin`` | ``workspace``) to split built-in vs
 * customised skills. Octop only returns ``name`` and has no kind concept.
 *
 * To reuse finnie-style components without renaming everything, this
 * hook exposes ``slug`` (= server's ``name``) and synthesises ``kind``
 * (always ``"workspace"`` for now — every octop skill is editable).
 * The optional ``emoji`` from frontmatter is also surfaced for the card.
 */
export interface SkillSpec {
  /** Identifier used in URLs / list keys. Equal to the server's ``name``. */
  slug: string;
  /** Human readable name (server falls back to slug). */
  name: string;
  description: string;
  enabled: boolean;
  /** Source of the skill. */
  kind: "workspace" | "builtin" | "package";
  emoji?: string;
  /** Persisted SkillHub marketplace icon. */
  iconUrl?: string;
  /** ``metadata.octop.label`` when the API keeps the localized map. */
  label?:
    | string
    | { zh?: string; en?: string; [key: string]: string | undefined };
  displayName?: string;
}

export interface SkillDetail extends SkillSpec {
  /** Parsed YAML frontmatter (key/value, untyped). */
  frontmatter: Record<string, unknown>;
  /** Markdown body without the frontmatter block. */
  body: string;
  /** Raw SKILL.md content including frontmatter. */
  raw: string;
}

interface ServerSummary {
  /** Directory name — the stable identifier for operations. */
  slug?: string;
  /** Frontmatter display name (may differ from slug). */
  name: string;
  description: string;
  enabled: boolean;
  kind?: "workspace" | "builtin" | "package";
  emoji?: string;
  icon_url?: string;
  /** ``metadata.octop.label`` map (zh/en) when not yet folded into ``name``. */
  label?:
    | string
    | { zh?: string; en?: string; [key: string]: string | undefined };
  display_name?: string;
  /** Present when the skill manifest exists but cannot be decoded. */
  corrupt?: boolean;
  error?: string;
}

interface ServerDetail extends ServerSummary {
  frontmatter: Record<string, unknown>;
  body: string;
  raw: string;
}

const toSpec = (row: ServerSummary): SkillSpec => ({
  // Prefer the directory-name slug for operations; fall back to name for
  // older backends that didn't return slug.
  slug: row.slug ?? row.name,
  name: row.name,
  description: row.description || "",
  enabled: row.enabled,
  kind:
    row.kind === "builtin"
      ? "builtin"
      : row.kind === "package"
      ? "package"
      : "workspace",
  emoji: row.emoji,
  iconUrl: row.icon_url,
  label: row.label,
  displayName: row.display_name,
});

const toDetail = (row: ServerDetail): SkillDetail => ({
  ...toSpec(row),
  frontmatter: row.frontmatter || {},
  body: row.body || "",
  raw: row.raw || "",
});

/**
 * Manage the per-agent skills list for the current ``activeAgentId``.
 */
export function useSkills(
  agentId: string | null,
  options?: { enabled?: boolean },
) {
  const { t } = useTranslation();
  const { modal, message } = App.useApp();
  const enabled = options?.enabled !== false && !!agentId;

  const {
    data: skills,
    loading,
    refresh: fetchSkills,
    setData: setSkills,
  } = useAsyncResource<SkillSpec[]>(
    [],
    async () => {
      const rows = await request<ServerSummary[]>(
        `/agents/${encodeURIComponent(agentId!)}/skills`,
        {
          cache: "no-store",
        },
      );
      const list = rows || [];
      const corrupt = list.filter((row) => row.corrupt);
      if (corrupt.length > 0) {
        message.warning(
          t("skills.corruptSkipped", {
            slugs: corrupt.map((row) => row.slug ?? row.name).join(", "),
          }),
        );
      }
      return list.filter((row) => !row.corrupt).map(toSpec);
    },
    [agentId, message, t],
    {
      enabled,
      errorFallback: t("skills.loadFailed"),
      t,
      logLabel: "Skills",
    },
  );

  const getDetail = useCallback(
    async (slug: string): Promise<SkillDetail | null> => {
      if (!agentId) return null;
      try {
        const row = await request<ServerDetail>(
          `/agents/${encodeURIComponent(agentId)}/skills/${encodeURIComponent(
            slug,
          )}`,
          { cache: "no-store" },
        );
        return toDetail(row);
      } catch (error) {
        console.error("Failed to load skill detail", error);
        showApiError(error, t("skills.loadDetailFailed"), t);
        return null;
      }
    },
    [agentId, t],
  );

  const createSkill = useCallback(
    async (name: string, content: string): Promise<boolean> => {
      if (!agentId) return false;
      try {
        await request(`/agents/${agentId}/skills`, {
          method: "POST",
          body: JSON.stringify({ name, content }),
        });
        message.success(t("skills.createSuccess"));
        await fetchSkills();
        return true;
      } catch (error) {
        console.error("Failed to save skill", error);
        showApiError(error, t("skills.createFailed"), t);
        return false;
      }
    },
    [agentId, fetchSkills, t],
  );

  const updateSkill = useCallback(
    async (slug: string, content: string): Promise<boolean> => {
      if (!agentId) return false;
      try {
        await request(`/agents/${agentId}/skills/${slug}`, {
          method: "PUT",
          body: JSON.stringify({ content }),
        });
        message.success(t("skills.updateSuccess"));
        await fetchSkills();
        return true;
      } catch (error) {
        console.error("Failed to update skill", error);
        showApiError(error, t("skills.updateFailed"), t);
        return false;
      }
    },
    [agentId, fetchSkills, t],
  );

  const toggleEnabled = useCallback(
    async (skill: SkillSpec): Promise<boolean> => {
      if (!agentId) return false;
      const action = skill.enabled ? "disable" : "enable";
      try {
        await request(`/agents/${agentId}/skills/${skill.slug}/${action}`, {
          method: "POST",
          cache: "no-store",
        });
        setSkills((prev) =>
          prev.map((s) =>
            s.slug === skill.slug ? { ...s, enabled: !skill.enabled } : s,
          ),
        );
        message.success(
          skill.enabled
            ? t("skills.disabledSuccess")
            : t("skills.enabledSuccess"),
        );
        return true;
      } catch (error) {
        console.error("Failed to toggle skill", error);
        showApiError(error, t("skills.operationFailed"), t);
        return false;
      }
    },
    [agentId, setSkills, t],
  );

  const deleteSkill = useCallback(
    async (skill: SkillSpec): Promise<boolean> => {
      if (!agentId) return false;
      const confirmed = await new Promise<boolean>((resolve) => {
        modal.confirm({
          title: t("common.delete"),
          content: t("skills.deleteConfirmContent", { slug: skill.slug }),
          okText: t("common.delete"),
          okType: "danger",
          cancelText: t("common.cancel"),
          onOk: () => resolve(true),
          onCancel: () => resolve(false),
        });
      });
      if (!confirmed) return false;

      try {
        await request(`/agents/${agentId}/skills/${skill.slug}`, {
          method: "DELETE",
        });
        message.success(t("skills.deleteSuccess"));
        await fetchSkills();
        return true;
      } catch (error) {
        console.error("Failed to delete skill", error);
        showApiError(error, t("skills.deleteFailed"), t);
        return false;
      }
    },
    [agentId, fetchSkills, t],
  );

  const [importing, setImporting] = useState(false);

  const importFromUrl = useCallback(
    async (
      bundleUrl: string,
      options?: { overwrite?: boolean },
    ): Promise<boolean> => {
      if (!agentId) return false;
      const trimmed = bundleUrl.trim();
      if (!trimmed) return false;
      try {
        setImporting(true);
        await request(`/agents/${agentId}/skills/import`, {
          method: "POST",
          body: JSON.stringify({
            bundle_url: trimmed,
            enable: true,
            overwrite: Boolean(options?.overwrite),
          }),
        });
        message.success(t("skills.importSuccess"));
        await fetchSkills();
        return true;
      } catch (error) {
        console.error("Failed to import skill from URL", error);
        showApiError(error, t("skills.importFailed"), t);
        return false;
      } finally {
        setImporting(false);
      }
    },
    [agentId, fetchSkills, t],
  );

  const importFromZip = useCallback(
    async (
      skillsToImport: Array<{
        slug: string;
        files: Array<{ path: string; contentBase64: string }>;
      }>,
      options?: { overwrite?: boolean },
    ) => {
      if (!agentId) return false as const;
      const overwrite = Boolean(options?.overwrite);
      let imported = 0;
      let skipped = 0;
      let failed = 0;
      setImporting(true);
      try {
        for (const skill of skillsToImport) {
          try {
            await request(`/agents/${agentId}/skills`, {
              method: "POST",
              body: JSON.stringify({
                name: skill.slug,
                files: skill.files.map((file) => ({
                  path: file.path,
                  content_base64: file.contentBase64,
                })),
                overwrite,
              }),
            });
            imported += 1;
          } catch (error) {
            const code = parseApiError(error)?.code;
            if (!overwrite && code === "SKILL_ALREADY_EXISTS") {
              skipped += 1;
              continue;
            }
            failed += 1;
          }
        }
        await fetchSkills();
        message.success(
          t("skills.zipImportSummary", { imported, skipped, failed }),
        );
        return { imported, skipped, failed };
      } finally {
        setImporting(false);
      }
    },
    [agentId, fetchSkills, t],
  );

  return {
    skills,
    loading,
    fetchSkills,
    getDetail,
    createSkill,
    updateSkill,
    importFromUrl,
    importFromZip,
    importing,
    toggleEnabled,
    deleteSkill,
  };
}
