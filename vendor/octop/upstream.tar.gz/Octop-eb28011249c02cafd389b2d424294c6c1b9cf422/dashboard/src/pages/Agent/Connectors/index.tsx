import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button, Drawer, Form, Input, Select, Spin, Switch, Alert } from "antd";
import { message } from "@/utils/antdMessage";

import {
  Activity,
  Blocks,
  CheckCircle2,
  ClipboardPaste,
  Copy,
  Download,
  ExternalLink,
  Link2,
  Plug,
  Plus,
  RefreshCw,
  Sparkles,
  Wrench,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { useSearchParams } from "react-router-dom";

import PageShell from "../../../layouts/PageShell";
import TabBar, { type TabBarItem } from "../../../components/TabLabel/TabBar";
import StreamSetupGuide from "../../../components/StreamSetupGuide/StreamSetupGuide";
import { OctopEmptyMascot } from "../../../components/EmptyState/OctopEmptyMascot";
import { useCurrentUser } from "../../../hooks/useCurrentUser";
import { userCan } from "../../../utils/permissions";
import { apiErrorMessage } from "../../../utils/apiError";
import { copyText } from "../../../utils/copyText";
import {
  clearFormDraft,
  loadFormDraft,
  saveFormDraft,
} from "../../../utils/formDraft";
import {
  connectorsApi,
  type ConnectorAuthInfo,
  type ConnectorCatalogEntry,
  type ConnectorCliInstallResult,
  type ConnectorCredentialsPreview,
  type ConnectorInstance,
  type ConnectorInstanceDetail,
  type FeishuUserAuthStartResult,
} from "../../../api/modules/connectors";
import { ConnectorCard } from "./ConnectorCard";
import { AgentlyAuth } from "./AgentlyAuth";
import { ConnectorInstanceCard } from "./ConnectorInstanceCard";
import { CustomMcpTab } from "./CustomMcpTab";
import {
  INLINE_CREDENTIAL_GUIDE_KINDS,
  HIDE_INLINE_FIELD_GUIDE_KINDS,
  MAIL_PROVIDERS,
  mailProviderById,
} from "./connectorDefs";
import { notifyConnectorsChanged } from "./customMcpUtils";
import {
  extractHttpUrl,
  isDifyMcpServerUrl,
  isGuidedConnector,
} from "./guidedConnectorUtils";
import { oauthCallbackSupported } from "./oauthCallback";
import { useConnectorInstances } from "./useConnectors";
import styles from "./index.module.less";

function buildCredentials(
  entry: ConnectorCatalogEntry,
  values: Record<string, unknown>,
): Record<string, unknown> {
  const credentials: Record<string, unknown> = {};
  if (entry.auth_kind === "personal_token") {
    const token = String(values.token ?? "").trim();
    if (token) credentials.token = token;
  } else if (entry.auth_kind === "oauth2") {
    if (entry.kind === "qcc") {
      const api_key = String(values.api_key ?? "").trim();
      if (api_key) {
        credentials.api_key = api_key;
        return credentials;
      }
    }
    const access_token = String(values.access_token ?? "").trim();
    if (access_token && access_token !== "__configured__") {
      credentials.access_token = access_token;
    }
    if (values.refresh_token) credentials.refresh_token = values.refresh_token;
    if (values.expires_at) credentials.expires_at = values.expires_at;
    if (values.oauth_client_id)
      credentials.oauth_client_id = values.oauth_client_id;
    if (values.oauth_client_secret)
      credentials.oauth_client_secret = values.oauth_client_secret;
    if (values.openid) credentials.openid = values.openid;
  } else if (entry.auth_kind === "auth_code") {
    const code = String(values.auth_code ?? "").trim();
    if (code) credentials.code = code;
  } else if (entry.auth_kind === "api_key") {
    if (entry.kind === "feishu-cli") {
      if (values.app_id) credentials.app_id = String(values.app_id).trim();
      const app_secret = String(values.app_secret ?? "").trim();
      if (app_secret) credentials.app_secret = app_secret;
      if (values.default_as === "user") credentials.default_as = "user";
      if (values.cli_config_key) {
        credentials.cli_config_key = String(values.cli_config_key).trim();
      }
    } else if (entry.kind === "wecom-cli") {
      if (values.bot_id) credentials.bot_id = String(values.bot_id).trim();
      const bot_secret = String(values.bot_secret ?? "").trim();
      if (bot_secret) credentials.bot_secret = bot_secret;
    } else {
      const api_key = String(values.api_key ?? "").trim();
      if (api_key) credentials.api_key = api_key;
      if (entry.kind === "tencent-ima" && values.client_id) {
        credentials.client_id = values.client_id;
      }
      if (entry.kind === "tencent-lexiang" && values.client_id) {
        credentials.client_id = values.client_id;
      }
    }
  } else if (entry.auth_kind === "imap_app_password") {
    credentials.email = values.email;
    const password = String(values.password ?? "").trim();
    if (password) credentials.password = password;
    if (values.mail_provider) {
      credentials.mail_provider = values.mail_provider;
    }
    if (values.mail_provider === "custom") {
      if (values.imap_host) credentials.imap_host = values.imap_host;
      if (values.smtp_host) credentials.smtp_host = values.smtp_host;
    }
  } else if (entry.auth_kind === "api_credentials") {
    credentials.app_id = values.app_id;
    credentials.sdk_id = values.sdk_id;
    const secret_key = String(values.secret_key ?? "").trim();
    if (secret_key) credentials.secret_key = secret_key;
  } else if (entry.auth_kind === "custom_fields") {
    for (const field of entry.credential_fields ?? []) {
      const text = String(values[field.key] ?? "").trim();
      if (!text) continue;
      credentials[field.key] =
        field.field_type === "tags"
          ? text
              .split(",")
              .map((item) => item.trim())
              .filter(Boolean)
          : text;
    }
  }
  return credentials;
}

function previewToFormValues(
  entry: ConnectorCatalogEntry,
  detail: ConnectorInstanceDetail | null,
): Record<string, unknown> {
  if (!detail) {
    return {
      display_name: entry.name,
      description: entry.description,
      mail_provider: "qq",
      default_open: false,
      shared: false,
    };
  }
  const preview = detail.credentials_preview ?? {};
  const values: Record<string, unknown> = {
    display_name: detail.display_name || entry.name,
    description: detail.description || entry.description,
    default_open:
      detail.default_open === true || detail.config?.default_open === true,
    shared: detail.shared === true,
  };
  if (preview.email) values.email = preview.email;
  if (preview.mail_provider) values.mail_provider = preview.mail_provider;
  if (preview.imap_host) values.imap_host = preview.imap_host;
  if (preview.smtp_host) values.smtp_host = preview.smtp_host;
  if (preview.bkn) values.bkn = preview.bkn;
  if (preview.knowledge_base_id)
    values.knowledge_base_id = preview.knowledge_base_id;
  if (preview.app_id) values.app_id = preview.app_id;
  if (preview.bot_id) values.bot_id = preview.bot_id;
  if (preview.cli_config_key) values.cli_config_key = preview.cli_config_key;
  if (preview.default_as === "user") values.default_as = "user";
  if (preview.client_id) values.client_id = preview.client_id;
  if (preview.sdk_id) values.sdk_id = preview.sdk_id;
  if (entry.auth_kind === "oauth2" && preview.oauth_configured) {
    values.access_token = "__configured__";
  }
  if (entry.auth_kind === "custom_fields") {
    for (const field of entry.credential_fields ?? []) {
      if (field.secret) continue;
      const value = preview[field.key];
      if (Array.isArray(value)) {
        values[field.key] = value.join(", ");
      } else if (value !== undefined && value !== null) {
        values[field.key] = value;
      }
    }
  }
  return values;
}

function hasFreshCredentialInput(
  entry: ConnectorCatalogEntry,
  values: Record<string, unknown>,
): boolean {
  if (entry.auth_kind === "personal_token") {
    return Boolean(String(values.token ?? "").trim());
  }
  if (entry.auth_kind === "oauth2") {
    if (entry.kind === "qcc") {
      const apiKey = String(values.api_key ?? "").trim();
      if (apiKey) return true;
    }
    const token = String(values.access_token ?? "").trim();
    return Boolean(token && token !== "__configured__");
  }
  if (entry.auth_kind === "auth_code") {
    return Boolean(String(values.auth_code ?? "").trim());
  }
  if (entry.auth_kind === "api_key") {
    if (entry.kind === "feishu-cli") {
      return Boolean(String(values.app_secret ?? "").trim());
    }
    if (entry.kind === "wecom-cli") {
      return Boolean(String(values.bot_secret ?? "").trim());
    }
    return Boolean(String(values.api_key ?? "").trim());
  }
  if (entry.auth_kind === "imap_app_password") {
    return Boolean(String(values.password ?? "").trim());
  }
  if (entry.auth_kind === "api_credentials") {
    return Boolean(String(values.secret_key ?? "").trim());
  }
  if (entry.auth_kind === "custom_fields") {
    return (entry.credential_fields ?? []).some(
      (field) =>
        field.secret && Boolean(String(values[field.key] ?? "").trim()),
    );
  }
  return false;
}

function customCredentialConfigChanged(
  entry: ConnectorCatalogEntry,
  values: Record<string, unknown>,
  preview: ConnectorCredentialsPreview,
): boolean {
  if (entry.auth_kind !== "custom_fields") return false;
  return (entry.credential_fields ?? []).some((field) => {
    if (field.secret) return false;
    const current = String(values[field.key] ?? "").trim();
    const storedValue = preview[field.key];
    const stored = Array.isArray(storedValue)
      ? storedValue.join(", ")
      : String(storedValue ?? "").trim();
    return current !== stored;
  });
}

function openAuthorizeLabel(
  kind: string,
  t: (key: string, fallback: string) => string,
): string {
  if (kind === "tencent-ima") {
    return t("connectors.openAuthorizePage", "打开授权页");
  }
  return t("connectors.openTokenPage", "打开授权页");
}

function authCodeGuideLabel(
  kind: string,
  t: (key: string, fallback: string) => string,
): string {
  if (kind === "tencent-news") {
    return t("connectors.newsAuthGuide", "如何获取腾讯新闻 API Key");
  }
  return t("connectors.authCodeDoc", "查看如何获取授权码");
}

function secretFieldRules(required: boolean) {
  const trimRule = {
    validator: (_: unknown, value: unknown) => {
      const text = String(value ?? "").trim();
      if (required && !text) {
        return Promise.reject(new Error(""));
      }
      return Promise.resolve();
    },
  };
  return required ? [{ required: true, message: "" }, trimRule] : [trimRule];
}

function configuredExtra(
  preview: ConnectorCredentialsPreview | undefined,
  key: string,
  t: (key: string, fallback: string) => string,
) {
  if (!preview?.[key]) return undefined;
  return t("connectors.secretConfigured", "已配置，留空表示不修改");
}

function isHostCliConnector(kind: string): boolean {
  return ["feishu-cli", "wecom-cli", "agently-cli"].includes(kind);
}

function ConnectorConfigDrawer({
  open,
  entry,
  instance,
  onClose,
  onSaved,
}: {
  open: boolean;
  entry: ConnectorCatalogEntry | null;
  instance: ConnectorInstance | null;
  onClose: () => void;
  onSaved: (created?: ConnectorInstance) => void;
}) {
  const { t } = useTranslation();
  const user = useCurrentUser();
  const canInstallCli = userCan(user, "connectors");
  const [form] = Form.useForm();
  const [saving, setSaving] = useState(false);
  const [probing, setProbing] = useState(false);
  const [authorizing, setAuthorizing] = useState(false);
  const [openingAuthorize, setOpeningAuthorize] = useState(false);
  const [showManual, setShowManual] = useState(false);
  const [authInfo, setAuthInfo] = useState<ConnectorAuthInfo | null>(null);
  const [instanceDetail, setInstanceDetail] =
    useState<ConnectorInstanceDetail | null>(null);
  const [probeResult, setProbeResult] = useState<
    { name: string; description: string }[] | null
  >(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [cliInfo, setCliInfo] = useState<ConnectorCliInstallResult | null>(
    null,
  );
  const [installingCli, setInstallingCli] = useState(false);
  const [detectingLocalWeKnora, setDetectingLocalWeKnora] = useState(false);
  const [feishuUserAuth, setFeishuUserAuth] =
    useState<FeishuUserAuthStartResult | null>(null);
  const [feishuUserAuthBusy, setFeishuUserAuthBusy] = useState(false);
  const [feishuUserReady, setFeishuUserReady] = useState(false);
  const [feishuAuthNeedsReauth, setFeishuAuthNeedsReauth] = useState(false);
  const [feishuRefreshExpiresAt, setFeishuRefreshExpiresAt] = useState<
    string | null
  >(null);

  const hasStoredCredentials = Boolean(
    instanceDetail?.has_credentials ?? instance?.has_credentials,
  );
  const mailProvider = Form.useWatch("mail_provider", form) ?? "qq";
  const defaultOpen = Form.useWatch("default_open", form) === true;
  const selectedMailProvider = mailProviderById(String(mailProvider));
  const draftScope = entry
    ? instance
      ? `connector:${instance.instance_id}`
      : `connector:new:${entry.kind}`
    : "";
  const restoringDraftRef = useRef(false);

  const applyConnectorDraft = useCallback(() => {
    if (!draftScope) return;
    const draft = loadFormDraft(draftScope);
    if (!draft) return;
    restoringDraftRef.current = true;
    form.setFieldsValue(draft);
    restoringDraftRef.current = false;
  }, [draftScope, form]);

  useEffect(() => {
    if (!open || !entry) return;
    setShowManual(false);
    setAuthInfo(null);
    setInstanceDetail(null);
    setProbeResult(null);
    setCliInfo(null);
    setFeishuUserAuth(null);
    setFeishuUserReady(false);
    setFeishuAuthNeedsReauth(false);
    setFeishuRefreshExpiresAt(null);
    form.resetFields();
    form.setFieldsValue({
      display_name: entry.name,
      description: entry.description,
      default_open: false,
      shared: false,
    });

    void connectorsApi
      .authInfo(entry.kind)
      .then(setAuthInfo)
      .catch(() => {
        setAuthInfo({
          authorize_url: entry.quick_auth_url ?? null,
          login_url: entry.login_url ?? null,
          guide_url: entry.guide_url ?? entry.doc_url ?? null,
          manual_url:
            entry.manual_url ?? entry.guide_url ?? entry.doc_url ?? null,
          auth_hint: entry.auth_hint ?? null,
        });
      });

    if (isHostCliConnector(entry.kind)) {
      void connectorsApi
        .cliStatus(entry.kind)
        .then(setCliInfo)
        .catch(() => {
          setCliInfo(null);
        });
    }

    if (instance) {
      setLoadingDetail(true);
      void connectorsApi
        .getInstance(instance.instance_id)
        .then((detail) => {
          setInstanceDetail(detail);
          form.setFieldsValue(previewToFormValues(entry, detail));
          if (detail.credentials_preview?.oauth_configured) {
            setShowManual(false);
          }
          if (detail.credentials_preview?.user_auth_configured) {
            const needs =
              detail.credentials_preview.user_auth_needs_reauth === true ||
              detail.credentials_preview.user_auth_valid === false;
            setFeishuAuthNeedsReauth(needs);
            setFeishuUserReady(!needs);
            setFeishuRefreshExpiresAt(
              detail.credentials_preview.user_refresh_expires_at ?? null,
            );
          }
          applyConnectorDraft();
        })
        .catch(() => {
          form.setFieldsValue({
            display_name: instance.display_name || entry.name,
            description: instance.description || entry.description,
            default_open: instance.default_open === true,
          });
          applyConnectorDraft();
        })
        .finally(() => setLoadingDetail(false));
    } else {
      applyConnectorDraft();
    }
  }, [open, entry, instance, form, applyConnectorDraft]);

  const openUrl = (url: string | null | undefined) => {
    if (!url) return;
    window.open(url, "octop-connector-auth", "width=720,height=800");
  };

  /** Open sync under the click gesture so popup blockers don't swallow async opens. */
  const openAuthPopupPlaceholder = (): Window | null => {
    const popup = window.open(
      "about:blank",
      "octop-connector-auth",
      "width=720,height=800",
    );
    if (popup) {
      try {
        popup.document.title = "Feishu Auth";
        popup.document.body.innerHTML =
          '<p style="font:14px/1.5 system-ui;padding:24px;color:#666">Loading…</p>';
      } catch {
        // Cross-origin / closed — ignore.
      }
    }
    return popup;
  };

  const navigateAuthPopup = (
    popup: Window | null,
    url: string | null | undefined,
  ) => {
    if (!url) return;
    if (popup && !popup.closed) {
      try {
        popup.location.replace(url);
        popup.focus();
        return;
      } catch {
        // Fall through to a fresh open.
      }
    }
    openUrl(url);
  };

  const handleOpenAuthorize = async () => {
    if (!entry) return;
    setOpeningAuthorize(true);
    try {
      const { authorize_url } = await connectorsApi.authorizeUrl(entry.kind);
      if (!authorize_url) {
        message.error(t("connectors.authUrlMissing", "无法获取授权页地址"));
        return;
      }
      openUrl(authorize_url);
    } catch (e) {
      console.error(e);
      message.error(
        apiErrorMessage(e, t("connectors.authUrlFailed", "打开授权页失败"), t),
      );
    } finally {
      setOpeningAuthorize(false);
    }
  };

  const handleOpenLogin = () => {
    openUrl(authInfo?.login_url);
  };

  const handleCopyInstallCommand = async (command: string) => {
    const ok = await copyText(command);
    if (ok) {
      message.success(t("connectors.cliInstallCopied", "安装命令已复制"));
    } else {
      message.error(
        t("connectors.clipboardDenied", "无法读取剪贴板，请手动粘贴"),
      );
    }
  };

  const handleRefreshCliStatus = async () => {
    if (!entry || !isHostCliConnector(entry.kind)) return;
    try {
      const status = await connectorsApi.cliStatus(entry.kind);
      setCliInfo(status);
      if (status.installed) {
        message.success(
          t("connectors.cliAlreadyInstalled", {
            binary: status.binary,
            defaultValue: `${status.binary} 已安装`,
          }),
        );
      }
    } catch (e) {
      console.error(e);
      message.error(
        apiErrorMessage(
          e,
          t("connectors.cliInstallFailed", "主机 CLI 安装失败"),
          t,
        ),
      );
    }
  };

  const handleInstallCli = async () => {
    if (!entry || !isHostCliConnector(entry.kind) || installingCli) return;
    if (cliInfo?.installed) {
      await handleRefreshCliStatus();
      return;
    }
    setInstallingCli(true);
    try {
      const result = await connectorsApi.installCli(entry.kind);
      setCliInfo(result);
      if (result.ok) {
        message.success(
          result.already_installed
            ? t("connectors.cliAlreadyInstalled", {
                binary: result.binary,
                defaultValue: `${result.binary} 已安装`,
              })
            : t("connectors.cliInstallSuccess", {
                binary: result.binary,
                defaultValue: `${result.binary} 安装成功`,
              }),
        );
      } else {
        message.error(
          result.error ?? t("connectors.cliInstallFailed", "主机 CLI 安装失败"),
        );
      }
    } catch (e) {
      console.error(e);
      message.error(
        apiErrorMessage(
          e,
          t("connectors.cliInstallFailed", "主机 CLI 安装失败"),
          t,
        ),
      );
    } finally {
      setInstallingCli(false);
    }
  };

  const handleFeishuUserAuthStart = async () => {
    if (!entry || entry.kind !== "feishu-cli" || feishuUserAuthBusy) return;
    const popup = openAuthPopupPlaceholder();
    setFeishuUserAuthBusy(true);
    try {
      let started: FeishuUserAuthStartResult;
      if (instance?.instance_id && hasStoredCredentials) {
        started = await connectorsApi.feishuUserAuthStartInstance(
          instance.instance_id,
        );
      } else {
        try {
          await form.validateFields(["app_id", "app_secret"]);
        } catch {
          popup?.close();
          message.warning(
            t(
              "connectors.feishuUserAuthNeedApp",
              "请先填写 App ID 与 App Secret",
            ),
          );
          return;
        }
        const values = form.getFieldsValue();
        const app_id = String(values.app_id ?? "").trim();
        const app_secret = String(values.app_secret ?? "").trim();
        if (!app_id || !app_secret) {
          popup?.close();
          message.warning(
            t(
              "connectors.feishuUserAuthNeedApp",
              "请先填写 App ID 与 App Secret",
            ),
          );
          return;
        }
        started = await connectorsApi.feishuUserAuthStart({
          app_id,
          app_secret,
          cli_config_key:
            String(values.cli_config_key ?? "").trim() || undefined,
        });
      }
      form.setFieldsValue({ cli_config_key: started.cli_config_key });
      setFeishuUserAuth(started);
      setFeishuUserReady(false);
      navigateAuthPopup(popup, started.verification_url);
      message.success(
        t(
          "connectors.feishuUserAuthStarted",
          "已打开授权页，完成后点「我已授权」",
        ),
      );
    } catch (e) {
      popup?.close();
      console.error(e);
      message.error(
        apiErrorMessage(e, t("connectors.feishuUserAuthFailed", "授权失败"), t),
      );
    } finally {
      setFeishuUserAuthBusy(false);
    }
  };

  const handleFeishuUserAuthComplete = async () => {
    if (!entry || entry.kind !== "feishu-cli" || !feishuUserAuth) return;
    setFeishuUserAuthBusy(true);
    try {
      let done;
      if (instance?.instance_id && hasStoredCredentials) {
        done = await connectorsApi.feishuUserAuthCompleteInstance(
          instance.instance_id,
          {
            device_code: feishuUserAuth.device_code,
            cli_config_key: feishuUserAuth.cli_config_key,
          },
        );
      } else {
        const values = form.getFieldsValue();
        const app_id = String(values.app_id ?? "").trim();
        const app_secret = String(values.app_secret ?? "").trim();
        const cli_config_key = String(
          values.cli_config_key ?? feishuUserAuth.cli_config_key ?? "",
        ).trim();
        if (!app_id || !app_secret || !cli_config_key) {
          message.warning(
            t(
              "connectors.feishuUserAuthNeedApp",
              "请先填写 App ID 与 App Secret",
            ),
          );
          return;
        }
        done = await connectorsApi.feishuUserAuthComplete({
          app_id,
          app_secret,
          device_code: feishuUserAuth.device_code,
          cli_config_key,
        });
      }
      form.setFieldsValue({
        default_as: "user",
        cli_config_key: done.cli_config_key,
      });
      setFeishuUserReady(true);
      setFeishuAuthNeedsReauth(false);
      setFeishuUserAuth(null);
      const persisted = Boolean(instance?.instance_id) && hasStoredCredentials;
      if (done.warning || done.search_docs_scope === false) {
        message.warning(
          done.warning ||
            t(
              "connectors.feishuUserAuthWarning",
              "已登录，但文档搜索权限可能未开通，请检查开放平台权限后重新授权",
            ),
        );
      } else {
        message.success(
          persisted
            ? t("connectors.feishuUserAuthSuccessSaved", "授权完成")
            : t("connectors.feishuUserAuthSuccess", "授权完成，请保存连接器"),
        );
      }
    } catch (e) {
      console.error(e);
      message.error(
        apiErrorMessage(e, t("connectors.feishuUserAuthFailed", "授权失败"), t),
      );
    } finally {
      setFeishuUserAuthBusy(false);
    }
  };

  const extractPastedCredential = (text: string): string => {
    const trimmed = text.trim();
    try {
      const url = new URL(trimmed);
      const fromQuery =
        url.searchParams.get("code") ??
        url.searchParams.get("access_token") ??
        url.searchParams.get("token");
      if (fromQuery) return fromQuery;
    } catch {
      // not a full URL
    }
    const match = trimmed.match(/access_token=([^&\s#]+)/i);
    if (match?.[1]) {
      try {
        return decodeURIComponent(match[1]);
      } catch {
        return match[1];
      }
    }
    const mcpMatch = trimmed.match(/mcp_token=([^\s;,&"']+)/i);
    if (mcpMatch?.[1]) {
      return mcpMatch[1];
    }
    return trimmed;
  };

  const handlePasteToken = async () => {
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) {
        message.warning(t("connectors.clipboardEmpty", "剪贴板为空"));
        return;
      }
      if (entry?.auth_kind === "personal_token") {
        form.setFieldValue("token", extractPastedCredential(text));
      } else if (entry?.auth_kind === "auth_code") {
        form.setFieldValue("auth_code", text);
      } else if (entry?.auth_kind === "api_key") {
        form.setFieldValue("api_key", text);
      }
      message.success(t("connectors.pasteSuccess", "已粘贴"));
    } catch {
      message.error(
        t("connectors.clipboardDenied", "无法读取剪贴板，请手动粘贴"),
      );
    }
  };

  const handleGuidedPaste = async () => {
    if (!entry || !isGuidedConnector(entry.kind)) return;
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) {
        message.warning(t("connectors.clipboardEmpty", "剪贴板为空"));
        return;
      }
      const pastedUrl = extractHttpUrl(text);
      if (entry.kind === "dify") {
        if (!pastedUrl) {
          message.warning(
            t("connectors.difyPasteUrlRequired", "剪贴板中没有 MCP URL"),
          );
          return;
        }
        form.setFieldValue("mcp_url", pastedUrl);
        await form.validateFields(["mcp_url"]);
      } else if (pastedUrl) {
        form.setFieldValue("base_url", pastedUrl);
      } else {
        form.setFieldValue("api_key", text);
      }
      saveFormDraft(
        draftScope,
        form.getFieldsValue() as Record<string, unknown>,
      );
      message.success(t("connectors.pasteSuccess", "已粘贴"));
    } catch (error) {
      if (error && typeof error === "object" && "errorFields" in error) {
        message.warning(
          t(
            "connectors.difyMcpUrlInvalid",
            "请粘贴 Dify 访问点提供的完整 MCP Server URL",
          ),
        );
        return;
      }
      message.error(
        t("connectors.clipboardDenied", "无法读取剪贴板，请手动粘贴"),
      );
    }
  };

  const handleDetectLocalWeKnora = async () => {
    if (detectingLocalWeKnora) return;
    setDetectingLocalWeKnora(true);
    try {
      const result = await connectorsApi.detectLocalWeKnora();
      if (!result.found || !result.base_url) {
        message.warning(
          t(
            "connectors.weknoraNotFound",
            "未在 OCTOP 主机的 127.0.0.1:8080 检测到 WeKnora",
          ),
        );
        return;
      }
      form.setFieldValue("base_url", result.base_url);
      saveFormDraft(
        draftScope,
        form.getFieldsValue() as Record<string, unknown>,
      );
      message.success(
        t("connectors.weknoraFound", "已检测到本机 WeKnora 并填入地址"),
      );
    } catch (error) {
      console.error(error);
      message.error(
        apiErrorMessage(
          error,
          t("connectors.weknoraDetectFailed", "检测本机 WeKnora 失败"),
          t,
        ),
      );
    } finally {
      setDetectingLocalWeKnora(false);
    }
  };

  const handleOAuth = async () => {
    if (!entry || authorizing) return;
    const popup = window.open("", "octop-oauth", "width=520,height=720");
    if (!popup) {
      message.error(
        t(
          "connectors.oauthPopupBlocked",
          "授权窗口被浏览器拦截，请允许本站弹出窗口后重试",
        ),
      );
      return;
    }

    setAuthorizing(true);
    let settled = false;
    let pollTimer: ReturnType<typeof setInterval> | undefined;
    let timeoutTimer: ReturnType<typeof setTimeout> | undefined;
    let stateId = "";

    const cleanup = () => {
      if (pollTimer !== undefined) clearInterval(pollTimer);
      if (timeoutTimer !== undefined) clearTimeout(timeoutTimer);
      window.removeEventListener("message", onMessage);
    };

    const finishWithTokens = async (tokens: Record<string, unknown>) => {
      if (settled) return;
      settled = true;
      cleanup();
      try {
        popup.close();
      } catch {
        // ignore
      }
      try {
        const values = form.getFieldsValue();
        const credentials: Record<string, unknown> = {};
        if (tokens.access_token) credentials.access_token = tokens.access_token;
        if (tokens.refresh_token)
          credentials.refresh_token = tokens.refresh_token;
        if (tokens.expires_at) credentials.expires_at = tokens.expires_at;
        if (tokens.oauth_client_id)
          credentials.oauth_client_id = tokens.oauth_client_id;
        if (tokens.oauth_client_secret)
          credentials.oauth_client_secret = tokens.oauth_client_secret;
        if (tokens.openid) credentials.openid = tokens.openid;

        if (!credentials.access_token) {
          message.error(t("connectors.oauthFailed", "获取授权结果失败"));
          return;
        }

        if (instance) {
          await connectorsApi.patchInstance(instance.instance_id, {
            display_name: String(values.display_name || entry.name),
            description: String(values.description || entry.description),
            credentials,
            default_open: values.default_open === true,
            shared: values.shared === true,
          });
        } else {
          await connectorsApi.createInstance({
            kind: entry.kind,
            display_name: String(values.display_name || entry.name),
            description: String(values.description || entry.description),
            credentials,
            default_open: values.default_open === true,
            shared: values.shared === true,
          });
        }
        clearFormDraft(draftScope);
        message.success(t("connectors.createSuccess", "连接器已创建"));
        onSaved();
        onClose();
      } catch (e) {
        console.error(e);
        form.setFieldsValue({
          display_name: entry.name,
          description: entry.description,
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          expires_at: tokens.expires_at,
          oauth_client_id: tokens.oauth_client_id,
          oauth_client_secret: tokens.oauth_client_secret,
          openid: tokens.openid,
        });
        message.error(
          apiErrorMessage(e, t("connectors.createFailed", "创建失败"), t),
        );
      } finally {
        setAuthorizing(false);
      }
    };

    const claimPending = async () => {
      if (settled || !stateId) return;
      try {
        const pending = await connectorsApi.oauthPending(stateId);
        await finishWithTokens(pending.tokens ?? {});
      } catch {
        // Pending not ready yet (404) — keep polling.
      }
    };

    const onMessage = (ev: MessageEvent) => {
      if (ev.origin !== window.location.origin) return;
      if (ev.data?.type !== "octop:connector-oauth") return;
      if (ev.data.state_id !== stateId) return;
      void claimPending();
    };

    try {
      const { authorize_url, state_id } = await connectorsApi.oauthStart(
        { type: "catalog", kind: entry.kind },
        "/connectors",
      );
      stateId = state_id;
      window.addEventListener("message", onMessage);
      // Ardot (and some IdPs) set COOP so window.opener is null after redirect;
      // poll pending so the parent still claims tokens without postMessage.
      pollTimer = setInterval(() => {
        void claimPending();
      }, 1500);
      timeoutTimer = setTimeout(
        () => {
          if (settled) return;
          settled = true;
          cleanup();
          try {
            popup.close();
          } catch {
            // ignore
          }
          setAuthorizing(false);
          message.error(
            t("connectors.oauthTimedOut", "授权超时，请重试一键授权"),
          );
        },
        5 * 60 * 1000,
      );
      popup.location.replace(authorize_url);
    } catch (e) {
      cleanup();
      try {
        popup.close();
      } catch {
        // ignore
      }
      console.error(e);
      message.error(
        apiErrorMessage(e, t("connectors.oauthStartFailed", "无法启动 OAuth")),
      );
      setAuthorizing(false);
    }
  };

  const handleProbe = async () => {
    if (!entry) return;
    const values = form.getFieldsValue();
    const preview = instanceDetail?.credentials_preview ?? {};
    const freshSecret = hasFreshCredentialInput(entry, values);
    const feishuAppIdChanged =
      entry.kind === "feishu-cli" &&
      Boolean(preview.app_id) &&
      String(values.app_id ?? "").trim() !==
        String(preview.app_id ?? "").trim();
    const wecomBotIdChanged =
      entry.kind === "wecom-cli" &&
      Boolean(preview.bot_id) &&
      String(values.bot_id ?? "").trim() !==
        String(preview.bot_id ?? "").trim();
    const customConfigChanged = customCredentialConfigChanged(
      entry,
      values,
      preview,
    );
    const customHasStoredSecret = (entry.credential_fields ?? []).some(
      (field) => field.secret && preview[`${field.key}_configured`] === true,
    );
    const identityChanged =
      feishuAppIdChanged || wecomBotIdChanged || customConfigChanged;
    if (
      identityChanged &&
      !freshSecret &&
      (entry.auth_kind !== "custom_fields" || customHasStoredSecret)
    ) {
      message.warning(
        entry.kind === "feishu-cli"
          ? t(
              "connectors.probeNeedSecretAfterAppIdChange",
              "App ID 已修改，请填写 App Secret 后再探测",
            )
          : entry.kind === "wecom-cli"
          ? t(
              "connectors.probeNeedSecretAfterBotIdChange",
              "Bot ID 已修改，请填写 Secret 后再探测",
            )
          : t(
              "connectors.probeNeedSecretAfterConfigChange",
              "连接配置已修改，请重新填写密钥后再探测",
            ),
      );
      return;
    }
    const freshInput = freshSecret || identityChanged;
    // Only reuse saved creds when the form still matches the stored identity.
    const canUseStored = hasStoredCredentials && instance && !freshInput;

    if (!canUseStored) {
      try {
        await form.validateFields();
      } catch {
        message.warning(
          t("connectors.probeNeedConfig", "请先填写连接配置后再探测"),
        );
        return;
      }
    }

    setProbing(true);
    setProbeResult(null);
    try {
      const r = canUseStored
        ? await connectorsApi.testInstance(instance.instance_id)
        : await connectorsApi.testCredentials({
            kind: entry.kind,
            credentials: buildCredentials(entry, values),
          });
      if (r.ok) {
        const tools = r.tools ?? [];
        setProbeResult(tools);
        if (canUseStored) {
          message.success(
            t(
              "connectors.probeUsedStoredCredentials",
              "探测通过（使用已保存的凭证）",
            ),
          );
        }
      } else {
        setProbeResult(null);
        message.error(r.error ?? t("connectors.probeFailed", "探测失败"));
      }
    } catch (e) {
      console.error(e);
      message.error(
        apiErrorMessage(e, t("connectors.probeFailed", "探测失败"), t),
      );
    } finally {
      setProbing(false);
    }
  };

  const handleSubmit = async () => {
    if (!entry) return;
    try {
      await form.validateFields();
    } catch {
      return;
    }
    const values = form.getFieldsValue();
    if (entry.auth_kind === "oauth2") {
      const token = String(values.access_token ?? "").trim();
      const apiKey =
        entry.kind === "qcc" ? String(values.api_key ?? "").trim() : "";
      if (!hasStoredCredentials && !token && !apiKey) {
        message.warning(
          entry.kind === "qcc"
            ? t(
                "connectors.qccNeedAuthOrKey",
                "请先完成一键授权，或填写 API Key",
              )
            : t("connectors.oauthNeedToken", "请先完成授权或手动填写 Token"),
        );
        return;
      }
    }
    setSaving(true);
    try {
      const payload = buildCredentials(entry, values);
      if (instance) {
        await connectorsApi.patchInstance(instance.instance_id, {
          display_name: values.display_name as string,
          description: values.description as string,
          credentials: payload,
          default_open: values.default_open === true,
          shared: values.shared === true,
        });
      } else {
        const created = await connectorsApi.createInstance({
          kind: entry.kind,
          display_name: values.display_name as string,
          description: values.description as string,
          credentials: payload,
          default_open: values.default_open === true,
          shared: values.shared === true,
        });
        if (entry.kind === "agently-cli") {
          clearFormDraft(draftScope);
          message.success(t("connectors.createSuccess", "连接器已创建"));
          onSaved(created);
          return;
        }
      }
      message.success(
        instance
          ? t("connectors.saveSuccess", "连接器已保存")
          : t("connectors.createSuccess", "连接器已创建"),
      );
      clearFormDraft(draftScope);
      onSaved();
      onClose();
    } catch (e) {
      console.error(e);
      message.error(
        apiErrorMessage(e, t("connectors.createFailed", "创建失败"), t),
      );
    } finally {
      setSaving(false);
    }
  };

  if (!entry) return null;

  const hasOAuthPopup =
    entry.auth_kind === "oauth2" &&
    entry.oauth_ready &&
    oauthCallbackSupported();
  const hasAuthorizeUrl = Boolean(authInfo?.authorize_url);
  const hasLoginUrl = Boolean(authInfo?.login_url);
  const guideUrl = authInfo?.guide_url ?? entry.guide_url ?? entry.doc_url;
  const manualUrl = authInfo?.manual_url ?? entry.manual_url ?? guideUrl;
  const catalogAuthHint = authInfo?.auth_hint ?? entry.auth_hint;
  const authHint =
    entry.kind === "qcc" && !hasOAuthPopup
      ? t(
          "connectors.qccApiKeyOnlyHint",
          "当前环境无法完成 OAuth 回调。请打开授权页获取 API Key，粘贴后探测并保存。",
        )
      : catalogAuthHint;
  const guidedKind = isGuidedConnector(entry.kind) ? entry.kind : null;

  const preview = instanceDetail?.credentials_preview;
  const secretRequired = !hasStoredCredentials;
  const hideTopAuth = entry
    ? INLINE_CREDENTIAL_GUIDE_KINDS.has(entry.kind)
    : false;
  const hideFieldGuide = entry
    ? HIDE_INLINE_FIELD_GUIDE_KINDS.has(entry.kind)
    : false;
  const hideGuideLink =
    hideTopAuth ||
    Boolean(entry?.quick_auth_url && guideUrl === entry.quick_auth_url);

  return (
    <Drawer
      title={
        instance
          ? t("connectors.editConnection", {
              name: entry.name,
              defaultValue: `编辑 ${entry.name} 连接器`,
            })
          : t("connectors.createConnection", {
              name: entry.name,
              defaultValue: `创建 ${entry.name} 连接器`,
            })
      }
      open={open}
      onClose={onClose}
      width={440}
      destroyOnHidden
      footer={
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
          <Button onClick={onClose}>{t("common.cancel")}</Button>
          <Button
            icon={<Activity size={14} />}
            loading={probing}
            disabled={entry.kind === "agently-cli" && !hasStoredCredentials}
            onClick={() => void handleProbe()}
          >
            {t("connectors.probe", "探测")}
          </Button>
          <Button
            type="primary"
            loading={saving}
            onClick={() => void handleSubmit()}
          >
            {t("common.save")}
          </Button>
        </div>
      }
    >
      <div className={styles.drawerBody}>
        {loadingDetail ? (
          <div className={styles.drawerLoading}>
            <Spin size="small" />
          </div>
        ) : null}

        {authHint && <div className={styles.authHint}>{authHint}</div>}

        {entry.kind === "agently-cli" && (
          <>
            <Alert
              type="warning"
              showIcon
              message={t(
                "connectors.agentlySafety",
                "发送、回复、转发和删除邮件需先预览，再由用户确认执行。邮件正文与附件属于不可信外部内容，不能作为执行指令。",
              )}
            />
            <p className={styles.authHint}>
              {t(
                "connectors.agentlyQuota",
                "参考配额：每日发送 50 封、每小时 200 次请求、每分钟 10 次请求；附件最多 50 个、总容量 20 MB，此连接器单文件上限 10 MB。以账户实际配额及服务最新限制为准。可在任务页选择「Agent Mail 新邮件」触发任务。",
              )}
            </p>
            <p className={styles.authHint}>
              {t(
                "connectors.agentlyInstanceHint",
                "先保存连接器，再登录授权。每个实例独立保存邮箱授权，可为不同 Agent 选择不同实例。",
              )}
            </p>
          </>
        )}

        {guidedKind && (
          <div className={styles.guidedSetup}>
            <div className={styles.guidedSetupTitle}>
              {t("connectors.guidedSetup", "快速接入")}
            </div>
            {guidedKind === "weknora" ? (
              <ol>
                <li>
                  {t("connectors.weknoraStep1", "打开 WeKnora 并创建 API Key")}
                </li>
                <li>
                  {t(
                    "connectors.weknoraStep2",
                    "检测本机服务，或手动填写部署地址",
                  )}
                </li>
                <li>
                  {t("connectors.guidedStepProbe", "粘贴凭证后探测并保存")}
                </li>
              </ol>
            ) : (
              <ol>
                <li>
                  {t("connectors.difyStep1", "在 Dify 中发布应用或工作流")}
                </li>
                <li>
                  {t(
                    "connectors.difyStep2",
                    "在访问点启用 MCP 并复制完整 Server URL",
                  )}
                </li>
                <li>
                  {t("connectors.guidedStepProbe", "粘贴凭证后探测并保存")}
                </li>
              </ol>
            )}
          </div>
        )}

        {guideUrl && !hideGuideLink && (
          <div className={styles.guideLinks}>
            <a href={guideUrl} target="_blank" rel="noreferrer">
              {t("connectors.viewGuide", "查看获取说明")}
            </a>
          </div>
        )}

        <div className={styles.quickAuthBar}>
          {guidedKind && (
            <>
              {guidedKind === "weknora" && (
                <Button
                  icon={<RefreshCw size={14} />}
                  loading={detectingLocalWeKnora}
                  onClick={() => void handleDetectLocalWeKnora()}
                >
                  {t("connectors.detectLocal", "检测本机服务")}
                </Button>
              )}
              <Button
                icon={<ClipboardPaste size={14} />}
                onClick={() => void handleGuidedPaste()}
              >
                {guidedKind === "dify"
                  ? t("connectors.pasteMcpUrl", "粘贴 MCP 地址")
                  : t("connectors.smartPaste", "智能粘贴")}
              </Button>
            </>
          )}
          {entry && isHostCliConnector(entry.kind) && (
            <>
              {canInstallCli && (
                <Button
                  type={cliInfo?.installed ? "default" : "primary"}
                  icon={
                    cliInfo?.installed ? (
                      <CheckCircle2 size={14} />
                    ) : (
                      <Download size={14} />
                    )
                  }
                  loading={installingCli}
                  onClick={() => void handleInstallCli()}
                >
                  {cliInfo?.installed
                    ? t("connectors.cliReady", "CLI 已就绪")
                    : t("connectors.installCli", "安装 CLI")}
                </Button>
              )}
              {!canInstallCli && cliInfo?.installed && (
                <Button
                  type="default"
                  icon={<CheckCircle2 size={14} />}
                  disabled
                >
                  {t("connectors.cliReady", "CLI 已就绪")}
                </Button>
              )}
              {!canInstallCli && !cliInfo?.installed && (
                <span className={styles.feishuUserAuthHint}>
                  {t(
                    "connectors.cliInstallAdminOnly",
                    "主机 CLI 需管理员安装；可复制命令交给管理员执行",
                  )}
                </span>
              )}
              {(cliInfo?.install_command ||
                entry.kind === "feishu-cli" ||
                entry.kind === "wecom-cli") && (
                <Button
                  icon={<Copy size={14} />}
                  onClick={() =>
                    void handleCopyInstallCommand(
                      cliInfo?.install_command ??
                        (entry.kind === "feishu-cli"
                          ? "npm install -g @larksuite/cli"
                          : "npm install -g @wecom/cli"),
                    )
                  }
                >
                  {t("connectors.copyInstallCommand", "复制安装命令")}
                </Button>
              )}
              {(cliInfo?.guide_url ||
                cliInfo?.doc_url ||
                entry.guide_url ||
                entry.doc_url) && (
                <Button
                  icon={<ExternalLink size={14} />}
                  onClick={() =>
                    openUrl(
                      cliInfo?.guide_url ||
                        entry.guide_url ||
                        cliInfo?.doc_url ||
                        entry.doc_url,
                    )
                  }
                >
                  {t("connectors.openCliDocs", "安装文档")}
                </Button>
              )}
            </>
          )}
          {hasOAuthPopup && (
            <Button
              type="primary"
              icon={<Sparkles size={14} />}
              loading={authorizing}
              onClick={() => void handleOAuth()}
            >
              {t("connectors.oneClickOAuth", "一键授权")}
            </Button>
          )}
          {hasAuthorizeUrl && !hideTopAuth && !hasOAuthPopup && (
            <Button
              type="primary"
              icon={<ExternalLink size={14} />}
              loading={openingAuthorize}
              onClick={() => void handleOpenAuthorize()}
            >
              {entry.kind === "qcc"
                ? t("connectors.qccOpenKeyPage", "打开授权页")
                : t("connectors.openAuthorizePage", "打开授权页")}
            </Button>
          )}
          {hasOAuthPopup && entry.kind === "qcc" && hasAuthorizeUrl && (
            <Button
              icon={<ExternalLink size={14} />}
              loading={openingAuthorize}
              onClick={() => void handleOpenAuthorize()}
            >
              {t("connectors.qccOpenKeyPage", "打开授权页")}
            </Button>
          )}
          {hasLoginUrl && !hideTopAuth && (
            <Button icon={<ExternalLink size={14} />} onClick={handleOpenLogin}>
              {t("connectors.openLoginPage", "打开登录页")}
            </Button>
          )}
          {!hideTopAuth &&
            !hasAuthorizeUrl &&
            !hasLoginUrl &&
            entry.quick_auth_url &&
            entry.auth_kind !== "oauth2" && (
              <Button
                type="primary"
                icon={<ExternalLink size={14} />}
                loading={openingAuthorize}
                onClick={() => void handleOpenAuthorize()}
              >
                {openAuthorizeLabel(entry.kind, t)}
              </Button>
            )}
          {(entry.auth_kind === "personal_token" ||
            entry.auth_kind === "auth_code" ||
            (entry.auth_kind === "api_key" &&
              entry.kind !== "feishu-cli" &&
              entry.kind !== "wecom-cli")) && (
            <Button
              icon={<ClipboardPaste size={14} />}
              onClick={() => void handlePasteToken()}
            >
              {t("connectors.pasteFromClipboard", "从剪贴板粘贴")}
            </Button>
          )}
        </div>

        {entry && isHostCliConnector(entry.kind) && cliInfo && (
          <div
            className={
              cliInfo.ok === false || !cliInfo.installed
                ? styles.cliInstallHintError
                : styles.cliInstallHint
            }
          >
            {cliInfo.installed ? (
              <div>
                {t("connectors.cliInstalledHint", {
                  binary: cliInfo.binary,
                  version: cliInfo.version ?? "",
                  defaultValue: cliInfo.version
                    ? `主机已检测到 ${cliInfo.binary}（${cliInfo.version}）`
                    : `主机已检测到 ${cliInfo.binary}`,
                })}
              </div>
            ) : (
              <div>
                {cliInfo.error ??
                  t(
                    "connectors.cliMissingHint",
                    "主机尚未安装 CLI。可点击「安装 CLI」，或在 Octop 主机终端手动执行下方命令。",
                  )}
              </div>
            )}
            {(!cliInfo.installed || cliInfo.ok === false) &&
              cliInfo.install_command && (
                <code className={styles.cliInstallCommand}>
                  {cliInfo.install_command}
                </code>
              )}
            {(!cliInfo.installed || cliInfo.ok === false) && (
              <div className={styles.cliInstallLinks}>
                {(cliInfo.guide_url || entry.guide_url) && (
                  <a
                    href={cliInfo.guide_url || entry.guide_url || undefined}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {t("connectors.openCliDocs", "安装文档")}
                  </a>
                )}
                {(cliInfo.doc_url || entry.doc_url) && (
                  <a
                    href={cliInfo.doc_url || entry.doc_url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {t("connectors.openCliRepo", "项目主页")}
                  </a>
                )}
              </div>
            )}
          </div>
        )}

        {open && entry.kind === "agently-cli" && instance && (
          <AgentlyAuth
            key={instance.instance_id}
            instanceId={instance.instance_id}
            installed={cliInfo?.installed === true}
            onChanged={() => {
              void connectorsApi
                .getInstance(instance.instance_id)
                .then((detail) =>
                  setInstanceDetail((current) =>
                    current?.instance_id === detail.instance_id
                      ? detail
                      : current,
                  ),
                )
                .catch(() => undefined);
              onSaved();
            }}
          />
        )}

        <Form
          form={form}
          layout="vertical"
          onValuesChange={(_, all) => {
            if (!restoringDraftRef.current && draftScope) {
              saveFormDraft(
                draftScope,
                all as unknown as Record<string, unknown>,
              );
            }
          }}
        >
          <div className={styles.configSectionTitle}>
            {t("connectors.configSection", "连接配置")}
          </div>
          <Form.Item
            name="display_name"
            label={t("connectors.displayName", "显示名称")}
            rules={[{ required: true }]}
          >
            <Input placeholder={entry.name} />
          </Form.Item>
          <Form.Item
            name="description"
            label={t("connectors.description", "描述")}
            rules={[{ required: true }]}
          >
            <Input.TextArea
              rows={3}
              maxLength={500}
              showCount
              placeholder={entry.description}
            />
          </Form.Item>

          {entry.auth_kind === "custom_fields" &&
            (entry.credential_fields ?? []).map((field) => {
              const isSecret = field.secret || field.field_type === "password";
              const input = isSecret ? (
                <Input.Password
                  placeholder={
                    hasStoredCredentials && field.secret
                      ? t("connectors.secretPlaceholder", "留空表示不修改")
                      : field.placeholder ?? undefined
                  }
                />
              ) : (
                <Input placeholder={field.placeholder ?? undefined} />
              );
              return (
                <Form.Item
                  key={field.key}
                  name={field.key}
                  label={field.label}
                  rules={[
                    ...(isSecret
                      ? secretFieldRules(field.required && secretRequired)
                      : [{ required: field.required }]),
                    ...(entry.kind === "dify" && field.key === "mcp_url"
                      ? [
                          {
                            validator: (_: unknown, value: unknown) =>
                              !value || isDifyMcpServerUrl(String(value))
                                ? Promise.resolve()
                                : Promise.reject(
                                    new Error(
                                      t(
                                        "connectors.difyMcpUrlInvalid",
                                        "请粘贴 Dify 访问点提供的完整 MCP Server URL",
                                      ),
                                    ),
                                  ),
                          },
                        ]
                      : []),
                  ]}
                  extra={
                    configuredExtra(preview, `${field.key}_configured`, t) ??
                    field.help
                  }
                >
                  {input}
                </Form.Item>
              );
            })}

          {entry.auth_kind === "personal_token" && (
            <Form.Item
              name="token"
              label={t("connectors.token", "访问 Token")}
              rules={secretFieldRules(secretRequired)}
              extra={
                configuredExtra(preview, "token_configured", t) ??
                (!hideFieldGuide && manualUrl ? (
                  <a href={manualUrl} target="_blank" rel="noreferrer">
                    {t("connectors.getTokenAt", "前往获取 Token")}
                  </a>
                ) : !hideFieldGuide ? (
                  <a href={entry.doc_url} target="_blank" rel="noreferrer">
                    {t("connectors.getToken", "获取 Token")}
                  </a>
                ) : undefined)
              }
            >
              <Input.Password
                placeholder={hasStoredCredentials ? "••••••••" : undefined}
              />
            </Form.Item>
          )}

          {entry.auth_kind === "auth_code" && (
            <>
              <Form.Item
                name="auth_code"
                label={t("connectors.authCode", "授权码")}
                rules={secretFieldRules(secretRequired)}
                extra={
                  configuredExtra(preview, "auth_configured", t) ??
                  (!hideFieldGuide && entry.manual_url ? (
                    <a href={entry.manual_url} target="_blank" rel="noreferrer">
                      {authCodeGuideLabel(entry.kind, t)}
                    </a>
                  ) : !hideFieldGuide && manualUrl ? (
                    <a href={manualUrl} target="_blank" rel="noreferrer">
                      {authCodeGuideLabel(entry.kind, t)}
                    </a>
                  ) : undefined)
                }
              >
                <Input.Password
                  placeholder={
                    hasStoredCredentials
                      ? t("connectors.secretPlaceholder", "留空表示不修改")
                      : t("connectors.authCodePlaceholder", "粘贴授权码")
                  }
                />
              </Form.Item>
            </>
          )}

          {entry.kind === "feishu-cli" && (
            <>
              <Form.Item name="default_as" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="cli_config_key" hidden>
                <Input />
              </Form.Item>
              <Form.Item
                name="app_id"
                label={t("connectors.feishuAppId", "App ID")}
                rules={[{ required: true }]}
                extra={
                  !hideFieldGuide && manualUrl ? (
                    <a href={manualUrl} target="_blank" rel="noreferrer">
                      {t(
                        "connectors.feishuAppCredDoc",
                        "在飞书开放平台创建应用并获取 App ID / App Secret",
                      )}
                    </a>
                  ) : undefined
                }
              >
                <Input
                  placeholder={t(
                    "connectors.feishuAppIdPlaceholder",
                    "例如 cli_xxxxxxxx",
                  )}
                />
              </Form.Item>
              <Form.Item
                name="app_secret"
                label={t("connectors.feishuAppSecret", "App Secret")}
                rules={secretFieldRules(secretRequired)}
                extra={configuredExtra(preview, "app_secret_configured", t)}
              >
                <Input.Password
                  placeholder={
                    hasStoredCredentials
                      ? t("connectors.secretPlaceholder", "留空表示不修改")
                      : t(
                          "connectors.feishuAppSecretPlaceholder",
                          "飞书应用 App Secret",
                        )
                  }
                />
              </Form.Item>
              <div className={styles.feishuUserAuthBox}>
                <div className={styles.feishuUserAuthTitle}>
                  {t("connectors.feishuUserAuthTitle", "飞书账号授权")}
                </div>
                <p className={styles.feishuUserAuthWhy}>
                  {t(
                    "connectors.feishuUserAuthWhy",
                    "上方 App ID / Secret 只代表应用（Bot）。文档搜索、访问你云空间里的个人文档和日程等，必须以你的飞书账号身份调用，因此需要额外授权一次。授权后 Agent 只能访问你本人有权限的内容。",
                  )}
                </p>
                <div className={styles.feishuUserAuthHint}>
                  {feishuAuthNeedsReauth
                    ? t(
                        "connectors.feishuUserAuthExpired",
                        "用户授权已失效，请重新登录授权。",
                      )
                    : feishuUserReady
                    ? t(
                        "connectors.feishuUserAuthReady",
                        "已授权，可搜索文档。",
                      )
                    : feishuUserAuth
                    ? t(
                        "connectors.feishuUserAuthPendingHint",
                        "请在弹出的页面完成授权，然后点「我已授权」。",
                      )
                    : t(
                        "connectors.feishuUserAuthHint",
                        "点击登录授权，完成后点「我已授权」。",
                      )}
                </div>
                {feishuUserReady && feishuRefreshExpiresAt && (
                  <div className={styles.feishuUserAuthHint}>
                    {t(
                      "connectors.feishuUserAuthRefreshUntil",
                      "刷新令牌约有效至 {{time}}（到期后需重新授权）",
                      { time: feishuRefreshExpiresAt },
                    )}
                  </div>
                )}
                <div className={styles.quickAuthBar}>
                  <Button
                    type={
                      feishuUserReady && !feishuAuthNeedsReauth
                        ? "default"
                        : "primary"
                    }
                    loading={feishuUserAuthBusy}
                    onClick={() => void handleFeishuUserAuthStart()}
                  >
                    {feishuUserReady || feishuAuthNeedsReauth
                      ? t("connectors.feishuUserAuthAgain", "重新授权")
                      : t("connectors.feishuUserAuthStart", "登录授权")}
                  </Button>
                  {feishuUserAuth && (
                    <Button
                      type="primary"
                      loading={feishuUserAuthBusy}
                      onClick={() => void handleFeishuUserAuthComplete()}
                    >
                      {t("connectors.feishuUserAuthConfirm", "我已授权")}
                    </Button>
                  )}
                </div>
                {feishuUserAuth && (
                  <button
                    type="button"
                    className={styles.feishuUserAuthReopen}
                    onClick={() => openUrl(feishuUserAuth.verification_url)}
                  >
                    {t("connectors.feishuUserAuthReopen", "未弹出？再打开一次")}
                  </button>
                )}
              </div>
            </>
          )}

          {entry.kind === "wecom-cli" && (
            <>
              <Form.Item
                name="bot_id"
                label={t("connectors.wecomBotId", "Bot ID")}
                rules={[{ required: true }]}
                extra={
                  !hideFieldGuide && manualUrl ? (
                    <a href={manualUrl} target="_blank" rel="noreferrer">
                      {t(
                        "connectors.wecomBotCredDoc",
                        "在企业微信开放平台获取智能机器人 Bot ID / Secret",
                      )}
                    </a>
                  ) : undefined
                }
              >
                <Input
                  placeholder={t(
                    "connectors.wecomBotIdPlaceholder",
                    "企业微信智能机器人 Bot ID",
                  )}
                />
              </Form.Item>
              <Form.Item
                name="bot_secret"
                label={t("connectors.wecomBotSecret", "Secret")}
                rules={secretFieldRules(secretRequired)}
                extra={configuredExtra(preview, "bot_secret_configured", t)}
              >
                <Input.Password
                  placeholder={
                    hasStoredCredentials
                      ? t("connectors.secretPlaceholder", "留空表示不修改")
                      : t(
                          "connectors.wecomBotSecretPlaceholder",
                          "企业微信机器人 Secret",
                        )
                  }
                />
              </Form.Item>
            </>
          )}

          {entry.auth_kind === "api_key" &&
            entry.kind !== "feishu-cli" &&
            entry.kind !== "wecom-cli" && (
              <>
                <Form.Item
                  name="api_key"
                  label={t("connectors.apiKey", "API Key")}
                  rules={secretFieldRules(secretRequired)}
                  extra={
                    configuredExtra(preview, "api_key_configured", t) ??
                    (!hideFieldGuide && manualUrl ? (
                      <a href={manualUrl} target="_blank" rel="noreferrer">
                        {t("connectors.apiKeyDoc", "查看如何获取 API Key")}
                      </a>
                    ) : undefined)
                  }
                >
                  <Input.Password
                    placeholder={
                      hasStoredCredentials
                        ? t("connectors.secretPlaceholder", "留空表示不修改")
                        : entry.kind === "tencent-ima"
                        ? t(
                            "connectors.imaApiKeyPlaceholder",
                            "从 IMA 配置页复制（仅展示一次）",
                          )
                        : t("connectors.apiKeyPlaceholder", "粘贴 API Key")
                    }
                  />
                </Form.Item>
                {entry.kind === "tencent-ima" && (
                  <Form.Item
                    name="client_id"
                    label="Client ID"
                    rules={[{ required: true }]}
                  >
                    <Input
                      placeholder={t(
                        "connectors.imaClientIdPlaceholder",
                        "从 IMA 配置页复制",
                      )}
                    />
                  </Form.Item>
                )}
                {entry.kind === "tencent-lexiang" && (
                  <Form.Item
                    name="client_id"
                    label={t(
                      "connectors.lexiangCompanyFrom",
                      "企业标识 (company_from)",
                    )}
                    rules={[{ required: true }]}
                  >
                    <Input
                      placeholder={t(
                        "connectors.lexiangCompanyFromPlaceholder",
                        "从乐享凭证页复制",
                      )}
                    />
                  </Form.Item>
                )}
              </>
            )}

          {entry.auth_kind === "oauth2" && (
            <>
              <Form.Item name="access_token" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="refresh_token" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="expires_at" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="oauth_client_id" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="oauth_client_secret" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="openid" hidden>
                <Input />
              </Form.Item>
              {preview?.oauth_configured && !showManual && (
                <div className={styles.configuredBadge}>
                  {t("connectors.oauthConfigured", "已授权，可直接探测或保存")}
                </div>
              )}
              {entry.kind === "qcc" &&
                preview?.api_key_configured &&
                !showManual && (
                  <div className={styles.configuredBadge}>
                    {t(
                      "connectors.qccApiKeyConfigured",
                      "已配置 API Key，可直接探测或保存",
                    )}
                  </div>
                )}
              {entry.oauth_ready &&
                hasOAuthPopup &&
                !preview?.oauth_configured &&
                !(entry.kind === "qcc" && preview?.api_key_configured) && (
                  <div
                    style={{
                      fontSize: 13,
                      color: "var(--fn-text-tertiary)",
                      marginBottom: 8,
                    }}
                  >
                    {entry.kind === "qcc"
                      ? t(
                          "connectors.qccOauthHint",
                          "点击「一键授权」完成登录后将自动保存；也可打开授权页获取 API Key 后粘贴",
                        )
                      : t(
                          "connectors.oauthHint",
                          "点击「一键授权」完成登录后将自动保存；也可手动粘贴 Token",
                        )}
                  </div>
                )}
              {entry.kind === "qcc" ? (
                <Form.Item
                  name="api_key"
                  label={t("connectors.qccApiKey", "API Key")}
                  extra={configuredExtra(preview, "api_key_configured", t)}
                >
                  <Input.Password
                    placeholder={
                      preview?.api_key_configured
                        ? t("connectors.secretPlaceholder", "留空表示不修改")
                        : t(
                            "connectors.qccApiKeyPlaceholder",
                            "粘贴企查查 API Key",
                          )
                    }
                  />
                </Form.Item>
              ) : (
                <>
                  <div
                    className={styles.manualToggle}
                    onClick={() => setShowManual((v) => !v)}
                    role="button"
                    tabIndex={0}
                  >
                    {showManual
                      ? t("connectors.hideManual", "收起手动输入")
                      : t("connectors.showManual", "手动粘贴 Token")}
                  </div>
                  {showManual && (
                    <Form.Item
                      name="access_token_manual"
                      label={t("connectors.accessTokenManual", "Access Token")}
                      extra={
                        manualUrl ? (
                          <a href={manualUrl} target="_blank" rel="noreferrer">
                            {t(
                              "connectors.manualTokenDoc",
                              "手动获取 Token 文档",
                            )}
                          </a>
                        ) : undefined
                      }
                    >
                      <Input.Password
                        onChange={(e) =>
                          form.setFieldValue("access_token", e.target.value)
                        }
                      />
                    </Form.Item>
                  )}
                </>
              )}
            </>
          )}

          {entry.auth_kind === "imap_app_password" && (
            <>
              <Form.Item
                name="mail_provider"
                label={t("connectors.mailProvider", "邮箱服务商")}
                initialValue="qq"
              >
                <Select
                  options={MAIL_PROVIDERS.map((item) => ({
                    value: item.id,
                    label: item.label,
                  }))}
                />
              </Form.Item>
              <Form.Item
                name="email"
                label={t("connectors.email", "邮箱地址")}
                rules={[{ required: true }]}
              >
                <Input placeholder={selectedMailProvider.emailPlaceholder} />
              </Form.Item>
              <Form.Item
                name="password"
                label={t("connectors.authCode", "授权码")}
                rules={secretFieldRules(secretRequired)}
                extra={
                  configuredExtra(preview, "password_configured", t) ??
                  (selectedMailProvider.guideUrl ? (
                    <a
                      href={selectedMailProvider.guideUrl}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {t(
                        "connectors.personalMailAuthGuide",
                        "如何获取邮箱授权码",
                      )}
                    </a>
                  ) : undefined)
                }
              >
                <Input.Password
                  placeholder={
                    hasStoredCredentials
                      ? t("connectors.secretPlaceholder", "留空表示不修改")
                      : undefined
                  }
                />
              </Form.Item>
              {mailProvider === "custom" && (
                <>
                  <Form.Item
                    name="imap_host"
                    label={t("connectors.imapHost", "IMAP 服务器")}
                    rules={[{ required: true }]}
                  >
                    <Input placeholder="imap.example.com" />
                  </Form.Item>
                  <Form.Item
                    name="smtp_host"
                    label={t("connectors.smtpHost", "SMTP 服务器")}
                    rules={[{ required: true }]}
                  >
                    <Input placeholder="smtp.example.com" />
                  </Form.Item>
                </>
              )}
            </>
          )}

          {entry.auth_kind === "api_credentials" && (
            <>
              <Form.Item
                name="app_id"
                label="AppId"
                rules={[{ required: true }]}
              >
                <Input placeholder="企业 ID / AppId" />
              </Form.Item>
              <Form.Item
                name="sdk_id"
                label="SdkId"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="secret_key"
                label="Secret"
                rules={secretFieldRules(secretRequired)}
                extra={configuredExtra(preview, "secret_key_configured", t)}
              >
                <Input.Password
                  placeholder={
                    hasStoredCredentials
                      ? t("connectors.secretPlaceholder", "留空表示不修改")
                      : undefined
                  }
                />
              </Form.Item>
            </>
          )}

          <Form.Item
            name="shared"
            label={t("connectors.shared", "是否共享")}
            valuePropName="checked"
            extra={t(
              "connectors.sharedHint",
              "共享后其他用户可以选择使用，但不能查看或修改配置。",
            )}
          >
            <Switch />
          </Form.Item>

          <Form.Item
            name="default_open"
            label={t("connectors.defaultEnabled", "是否默认开启")}
            valuePropName="checked"
            extra={
              defaultOpen
                ? undefined
                : t(
                    "connectors.defaultOpenHint",
                    "关闭时需在对话中手动勾选才会注入工具。",
                  )
            }
          >
            <Switch />
          </Form.Item>
          {defaultOpen ? (
            <Alert
              type="warning"
              showIcon
              style={{ marginBottom: 16 }}
              message={t(
                "connectors.defaultOpenWarning",
                "开启后默认会在 Dashboard、IM 与 Cron（未特殊选连接器时）携带该工具（额外消耗 token）。Dashboard 可关本轮；Cron 若显式选择连接器则以选择为准。",
              )}
            />
          ) : null}
        </Form>

        {probeResult !== null && (
          <div className={styles.probeResult}>
            <div className={styles.probeResultHeader}>
              <CheckCircle2
                size={18}
                className={styles.probeResultIcon}
                aria-hidden
              />
              <div className={styles.probeResultMeta}>
                <div className={styles.probeResultTitle}>
                  {t("connectors.probeToolsTitle", "探测成功")}
                </div>
                <div className={styles.probeResultSubtitle}>
                  {probeResult.length > 0
                    ? t("connectors.probeToolsHint", {
                        count: probeResult.length,
                        defaultValue: `连接正常，获取以下工具列表（共 ${probeResult.length} 个）`,
                      })
                    : t(
                        "connectors.probeToolsEmpty",
                        "连接正常，但未发现可用工具",
                      )}
                </div>
              </div>
            </div>
            {probeResult.length > 0 && (
              <ul className={styles.probeToolList}>
                {probeResult.map((tool, index) => (
                  <li key={tool.name} className={styles.probeToolItem}>
                    <span className={styles.probeToolIndex}>{index + 1}</span>
                    <div className={styles.probeToolBody}>
                      <div className={styles.probeToolName}>{tool.name}</div>
                      {tool.description ? (
                        <div className={styles.probeToolDesc}>
                          {tool.description}
                        </div>
                      ) : null}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    </Drawer>
  );
}

type ConnectorTab = "enabled" | "builtin" | "custom";

const CONNECTOR_TABS: TabBarItem<ConnectorTab>[] = [
  { key: "enabled", labelKey: "connectors.tabEnabled", icon: Link2 },
  { key: "builtin", labelKey: "connectors.tabBuiltin", icon: Blocks },
  { key: "custom", labelKey: "connectors.tabCustom", icon: Wrench },
];

export default function ConnectorsPage() {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<ConnectorTab>("enabled");
  const [drawerEntry, setDrawerEntry] = useState<ConnectorCatalogEntry | null>(
    null,
  );
  const [drawerInstance, setDrawerInstance] =
    useState<ConnectorInstance | null>(null);
  const [customFocusServerName, setCustomFocusServerName] = useState<
    string | null
  >(null);
  const { catalog, instances, loading, refresh } = useConnectorInstances();

  const configuredCount = useMemo(() => {
    return instances.filter((instance) => instance.has_credentials).length;
  }, [instances]);

  useEffect(() => {
    const oauthState = searchParams.get("oauth_state");
    if (!oauthState) return;
    void (async () => {
      try {
        const pending = await connectorsApi.oauthPending(oauthState);
        const kind = String(pending.kind || "");
        const entry = catalog.find((c) => c.kind === kind);
        const tokens = pending.tokens ?? {};
        if (!entry || !tokens.access_token) {
          message.error(t("connectors.oauthFailed", "获取授权结果失败"));
          return;
        }
        const credentials: Record<string, unknown> = {
          access_token: tokens.access_token,
        };
        if (tokens.refresh_token)
          credentials.refresh_token = tokens.refresh_token;
        if (tokens.expires_at) credentials.expires_at = tokens.expires_at;
        if (tokens.oauth_client_id)
          credentials.oauth_client_id = tokens.oauth_client_id;
        if (tokens.oauth_client_secret)
          credentials.oauth_client_secret = tokens.oauth_client_secret;
        if (tokens.openid) credentials.openid = tokens.openid;

        await connectorsApi.createInstance({
          kind: entry.kind,
          display_name: entry.name,
          description: entry.description,
          credentials,
          default_open: false,
        });
        await refresh();
        notifyConnectorsChanged();
        message.success(t("connectors.createSuccess", "连接器已创建"));
      } catch {
        message.error(t("connectors.oauthFailed", "获取授权结果失败"));
      }
      searchParams.delete("oauth_state");
      setSearchParams(searchParams, { replace: true });
    })();
  }, [searchParams, setSearchParams, catalog, refresh, t]);

  const handleConfigure = useCallback(
    (entry: ConnectorCatalogEntry, instance: ConnectorInstance | null) => {
      setDrawerEntry(entry);
      setDrawerInstance(instance);
    },
    [],
  );

  const handleSaved = useCallback(async () => {
    await refresh();
    notifyConnectorsChanged();
  }, [refresh]);

  const handleCloseDrawer = useCallback(() => {
    setDrawerEntry(null);
    setDrawerInstance(null);
  }, []);

  return (
    <PageShell.Tabbed
      title={t("pageShell.connectors.title")}
      subtitle={t("pageShell.connectors.subtitle")}
      tabBar={
        <TabBar
          tabs={CONNECTOR_TABS}
          activeKey={activeTab}
          onChange={(key) => {
            if (key === "custom") setCustomFocusServerName(null);
            setActiveTab(key);
          }}
        />
      }
    >
      {activeTab === "custom" ? (
        <CustomMcpTab focusServerName={customFocusServerName} />
      ) : activeTab === "enabled" ? (
        loading ? (
          <div className={styles.loadingState}>
            <Spin />
          </div>
        ) : instances.length === 0 ? (
          <div className={styles.emptyLayout}>
            <StreamSetupGuide
              className={styles.emptyGuide}
              wide
              plain
              icon={<OctopEmptyMascot />}
              title={t("connectors.emptyGuideTitle")}
              description={t("connectors.emptyGuideDesc")}
              steps={[
                {
                  label: t("connectors.emptyGuideStepWhat"),
                  detail: t("connectors.emptyGuideStepWhatDetail"),
                },
                {
                  label: t("connectors.emptyGuideStepHow"),
                  detail: t("connectors.emptyGuideStepHowDetail"),
                },
                {
                  label: t("connectors.emptyGuideStepShare"),
                  detail: t("connectors.emptyGuideStepShareDetail"),
                },
              ]}
              primaryAction={{
                label: t("connectors.emptyGuideBrowseBuiltin"),
                onClick: () => setActiveTab("builtin"),
                icon: <Plug size={14} />,
              }}
              secondaryAction={{
                label: t("connectors.emptyGuideAddCustom"),
                onClick: () => {
                  setCustomFocusServerName(null);
                  setActiveTab("custom");
                },
                icon: <Plus size={14} />,
                type: "default",
              }}
            />
          </div>
        ) : (
          <>
            <div className={styles.listToolbar}>
              <span className={styles.listToolbarMeta}>
                {t("connectors.enabledSummary", {
                  count: instances.length,
                  defaultValue: "已启用 {{count}} 个连接器实例",
                })}
              </span>
              <Button
                icon={<RefreshCw size={14} />}
                loading={loading}
                onClick={() => void refresh()}
              >
                {t("common.refresh")}
              </Button>
            </div>
            <div className={styles.typeGrid}>
              {instances.map((instance) => (
                <ConnectorInstanceCard
                  key={instance.instance_id}
                  instance={instance}
                  catalogEntry={catalog.find(
                    (entry) => entry.kind === instance.kind,
                  )}
                  onEdit={(item) => {
                    if (item.kind === "custom-mcp") {
                      setCustomFocusServerName(item.mcp_server_name);
                      setActiveTab("custom");
                      return;
                    }
                    const entry = catalog.find((row) => row.kind === item.kind);
                    if (entry) handleConfigure(entry, item);
                  }}
                  onChanged={handleSaved}
                />
              ))}
            </div>
          </>
        )
      ) : (
        <>
          <div className={styles.listToolbar}>
            <span className={styles.listToolbarMeta}>
              {t("connectors.listSummary", {
                total: catalog.length,
                configured: configuredCount,
                defaultValue:
                  "当前支持 {{total}} 个连接器，已配置 {{configured}} 个",
              })}
            </span>
            <Button
              icon={<RefreshCw size={14} />}
              loading={loading}
              onClick={() => void refresh()}
            >
              {t("common.refresh")}
            </Button>
          </div>
          {loading ? (
            <div className={styles.loadingState}>
              <Spin />
            </div>
          ) : (
            <div className={styles.typeGrid}>
              {catalog.map((entry) => (
                <ConnectorCard
                  key={entry.kind}
                  entry={entry}
                  onConfigure={handleConfigure}
                />
              ))}
            </div>
          )}
        </>
      )}

      <ConnectorConfigDrawer
        open={drawerEntry !== null}
        entry={drawerEntry}
        instance={drawerInstance}
        onClose={handleCloseDrawer}
        onSaved={(created) => {
          if (created) setDrawerInstance(created);
          void handleSaved();
        }}
      />
    </PageShell.Tabbed>
  );
}
