/**
 * Embeddable per-agent channels grid (preset cards + ChannelDrawer).
 * Lives under Agent/Channels — shared by Personalization tab and Experts drawer.
 */
import { useCallback, useMemo, useState } from "react";
import { Form, Button, Empty } from "antd";
import { message } from "@/utils/antdMessage";

import { RefreshCw } from "lucide-react";
import { useTranslation } from "react-i18next";

import { CardSkeleton } from "../../../components/Skeleton";
import {
  ChannelCard,
  ChannelDrawer,
  useChannels,
  CHANNEL_KEYS,
  DEFAULT_CHANNEL_DISPLAY_CONFIG,
  applyQqChannelSaveConfig,
  CHANNEL_DISPLAY_CONFIG_KEYS,
  CHANNEL_FIELDS,
  DEFAULT_QQ_GROUP_CONTEXT_CONFIG,
  normalizeChannelFieldValue,
  normalizeQqGroupContextConfig,
  partitionChannelKeys,
  type ChannelKey,
} from "./components";
import type { ChannelRow } from "./useChannels";
import type { ChannelFormValues } from "./components/ChannelDrawer";
import styles from "./index.module.less";

function configFromFormValues(
  values: ChannelFormValues,
): Record<string, unknown> {
  const { __raw_config, response_mode, show_thinking, show_tool_hints } =
    values;
  let config: Record<string, unknown> = {
    response_mode:
      response_mode ?? DEFAULT_CHANNEL_DISPLAY_CONFIG.response_mode,
    show_thinking:
      show_thinking ?? DEFAULT_CHANNEL_DISPLAY_CONFIG.show_thinking,
    show_tool_hints:
      show_tool_hints ?? DEFAULT_CHANNEL_DISPLAY_CONFIG.show_tool_hints,
  };
  const fields = CHANNEL_FIELDS[values.kind as ChannelKey];
  const hasSchema = !!fields && fields.length > 0;
  if (hasSchema) {
    for (const [k, v] of Object.entries(values)) {
      if (
        k === "kind" ||
        k === "name" ||
        k === "enabled" ||
        k === "__raw_config" ||
        k === "response_mode" ||
        k === "show_thinking" ||
        k === "show_tool_hints" ||
        k === "c2c_streaming"
      ) {
        continue;
      }
      if (v === undefined || v === null || v === "") continue;
      config[k] = normalizeChannelFieldValue(k, v);
    }
  } else if (__raw_config !== undefined) {
    const trimmed = __raw_config.trim();
    if (trimmed) {
      const parsed = JSON.parse(trimmed) as Record<string, unknown>;
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        config = parsed;
      }
    }
  }
  config = {
    ...config,
    response_mode:
      response_mode ?? DEFAULT_CHANNEL_DISPLAY_CONFIG.response_mode,
    show_thinking:
      show_thinking ?? DEFAULT_CHANNEL_DISPLAY_CONFIG.show_thinking,
    show_tool_hints:
      show_tool_hints ?? DEFAULT_CHANNEL_DISPLAY_CONFIG.show_tool_hints,
  };
  applyQqChannelSaveConfig(config, values.kind);
  return config;
}

interface TestState {
  loadingKey: ChannelKey | null;
  results: Partial<Record<ChannelKey, { ok: boolean; error?: string }>>;
}

export interface ChannelsPanelProps {
  agentId: string | null;
}

export default function ChannelsPanel({ agentId }: ChannelsPanelProps) {
  const { t } = useTranslation();
  const {
    channels,
    loading,
    fetchChannels,
    getChannel,
    createChannel,
    updateChannel,
    deleteChannel,
    probeChannelConfig,
  } = useChannels(agentId);

  const [hoverId, setHoverId] = useState<ChannelKey | null>(null);
  const [showMoreChannels, setShowMoreChannels] = useState(false);
  const [enableLoadingKey, setEnableLoadingKey] = useState<ChannelKey | null>(
    null,
  );
  const [testState, setTestState] = useState<TestState>({
    loadingKey: null,
    results: {},
  });

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editing, setEditing] = useState<ChannelRow | null>(null);
  const [loadingConfig, setLoadingConfig] = useState(false);
  const [drawerInitialValues, setDrawerInitialValues] = useState<
    ChannelFormValues | undefined
  >(undefined);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [form] = Form.useForm<ChannelFormValues>();

  const channelByKind = useMemo<Map<ChannelKey, ChannelRow>>(() => {
    const map = new Map<ChannelKey, ChannelRow>();
    for (const row of channels) {
      const key = row.kind as ChannelKey;
      if (!CHANNEL_KEYS.includes(key)) continue;
      const existing = map.get(key);
      if (!existing || (!existing.enabled && row.enabled)) {
        map.set(key, row);
      }
    }
    return map;
  }, [channels]);

  const { featuredChannelKeys, moreChannelKeys } = useMemo(() => {
    const { featured, more } = partitionChannelKeys(
      CHANNEL_KEYS,
      new Set(channelByKind.keys()),
    );
    return { featuredChannelKeys: featured, moreChannelKeys: more };
  }, [channelByKind]);

  const visibleChannelKeys = showMoreChannels
    ? [...featuredChannelKeys, ...moreChannelKeys]
    : featuredChannelKeys;

  const openCreate = useCallback(
    (kind: ChannelKey) => {
      setEditing(null);
      setLoadingConfig(false);
      const defaults: ChannelFormValues = {
        kind,
        // Create defaults to ENABLED, matching the server-side create default
        // (repos/channels.py writes enabled=1) and the QR-bind auto-enable
        // flows ("channel is usable immediately"). A channel born enabled
        // needs no follow-up PATCH, so the row keeps a clean single-write
        // signature and no start/stop churn happens behind the save.
        enabled: true,
        ...DEFAULT_CHANNEL_DISPLAY_CONFIG,
        ...(kind === "discord" ? { allow_all_channels: true } : {}),
        ...(kind === "qq"
          ? { group_context: { ...DEFAULT_QQ_GROUP_CONTEXT_CONFIG } }
          : {}),
      };
      setDrawerInitialValues(defaults);
      form.resetFields();
      form.setFieldsValue(defaults);
      setDrawerOpen(true);
    },
    [form],
  );

  const openEdit = useCallback(
    async (row: ChannelRow) => {
      setEditing(row);
      setLoadingConfig(true);
      const baseValues: ChannelFormValues = {
        kind: row.kind as ChannelKey,
        enabled: row.enabled,
        ...DEFAULT_CHANNEL_DISPLAY_CONFIG,
      };
      setDrawerInitialValues(baseValues);
      form.resetFields();
      form.setFieldsValue(baseValues);
      setDrawerOpen(true);
      const detail = await getChannel(row.id);
      if (detail) {
        const cfg = detail.config ?? {};
        const formCfg: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(cfg)) {
          if (v === undefined || v === null) continue;
          if (row.kind === "qq" && k === "show_progress") continue;
          if (
            CHANNEL_DISPLAY_CONFIG_KEYS.includes(
              k as (typeof CHANNEL_DISPLAY_CONFIG_KEYS)[number],
            )
          ) {
            continue;
          }
          if (
            row.kind === "discord" &&
            (k === "allowed_channel_ids" || k === "allowed_user_ids") &&
            Array.isArray(v)
          ) {
            formCfg[k] = v.join("\n");
          } else if (row.kind === "qq" && k === "group_context") {
            formCfg[k] = normalizeQqGroupContextConfig(v);
          } else if (typeof v === "string") formCfg[k] = v;
          else if (typeof v === "number" || typeof v === "boolean")
            formCfg[k] = String(v);
          else formCfg[k] = JSON.stringify(v);
        }
        if (
          row.kind === "qq" &&
          typeof formCfg.client_secret === "string" &&
          !formCfg.secret
        ) {
          formCfg.secret = formCfg.client_secret;
        }
        if (row.kind === "qq" && !formCfg.group_context) {
          formCfg.group_context = { ...DEFAULT_QQ_GROUP_CONTEXT_CONFIG };
        }
        const next: ChannelFormValues = {
          kind: row.kind as ChannelKey,
          enabled: row.enabled,
          response_mode: cfg.response_mode === "stream" ? "stream" : "invoke",
          show_thinking:
            typeof cfg.show_thinking === "boolean"
              ? cfg.show_thinking
              : DEFAULT_CHANNEL_DISPLAY_CONFIG.show_thinking,
          show_tool_hints:
            typeof cfg.show_tool_hints === "boolean"
              ? cfg.show_tool_hints
              : DEFAULT_CHANNEL_DISPLAY_CONFIG.show_tool_hints,
          ...formCfg,
          ...(row.kind === "discord"
            ? { allow_all_channels: cfg.allow_all_channels !== false }
            : {}),
          __raw_config: JSON.stringify(cfg, null, 2),
        };
        setDrawerInitialValues(next);
        form.setFieldsValue(next);
      }
      setLoadingConfig(false);
    },
    [form, getChannel],
  );

  const handleCardClick = useCallback(
    (key: ChannelKey) => {
      const row = channelByKind.get(key);
      if (row) {
        void openEdit(row);
      } else {
        openCreate(key);
      }
    },
    [channelByKind, openCreate, openEdit],
  );

  const handleDrawerClose = useCallback(() => {
    setDrawerOpen(false);
    setEditing(null);
    setDrawerInitialValues(undefined);
  }, []);

  const handleProvisioned = useCallback(() => {
    message.success(t("channels.dingtalkBindSuccess"));
    setDrawerOpen(false);
    setEditing(null);
    setDrawerInitialValues(undefined);
    void fetchChannels();
  }, [fetchChannels, t]);

  const handleSubmit = useCallback(
    async (
      kind: ChannelKey,
      _name: string,
      config: Record<string, unknown>,
      enabled: boolean,
    ) => {
      setSaving(true);
      try {
        if (editing) {
          const updated = await updateChannel(editing.id, { config, enabled });
          if (updated) {
            message.success(t("channels.configSaved"));
            setDrawerOpen(false);
            void fetchChannels();
            return true;
          }
          return false;
        }
        const existing = channelByKind.get(kind);
        if (existing) {
          const updated = await updateChannel(existing.id, { config, enabled });
          if (updated) {
            message.success(t("channels.configSaved"));
            setDrawerOpen(false);
            void fetchChannels();
            return true;
          }
          return false;
        }
        const created = await createChannel({ kind, name: kind, config });
        if (created) {
          // Align enablement with the requested state (QR bind → true).
          // Server create currently defaults to enabled=1, so this is a no-op
          // when we ask for enabled=true.
          if (created.enabled !== enabled) {
            await updateChannel(created.id, { enabled });
          }
          // One toast only — createChannel no longer toasts on its own.
          // Prefer bind-success copy when the channel was just QR-auto-enabled.
          const toastKey = !enabled
            ? "channels.configSaved"
            : kind === "wecom"
            ? "channels.qrBindSuccess"
            : kind === "weixin"
            ? "channels.weixinQrBindSuccess"
            : kind === "feishu"
            ? "channels.feishuBindSuccess"
            : kind === "yuanbao"
            ? "channels.yuanbaoBindSuccess"
            : "channels.channelEnabled";
          message.success(t(toastKey));
          setDrawerOpen(false);
          void fetchChannels();
          return true;
        }
        return false;
      } finally {
        setSaving(false);
      }
    },
    [editing, channelByKind, createChannel, updateChannel, fetchChannels, t],
  );

  const handleToggleEnabled = useCallback(
    async (key: ChannelKey, checked: boolean) => {
      const row = channelByKind.get(key);
      if (!row) {
        openCreate(key);
        return;
      }
      setEnableLoadingKey(key);
      try {
        await updateChannel(row.id, { enabled: checked });
        message.success(
          checked
            ? t("channels.channelEnabled")
            : t("channels.channelDisabled"),
        );
      } finally {
        setEnableLoadingKey(null);
      }
    },
    [channelByKind, openCreate, updateChannel, t],
  );

  const handleDeleteFromDrawer = useCallback(async () => {
    if (!editing) return;
    setDeleting(true);
    try {
      await deleteChannel(editing.id);
      setDrawerOpen(false);
      setEditing(null);
    } finally {
      setDeleting(false);
    }
  }, [editing, deleteChannel]);

  const handleTestFromDrawer = useCallback(async () => {
    const values = form.getFieldsValue(true) as ChannelFormValues;
    const kind = (values.kind ?? editing?.kind) as ChannelKey | undefined;
    if (!kind) return;
    let config: Record<string, unknown>;
    try {
      config = configFromFormValues({ ...values, kind });
    } catch {
      message.error(t("channels.probeNeedConfig"));
      return;
    }
    setTestState((prev) => ({ ...prev, loadingKey: kind }));
    const result = await probeChannelConfig(kind, config);
    setTestState((prev) => ({
      loadingKey: null,
      results: { ...prev.results, [kind]: result },
    }));
    if (result.ok) {
      message.success(t("channels.testSuccess"));
    } else {
      message.error(
        t("channels.testFailed", {
          error: result.error ?? t("common.unknownError"),
        }),
      );
    }
  }, [editing, form, probeChannelConfig, t]);

  if (!agentId) {
    return (
      <Empty
        description={t("channels.noAgentSelected")}
        style={{ marginTop: 60 }}
      />
    );
  }

  return (
    <div className={styles.channelsPanel}>
      <div className={styles.channelsToolbar}>
        <span className={styles.channelsStats}>
          {t("channels.statsSummary", {
            supported: CHANNEL_KEYS.length,
            configured: channelByKind.size,
          })}
        </span>
        <Button
          icon={<RefreshCw size={14} />}
          onClick={() => void fetchChannels()}
          loading={loading}
        >
          {t("common.refresh")}
        </Button>
      </div>

      {loading && channels.length === 0 ? (
        <div className={styles.channelsBody}>
          <CardSkeleton count={10} />
        </div>
      ) : (
        <div className={styles.channelsBody}>
          <div className={styles.channelsGrid}>
            {visibleChannelKeys.map((key) => {
              const row = channelByKind.get(key);
              return (
                <ChannelCard
                  key={key}
                  channelKey={key}
                  enabled={Boolean(row?.enabled)}
                  hasChannel={Boolean(row)}
                  isHover={hoverId === key}
                  enableLoading={enableLoadingKey === key}
                  testLoading={testState.loadingKey === key}
                  testResult={testState.results[key] ?? null}
                  runtime={row?.runtime}
                  onClick={() => handleCardClick(key)}
                  onMouseEnter={() => setHoverId(key)}
                  onMouseLeave={() => setHoverId(null)}
                  onToggleEnabled={handleToggleEnabled}
                />
              );
            })}
          </div>
          {moreChannelKeys.length > 0 && (
            <Button
              type="link"
              size="small"
              className={styles.showMoreChannelsBtn}
              onClick={() => setShowMoreChannels((v) => !v)}
            >
              {showMoreChannels
                ? t("channels.hideMoreChannels")
                : t("channels.showMoreChannels", {
                    count: moreChannelKeys.length,
                  })}
            </Button>
          )}
        </div>
      )}

      <ChannelDrawer
        open={drawerOpen}
        editing={editing}
        loadingConfig={loadingConfig}
        initialValues={drawerInitialValues}
        form={form}
        saving={saving}
        deleting={deleting}
        onDelete={editing ? handleDeleteFromDrawer : undefined}
        onClose={handleDrawerClose}
        onSubmit={handleSubmit}
        onProvisioned={handleProvisioned}
        onTest={handleTestFromDrawer}
        testing={
          testState.loadingKey !== null &&
          testState.loadingKey ===
            ((form.getFieldValue("kind") as ChannelKey | undefined) ??
              (editing?.kind as ChannelKey | undefined))
        }
        agentId={agentId}
      />
    </div>
  );
}
