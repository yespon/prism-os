import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
} from "react";
import {
  Alert,
  Button,
  Checkbox,
  Collapse,
  Drawer,
  Empty,
  Input,
  Modal,
  Popconfirm,
  Segmented,
  Space,
  Switch,
  Tag,
  Typography,
} from "antd";
import { message } from "@/utils/antdMessage";

import {
  BookOpen,
  LayoutGrid,
  List,
  Package,
  Plus,
  Store,
  Trash2,
  Upload,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { useSearchParams } from "react-router-dom";
import { pluginsApi, type InstalledPlugin } from "../../../api/modules/plugins";
import { ResizableTable } from "../../../components/ResizableTable";
import { CardSkeleton } from "../../../components/Skeleton";
import { useCardTableView } from "../../../hooks/useCardTableView";
import {
  ensureBuiltinToolRenderers,
  reloadPluginToolUis,
} from "../../../plugins/toolRenderers";
import { updateToolPluginIndex } from "../../../plugins/toolRenderers/toolPluginIndex";
import { apiErrorMessage } from "../../../utils/apiError";
import styles from "./index.module.less";
import { PluginIconView } from "./PluginIconView";
import { PluginGroupTag } from "./PluginGroupTag";
import { PluginCardMeta } from "./PluginCardMeta";
import { notifyPluginsChanged, PLUGINS_CHANGED_EVENT } from "./pluginsEvents";

const { Text, Paragraph } = Typography;

async function syncPluginUis(rows: InstalledPlugin[]): Promise<void> {
  ensureBuiltinToolRenderers();
  updateToolPluginIndex(rows);
  await reloadPluginToolUis(rows);
}

function statusTag(row: InstalledPlugin, t: (key: string) => string) {
  if (row.error)
    return (
      <Tag color="error" bordered={false}>
        {t("plugins.statusError")}
      </Tag>
    );
  if (row.enabled === false)
    return (
      <Tag color="default" bordered={false}>
        {t("plugins.statusDisabled")}
      </Tag>
    );
  return (
    <Tag color={row.loaded ? "success" : "default"} bordered={false}>
      {row.loaded ? t("plugins.statusLoaded") : t("plugins.statusIdle")}
    </Tag>
  );
}

/** Server-wide plugin install, reload, enable, detail, and uninstall surface. */
export function InstalledPluginsPanel() {
  const { t } = useTranslation();
  const [, setSearchParams] = useSearchParams();
  const [plugins, setPlugins] = useState<InstalledPlugin[]>([]);
  const [loading, setLoading] = useState(true);
  const [installOpen, setInstallOpen] = useState(false);
  const [installUrl, setInstallUrl] = useState("");
  const [installing, setInstalling] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [overwrite, setOverwrite] = useState(false);
  const [reloading, setReloading] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [detail, setDetail] = useState<InstalledPlugin | null>(null);
  const { viewMode, setViewMode, showCardView } = useCardTableView("card");

  const fetchPlugins = useCallback(async () => {
    setLoading(true);
    try {
      const rows = await pluginsApi.list();
      setPlugins(rows);
      void syncPluginUis(rows).catch((err) =>
        console.warn("[plugin-ui] sync after list failed:", err),
      );
    } catch (err) {
      message.error(t("plugins.loadError"));
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    void fetchPlugins();
  }, [fetchPlugins]);

  useEffect(() => {
    const onChanged = () => {
      void fetchPlugins();
    };
    window.addEventListener(PLUGINS_CHANGED_EVENT, onChanged);
    return () => window.removeEventListener(PLUGINS_CHANGED_EVENT, onChanged);
  }, [fetchPlugins]);

  const handleInstall = async () => {
    const url = installUrl.trim();
    if (!url) return;
    setInstalling(true);
    try {
      await pluginsApi.install(url);
      message.success(t("plugins.installSuccess"));
      setInstallOpen(false);
      setInstallUrl("");
      notifyPluginsChanged();
      await fetchPlugins();
    } catch (err) {
      message.error(apiErrorMessage(err, t("plugins.installFailed"), t));
    } finally {
      setInstalling(false);
    }
  };

  const handleFileSelected = async (event: ChangeEvent<HTMLInputElement>) => {
    const next = event.target.files?.[0] ?? null;
    event.target.value = "";
    if (!next) return;
    if (!next.name.toLowerCase().endsWith(".zip")) {
      message.error(t("plugins.zipOnly"));
      return;
    }
    setUploading(true);
    try {
      await pluginsApi.upload(next, overwrite);
      message.success(t("plugins.installSuccess"));
      notifyPluginsChanged();
      await fetchPlugins();
    } catch (err) {
      message.error(apiErrorMessage(err, t("plugins.installFailed"), t));
    } finally {
      setUploading(false);
    }
  };

  const handleReload = async () => {
    setReloading(true);
    try {
      await pluginsApi.reload();
      message.success(t("plugins.reloadSuccess"));
      await fetchPlugins();
    } catch (err) {
      message.error(apiErrorMessage(err, t("plugins.reloadFailed"), t));
    } finally {
      setReloading(false);
    }
  };

  const handleUninstall = async (pluginId: string) => {
    try {
      await pluginsApi.uninstall(pluginId);
      message.success(t("plugins.uninstallSuccess"));
      if (detail?.id === pluginId) setDetail(null);
      notifyPluginsChanged();
      await fetchPlugins();
    } catch (err) {
      message.error(apiErrorMessage(err, t("plugins.uninstallFailed"), t));
    }
  };

  const handleToggleEnabled = async (
    row: InstalledPlugin,
    enabled: boolean,
  ) => {
    setTogglingId(row.id);
    try {
      const updated = await pluginsApi.setEnabled(row.id, enabled);
      setPlugins((prev) =>
        prev.map((item) =>
          item.id === row.id ? { ...item, ...updated } : item,
        ),
      );
      setDetail((prev) =>
        prev?.id === row.id ? { ...prev, ...updated } : prev,
      );
      message.success(
        enabled ? t("plugins.enabledSuccess") : t("plugins.disabledSuccess"),
      );
      await fetchPlugins();
    } catch (err) {
      message.error(apiErrorMessage(err, t("plugins.enableFailed"), t));
    } finally {
      setTogglingId(null);
    }
  };

  const columns = [
    {
      title: t("plugins.colName"),
      key: "name",
      width: 220,
      ellipsis: true,
      render: (_: unknown, row: InstalledPlugin) => (
        <span className={styles.tableNameCell}>
          <PluginIconView icon={row.icon} size={28} />
          <span className={styles.tableNameText}>{row.name || row.id}</span>
        </span>
      ),
    },
    {
      title: t("plugins.colId"),
      dataIndex: "id",
      key: "id",
      width: 160,
      ellipsis: true,
      render: (id: string) => <span className={styles.tableMono}>{id}</span>,
    },
    {
      title: t("plugins.colVersion"),
      dataIndex: "version",
      key: "version",
      width: 96,
      render: (version: string | undefined) => (
        <span className={styles.tableCellSingle}>{version || "—"}</span>
      ),
    },
    {
      title: t("plugins.colKind"),
      dataIndex: "kind",
      key: "kind",
      width: 100,
      render: (kind: string | undefined) => <Tag>{kind || "—"}</Tag>,
    },
    {
      title: t("plugins.colGroup"),
      dataIndex: "group",
      key: "group",
      width: 100,
      render: (group: string | null | undefined) =>
        group ? <PluginGroupTag group={group} /> : "—",
    },
    {
      title: t("plugins.colStatus"),
      key: "status",
      width: 110,
      render: (_: unknown, row: InstalledPlugin) => statusTag(row, t),
    },
    {
      title: t("plugins.colEnabled"),
      key: "enabled",
      width: 88,
      render: (_: unknown, row: InstalledPlugin) => (
        <Switch
          size="small"
          checked={row.enabled !== false}
          loading={togglingId === row.id}
          disabled={!!row.error}
          onChange={(checked) => void handleToggleEnabled(row, checked)}
        />
      ),
    },
    {
      title: t("plugins.colActions"),
      key: "actions",
      width: 128,
      render: (_: unknown, row: InstalledPlugin) => (
        <div className={styles.tableActions}>
          <Button type="link" size="small" onClick={() => setDetail(row)}>
            {t("plugins.viewDetails")}
          </Button>
          <Popconfirm
            title={t("plugins.uninstallConfirm", { id: row.id })}
            onConfirm={() => void handleUninstall(row.id)}
          >
            <Button
              type="text"
              danger
              size="small"
              className={styles.iconBtn}
              icon={<Trash2 size={15} />}
              aria-label={t("plugins.uninstall")}
            />
          </Popconfirm>
        </div>
      ),
    },
  ];

  return (
    <div className={styles.panel}>
      <Collapse
        className={styles.guide}
        items={[
          {
            key: "guide",
            label: (
              <span className={styles.guideLabel}>
                <BookOpen size={15} />
                {t("plugins.guideTitle")}
              </span>
            ),
            children: (
              <div className={styles.guideBody}>
                <div className={styles.guideSection}>
                  <Text strong>{t("plugins.guideDevelopTitle")}</Text>
                  <Paragraph className={styles.guideText}>
                    {t("plugins.guideDevelopBody")}
                  </Paragraph>
                </div>
                <div className={styles.guideSection}>
                  <Text strong>{t("plugins.guidePackageTitle")}</Text>
                  <Paragraph className={styles.guideText}>
                    {t("plugins.guidePackageBody")}
                  </Paragraph>
                </div>
                <div className={styles.guideSection}>
                  <Text strong>{t("plugins.guideImportTitle")}</Text>
                  <Paragraph className={styles.guideText}>
                    {t("plugins.guideImportBody")}
                  </Paragraph>
                </div>
                <div className={styles.guideSection}>
                  <Text strong>{t("plugins.guideExampleTitle")}</Text>
                  <pre className={styles.codeBlock}>
                    {t("plugins.guideExampleYaml")}
                  </pre>
                </div>
              </div>
            ),
          },
        ]}
      />

      <div className={styles.toolbar}>
        <div className={styles.toolbarLeft}>
          <span className={styles.toolbarCount}>
            {t("plugins.totalPlugins", { count: plugins.length })}
          </span>
        </div>
        <div className={styles.toolbarRight}>
          <Segmented
            size="small"
            value={viewMode}
            onChange={(v) => setViewMode(v as "card" | "table")}
            options={[
              {
                value: "card",
                label: (
                  <span className={styles.viewModeLabel}>
                    <LayoutGrid size={14} />
                    {t("plugins.viewCard")}
                  </span>
                ),
              },
              {
                value: "table",
                label: (
                  <span className={styles.viewModeLabel}>
                    <List size={14} />
                    {t("plugins.viewTable")}
                  </span>
                ),
              },
            ]}
          />
          <Checkbox
            checked={overwrite}
            onChange={(e) => setOverwrite(e.target.checked)}
          >
            {t("plugins.overwriteInstall")}
          </Checkbox>
          <Button loading={reloading} onClick={() => void handleReload()}>
            {t("plugins.reload")}
          </Button>
          <Button
            icon={<Upload size={16} />}
            loading={uploading}
            onClick={() => fileInputRef.current?.click()}
          >
            {t("plugins.installFromZip")}
          </Button>
          <Button
            type="primary"
            icon={<Plus size={16} />}
            onClick={() => setInstallOpen(true)}
          >
            {t("plugins.install")}
          </Button>
        </div>
      </div>

      {showCardView ? (
        loading ? (
          <CardSkeleton count={3} />
        ) : plugins.length === 0 ? (
          <Empty
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description={
              <div className={styles.emptyWithAction}>
                <div>{t("plugins.empty")}</div>
                <div className={styles.emptyHint}>{t("plugins.emptyHint")}</div>
                <Button
                  type="primary"
                  icon={<Store size={16} />}
                  onClick={() =>
                    setSearchParams({ tab: "market" }, { replace: true })
                  }
                >
                  {t("plugins.goToMarket")}
                </Button>
              </div>
            }
          />
        ) : (
          <div className={styles.cardGrid}>
            {plugins.map((row) => {
              const enabled = row.enabled !== false;
              return (
                <article
                  key={row.id}
                  className={`${styles.card} ${
                    enabled ? "" : styles.cardDisabled
                  }`}
                >
                  <div className={styles.cardBody}>
                    <div className={styles.cardTop}>
                      <PluginIconView
                        icon={row.icon}
                        size={32}
                        className={styles.cardIcon}
                      />
                      <div className={styles.cardTitleCol}>
                        <h3 className={styles.cardName}>
                          {row.name || row.id}
                        </h3>
                        <PluginCardMeta
                          kind={row.kind}
                          group={row.group}
                          version={row.version}
                          trailing={statusTag(row, t)}
                        />
                      </div>
                    </div>
                    <p className={styles.cardDesc}>
                      {row.error ||
                        row.description ||
                        t("plugins.noDescription")}
                    </p>
                  </div>
                  <div className={styles.cardFooter}>
                    <button
                      type="button"
                      className={styles.detailLink}
                      onClick={() => setDetail(row)}
                    >
                      {t("plugins.viewDetails")}
                    </button>
                    <span className={styles.cardFooterSpacer} />
                    <Switch
                      size="small"
                      checked={enabled}
                      loading={togglingId === row.id}
                      disabled={!!row.error}
                      onChange={(checked) =>
                        void handleToggleEnabled(row, checked)
                      }
                    />
                    <Popconfirm
                      title={t("plugins.uninstallConfirm", { id: row.id })}
                      onConfirm={() => void handleUninstall(row.id)}
                    >
                      <Button
                        type="text"
                        danger
                        size="small"
                        className={styles.iconBtn}
                        icon={<Trash2 size={15} />}
                        aria-label={t("plugins.uninstall")}
                      />
                    </Popconfirm>
                  </div>
                </article>
              );
            })}
          </div>
        )
      ) : (
        <ResizableTable
          storageKey="admin-plugins"
          className={styles.table}
          rowKey="id"
          loading={loading}
          columns={columns}
          dataSource={plugins}
          pagination={false}
          scroll={{ x: 960 }}
          locale={{
            emptyText: (
              <Empty
                image={Empty.PRESENTED_IMAGE_SIMPLE}
                description={
                  <div className={styles.emptyWithAction}>
                    <div>{t("plugins.empty")}</div>
                    <div className={styles.emptyHint}>
                      {t("plugins.emptyHint")}
                    </div>
                    <Button
                      type="primary"
                      icon={<Store size={16} />}
                      onClick={() =>
                        setSearchParams({ tab: "market" }, { replace: true })
                      }
                    >
                      {t("plugins.goToMarket")}
                    </Button>
                  </div>
                }
              />
            ),
          }}
        />
      )}

      <Drawer
        title={
          detail ? (
            <div className={styles.drawerTitleBar}>
              <PluginIconView icon={detail.icon} size={32} />
              <div className={styles.drawerTitleMeta}>
                <div className={styles.drawerTitleText}>
                  {detail.name || detail.id}
                </div>
                <div className={styles.drawerTitleId}>{detail.id}</div>
              </div>
            </div>
          ) : (
            t("plugins.detailTitle")
          )
        }
        open={!!detail}
        onClose={() => setDetail(null)}
        width={500}
        destroyOnHidden
        styles={{ body: { paddingTop: 12, paddingBottom: 24 } }}
      >
        {detail ? (
          <div className={styles.drawerContent}>
            {detail.error ? (
              <Alert
                type="error"
                showIcon
                message={detail.error}
                className={styles.drawerAlert}
              />
            ) : null}

            <p className={styles.drawerDesc}>
              {detail.description || t("plugins.noDescription")}
            </p>

            <PluginCardMeta
              kind={detail.kind}
              group={detail.group}
              version={detail.version}
              trailing={
                <>
                  {statusTag(detail, t)}
                  {detail.ui?.entry ? (
                    <Tag color="blue" bordered={false}>
                      {t("plugins.hasUi")}
                    </Tag>
                  ) : null}
                </>
              }
            />

            <div className={styles.drawerEnableRow}>
              <div className={styles.drawerEnableText}>
                <span className={styles.drawerEnableLabel}>
                  {t("plugins.colEnabled")}
                </span>
                <span className={styles.drawerEnableHint}>
                  {t("plugins.detailEnableHint")}
                </span>
              </div>
              <Switch
                checked={detail.enabled !== false}
                loading={togglingId === detail.id}
                disabled={!!detail.error}
                onChange={(checked) =>
                  void handleToggleEnabled(detail, checked)
                }
              />
            </div>

            <section className={styles.drawerSection}>
              <h4 className={styles.drawerSectionTitle}>
                {t("plugins.detailInfo")}
              </h4>
              <div className={styles.detailList}>
                <div className={styles.detailRow}>
                  <span className={styles.detailLabel}>
                    {t("plugins.colPath")}
                  </span>
                  <span
                    className={`${styles.detailValue} ${styles.detailMono}`}
                  >
                    {detail.path || "—"}
                  </span>
                </div>
                <div className={styles.detailRow}>
                  <span className={styles.detailLabel}>
                    {t("plugins.colUi")}
                  </span>
                  <span
                    className={`${styles.detailValue} ${styles.detailMono}`}
                  >
                    {detail.ui?.entry || "—"}
                  </span>
                </div>
                <div className={styles.detailRow}>
                  <span className={styles.detailLabel}>
                    {t("plugins.colRequires")}
                  </span>
                  <span className={styles.detailValue}>
                    {(detail.requires || []).length > 0 ? (
                      <span className={styles.requiresTags}>
                        {detail.requires!.map((req) => (
                          <Tag key={req}>{req}</Tag>
                        ))}
                      </span>
                    ) : (
                      "—"
                    )}
                  </span>
                </div>
              </div>
            </section>
          </div>
        ) : null}
      </Drawer>

      <Modal
        title={t("plugins.installTitle")}
        open={installOpen}
        onCancel={() => setInstallOpen(false)}
        onOk={() => void handleInstall()}
        confirmLoading={installing}
        okText={t("plugins.install")}
      >
        <Space direction="vertical" style={{ width: "100%" }} size="middle">
          <Alert type="info" showIcon message={t("plugins.installUrlHint")} />
          <Input
            prefix={<Package size={16} />}
            placeholder={t("plugins.installUrlPlaceholder")}
            value={installUrl}
            onChange={(e) => setInstallUrl(e.target.value)}
            onPressEnter={() => void handleInstall()}
          />
        </Space>
      </Modal>

      <input
        ref={fileInputRef}
        type="file"
        accept=".zip,application/zip"
        style={{ display: "none" }}
        onChange={(e) => void handleFileSelected(e)}
      />
    </div>
  );
}
