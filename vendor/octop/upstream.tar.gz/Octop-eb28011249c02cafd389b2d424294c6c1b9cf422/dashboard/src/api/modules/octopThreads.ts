import type { HitlPendingPayload, HitlSessionPolicy } from "../types/hitl";
import { request } from "../request";

/** Workspace file produced in a thread; ``agent_id`` is the producer. */
export type ThreadArtifact = {
  path: string;
  agent_id?: string;
};

/**
 * Prefer ``artifact_refs``; fall back to legacy ``artifacts`` (strings or
 * objects) so older servers / clients keep working.
 */
export function normalizeThreadArtifacts(
  raw: unknown,
  fallbackAgentId?: string | null,
  refs?: unknown,
): ThreadArtifact[] {
  const source = Array.isArray(refs) && refs.length > 0 ? refs : raw;
  if (!Array.isArray(source)) return [];
  const out: ThreadArtifact[] = [];
  const seen = new Set<string>();
  const fallback = (fallbackAgentId || "").trim();
  for (const item of source) {
    let path = "";
    let agentId = fallback;
    if (typeof item === "string") {
      path = item.trim();
    } else if (item && typeof item === "object") {
      const row = item as { path?: unknown; agent_id?: unknown };
      if (typeof row.path === "string") path = row.path.trim();
      if (typeof row.agent_id === "string" && row.agent_id.trim()) {
        agentId = row.agent_id.trim();
      }
    }
    if (!path) continue;
    const key = `${agentId}\0${path}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(agentId ? { path, agent_id: agentId } : { path });
  }
  return out;
}

export interface OctopThread {
  thread_id: string;
  title: string | null;
  channel_type: string;
  session_key: string;
  last_active: number;
  created_at: number;
  is_active?: boolean;
  has_messages?: boolean;
  pinned?: boolean;
  unread_count?: number;
  model_ref?: string | null;
  reasoning_mode?: "auto" | "enabled" | "disabled" | null;
  reasoning_effort?: string | null;
  conversation_mode?: "ask" | "plan" | "craft" | null;
  pending_plan_path?: string | null;
  hitl_policy?: HitlSessionPolicy | null;
  /** Legacy path list (compat). Prefer ``artifact_refs`` when present. */
  artifacts?: Array<string | ThreadArtifact>;
  /** Structured refs with producer ``agent_id``. */
  artifact_refs?: ThreadArtifact[];
}

export interface OctopThreadHistory {
  thread_id: string;
  messages: Array<{
    role: string;
    content: unknown;
    id?: string;
    usage?: unknown;
    timestamp?: number;
    status?: string;
    error_code?: string;
    agent_id?: string;
    team_wrapup?: boolean;
  }>;
  pinned?: boolean;
  model_ref?: string | null;
  reasoning_mode?: "auto" | "enabled" | "disabled" | null;
  reasoning_effort?: string | null;
  conversation_mode?: "ask" | "plan" | "craft" | null;
  pending_plan_path?: string | null;
  hitl_policy?: HitlSessionPolicy | null;
  has_more?: boolean;
  limit?: number;
  offset?: number;
  next_cursor?: string | null;
  /** Legacy checkpoint is being projected by the bounded background worker. */
  history_loading?: boolean;
  history_status?: "pending" | "queued" | "running" | "ready" | "failed";
  history_retry_after_ms?: number;
  /** True while a turn is still streaming server-side for this thread. */
  turn_active?: boolean;
  /** Pending tool approval for this thread (survives page reload). */
  hitl_pending?: HitlPendingPayload | null;
  /** Legacy path list (compat). Prefer ``artifact_refs`` when present. */
  artifacts?: Array<string | ThreadArtifact>;
  /** Structured refs with producer ``agent_id``. */
  artifact_refs?: ThreadArtifact[];
}

export interface OctopThreadPatch {
  title?: string;
  pinned?: boolean;
  model_ref?: string | null;
  reasoning_mode?: "auto" | "enabled" | "disabled" | null;
  reasoning_effort?: string | null;
  conversation_mode?: "ask" | "plan" | "craft" | null;
  hitl_policy?: HitlSessionPolicy | null;
}

export type ContextUsageSegmentKey =
  | "system_prompt"
  | "tool_definitions"
  | "rules"
  | "skills"
  | "mcp"
  | "subagent_definitions"
  | "conversation";

export interface ContextUsageSegment {
  key: ContextUsageSegmentKey;
  tokens: number;
}

export interface ContextUsageBreakdown {
  max_tokens: number;
  used_tokens: number;
  segments: ContextUsageSegment[];
}

export interface HistoryMigrationStatus {
  remaining: number;
  pending: number;
  queued: number;
  running: number;
  failed: number;
  processing: boolean;
  agent_busy: boolean;
  can_start: boolean;
  accepted?: number;
}

export const CHAT_HISTORY_PAGE_SIZE = 25;

export const octopThreadsApi = {
  list: (agentId: string, limit = 50) =>
    request<OctopThread[]>(
      `/agents/${encodeURIComponent(agentId)}/threads?limit=${limit}`,
    ),

  create: (agentId: string) =>
    request<{ thread_id: string; session_key: string }>(
      `/agents/${encodeURIComponent(agentId)}/threads`,
      { method: "POST" },
    ),

  historyMigrationStatus: (agentId: string) =>
    request<HistoryMigrationStatus>(
      `/agents/${encodeURIComponent(agentId)}/history-migration/status`,
    ),

  startHistoryMigration: (agentId: string) =>
    request<HistoryMigrationStatus>(
      `/agents/${encodeURIComponent(agentId)}/history-migration/start`,
      { method: "POST" },
    ),

  history: (
    agentId: string,
    threadId: string,
    params: { limit?: number; offset?: number; cursor?: string | null } = {},
  ) => {
    const limit = params.limit ?? CHAT_HISTORY_PAGE_SIZE;
    const offset = params.offset ?? 0;
    return request<OctopThreadHistory>(
      `/agents/${encodeURIComponent(agentId)}/threads/${encodeURIComponent(
        threadId,
      )}/history?limit=${limit}&offset=${offset}${
        params.cursor ? `&cursor=${encodeURIComponent(params.cursor)}` : ""
      }`,
    );
  },

  contextUsage: (
    agentId: string,
    threadId: string,
    params: {
      maxTokens?: number;
      inputTokens?: number;
      mcpServers?: string[];
      skills?: string[];
    } = {},
  ) => {
    const search = new URLSearchParams();
    if (params.maxTokens != null) {
      search.set("max_tokens", String(params.maxTokens));
    }
    if (params.inputTokens != null && params.inputTokens > 0) {
      search.set("input_tokens", String(params.inputTokens));
    }
    if (params.mcpServers != null && params.mcpServers.length > 0) {
      search.set("mcp_servers", params.mcpServers.join(","));
    }
    if (params.skills != null && params.skills.length > 0) {
      search.set("skills", params.skills.join(","));
    }
    const qs = search.toString();
    return request<ContextUsageBreakdown>(
      `/agents/${encodeURIComponent(agentId)}/threads/${encodeURIComponent(
        threadId,
      )}/context-usage${qs ? `?${qs}` : ""}`,
    );
  },

  rename: (agentId: string, threadId: string, title: string) =>
    octopThreadsApi.patch(agentId, threadId, { title }),

  patch: (agentId: string, threadId: string, body: OctopThreadPatch) =>
    request<{
      thread_id: string;
      title: string | null;
      pinned?: boolean;
      model_ref?: string | null;
      reasoning_mode?: "auto" | "enabled" | "disabled" | null;
      reasoning_effort?: string | null;
      conversation_mode?: "ask" | "plan" | "craft" | null;
      pending_plan_path?: string | null;
      hitl_policy?: HitlSessionPolicy | null;
    }>(
      `/agents/${encodeURIComponent(agentId)}/threads/${encodeURIComponent(
        threadId,
      )}`,
      { method: "PATCH", body: JSON.stringify(body) },
    ),

  delete: (agentId: string, threadId: string) =>
    request<void>(
      `/agents/${encodeURIComponent(agentId)}/threads/${encodeURIComponent(
        threadId,
      )}`,
      { method: "DELETE" },
    ),

  fork: (
    agentId: string,
    threadId: string,
    body: {
      message_id?: string;
      content?: string;
      assistant_turns_from_end?: number;
    },
  ) =>
    request<{
      thread_id: string;
      session_key: string;
      source_thread_id: string;
      copied_messages: number;
      title: string | null;
      last_active: number;
      created_at: number;
    }>(
      `/agents/${encodeURIComponent(agentId)}/threads/${encodeURIComponent(
        threadId,
      )}/fork`,
      { method: "POST", body: JSON.stringify(body) },
    ),

  markRead: (agentId: string, threadId: string) =>
    request<void>(
      `/agents/${encodeURIComponent(agentId)}/threads/${encodeURIComponent(
        threadId,
      )}/read`,
      { method: "POST" },
    ),

  rebind: (agentId: string, threadId: string) =>
    request<{ session_key: string; thread_id: string }>(
      `/agents/${encodeURIComponent(agentId)}/session`,
      { method: "PATCH", body: JSON.stringify({ thread_id: threadId }) },
    ),
};
