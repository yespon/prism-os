import { request, requestUpload } from "../request";

export interface PluginConfigField {
  name: string;
  label?: string;
  type?: string;
  required?: boolean;
  placeholder?: string;
  help?: string;
}

export interface InstalledPlugin {
  id: string;
  version?: string;
  name?: string;
  kind?: string;
  description?: string;
  /** Emoji, absolute image URL, or plugin-relative path resolved to ``/api/plugins/.../ui/...``. */
  icon?: string | null;
  /** Catalog group slug from plugin.yaml (e.g. lifestyle, games). */
  group?: string | null;
  requires?: string[];
  path?: string;
  loaded?: boolean;
  /** Global enable switch from config.json (default true). */
  enabled?: boolean;
  error?: string;
  ui?: { entry: string; manifest: string } | null;
  tools?: {
    name: string;
    description?: string;
    config_fields?: PluginConfigField[];
  }[];
}

export interface AgentPluginTool {
  plugin_id: string;
  name: string;
  description?: string;
  config_fields: PluginConfigField[];
  enabled: boolean;
  config: Record<string, unknown>;
}

export type AgentPluginsConfig = Record<
  string,
  {
    enabled?: boolean;
    tools?: Record<
      string,
      {
        enabled?: boolean;
        config?: Record<string, unknown>;
      }
    >;
  }
>;

export interface AgentPlugin {
  id: string;
  version?: string | null;
  name?: string | null;
  kind?: string | null;
  description?: string | null;
  icon?: string | null;
  group?: string | null;
  loaded: boolean;
  global_enabled: boolean;
  agent_enabled: boolean;
  /** Effective state: global and Agent switches must both be enabled. */
  enabled: boolean;
  tools: InstalledPlugin["tools"];
}

export interface MarketPlugin {
  id: string;
  version?: string;
  name?: string;
  kind?: string;
  description?: string;
  icon?: string | null;
  group?: string | null;
  requires?: string[];
  installed?: boolean;
  installed_version?: string | null;
  update_available?: boolean;
  error?: string;
}

export const pluginsApi = {
  list(): Promise<InstalledPlugin[]> {
    return request<InstalledPlugin[]>("/plugins");
  },

  listMarket(): Promise<MarketPlugin[]> {
    return request<MarketPlugin[]>("/plugins/market");
  },

  installFromMarket(
    pluginId: string,
    force = false,
  ): Promise<{ id: string; version: string; name: string; kind: string }> {
    const qs = force ? "?force=true" : "";
    return request(
      `/plugins/market/${encodeURIComponent(pluginId)}/install${qs}`,
      {
        method: "POST",
      },
    );
  },

  install(
    url: string,
  ): Promise<{ id: string; version: string; name: string; kind: string }> {
    return request("/plugins/install", {
      method: "POST",
      body: JSON.stringify({ url }),
    });
  },

  upload(
    file: File,
    force: boolean,
  ): Promise<{ id: string; version: string; name: string; kind: string }> {
    const formData = new FormData();
    formData.append("file", file);
    if (force) formData.append("force", "true");
    return requestUpload("/plugins/upload", formData);
  },

  uninstall(pluginId: string): Promise<{ status: string; id: string }> {
    return request(`/plugins/${encodeURIComponent(pluginId)}`, {
      method: "DELETE",
    });
  },

  setEnabled(pluginId: string, enabled: boolean): Promise<InstalledPlugin> {
    return request(`/plugins/${encodeURIComponent(pluginId)}`, {
      method: "PATCH",
      body: JSON.stringify({ enabled }),
    });
  },

  reload(): Promise<{
    status: string;
    loaded: { id: string; version: string; kind: string }[];
  }> {
    return request("/plugins/reload", { method: "POST" });
  },

  listAgentTools(agentId: string): Promise<{ tools: AgentPluginTool[] }> {
    return request(`/plugins/agents/${encodeURIComponent(agentId)}/tools`);
  },

  patchAgentTools(
    agentId: string,
    plugins: AgentPluginsConfig,
  ): Promise<{ status: string }> {
    return request(`/plugins/agents/${encodeURIComponent(agentId)}/tools`, {
      method: "PATCH",
      body: JSON.stringify({ plugins }),
    });
  },

  listAgentPlugins(agentId: string): Promise<{ plugins: AgentPlugin[] }> {
    return request(`/plugins/agents/${encodeURIComponent(agentId)}`);
  },

  patchAgentPlugins(
    agentId: string,
    plugins: Record<string, { enabled: boolean }>,
  ): Promise<{ plugins: AgentPlugin[] }> {
    return request(`/plugins/agents/${encodeURIComponent(agentId)}`, {
      method: "PATCH",
      body: JSON.stringify({ plugins }),
    });
  },
};
