import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useTranslation } from "react-i18next";
import { Collapse, Drawer, Spin, Tag } from "antd";
import { ChevronLeft } from "lucide-react";
import { request } from "../api/request";
import { withFromWorkspace } from "../utils/fromWorkspace";
import type { OctopAgent } from "../context/AgentContext";
import { useAgent } from "../context/AgentContext";
import { isAgentChatReady } from "../utils/agentError";
import { isTeamAgent } from "../utils/teamAgent";
import {
  listAgentSubagents,
  type AgentSubagentSummary,
} from "../api/modules/subagents";
import { teamsApi, type TeamMemberSummary } from "../api/modules/teams";
import MbtiPersonaTag from "./MbtiPersonaTag";
import { CopyableResourceId } from "./CopyableResourceId";
import {
  ExpertIcon,
  metaForFile,
} from "../pages/Experts/components/iconForName";
import { fetchConfigMdFiles } from "../pages/Experts/components/expertFileGroups";
import { useSkillDisplayName } from "../pages/Agent/Skills/skillDisplayNames";
import { DEFAULT_SKILL_EMOJI } from "../pages/Agent/Skills/skillMarkdown";
import SubagentCatalogDrawer from "../pages/Experts/components/SubagentCatalogDrawer";
import SkillCatalogDrawer from "../pages/Experts/components/SkillCatalogDrawer";
import WorkspaceDrawer from "../pages/Agent/Workspace/components/WorkspaceDrawer";
import {
  resolveSubagentAccent,
  subagentAccentIconStyle,
} from "../utils/expertColor";
import expertStyles from "../pages/Experts/index.module.less";
import styles from "./AgentProfileDrawer.module.less";

interface AgentDetail {
  name: string;
  description: string | null;
}

interface SkillSummary {
  slug?: string;
  name: string;
  description?: string;
  enabled?: boolean;
  kind?: "builtin" | "workspace";
  emoji?: string;
  icon_url?: string;
}

function workspaceSkills(skills: SkillSummary[]): SkillSummary[] {
  return skills.filter((s) => s.kind !== "builtin");
}

const SKILL_ICON_ACCENT = "#8B5CF6";

function skillIconStyle(hasImage: boolean): {
  color: string;
  background: string;
} {
  return {
    color: SKILL_ICON_ACCENT,
    background: hasImage ? "transparent" : `${SKILL_ICON_ACCENT}1a`,
  };
}

function ProfileEntityCard({
  icon,
  title,
  trailing,
  description,
}: {
  icon: ReactNode;
  title: ReactNode;
  trailing: ReactNode;
  description?: ReactNode;
}) {
  return (
    <div className={expertStyles.fileItem}>
      <div className={styles.entityCard}>
        <div className={styles.entityCardHeader}>
          {icon}
          <div
            className={`${expertStyles.fileLabel} ${styles.entityCardTitle}`}
          >
            {title}
          </div>
          {trailing}
        </div>
        {description ? (
          <div className={expertStyles.filePath}>{description}</div>
        ) : null}
      </div>
    </div>
  );
}

interface AgentProfileDrawerProps {
  open: boolean;
  agent: OctopAgent | null;
  isMobile?: boolean;
  onClose: () => void;
}

export default function AgentProfileDrawer({
  open,
  agent,
  isMobile = false,
  onClose,
}: AgentProfileDrawerProps) {
  const { t } = useTranslation();
  const { agents } = useAgent();
  const skillDisplayName = useSkillDisplayName();
  const [loading, setLoading] = useState(false);
  const [filesLoading, setFilesLoading] = useState(false);
  const [detail, setDetail] = useState<AgentDetail | null>(null);
  const [workspaceFiles, setWorkspaceFiles] = useState<string[]>([]);
  const [agentSkills, setAgentSkills] = useState<SkillSummary[]>([]);
  const [subagents, setSubagents] = useState<AgentSubagentSummary[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMemberSummary[]>([]);
  const [viewingFile, setViewingFile] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState("");
  const [fileLoading, setFileLoading] = useState(false);
  const [skillCatalogOpen, setSkillCatalogOpen] = useState(false);
  const [subagentCatalogOpen, setSubagentCatalogOpen] = useState(false);
  const [workspaceDrawerOpen, setWorkspaceDrawerOpen] = useState(false);

  const installedSlugs = useMemo(
    () => new Set(subagents.map((s) => s.slug)),
    [subagents],
  );
  const visibleTeamMembers = useMemo(
    () =>
      teamMembers.map((member) => {
        const found = agents.find((item) => item.agent_id === member.agent_id);
        if (!found) return member;
        return {
          ...member,
          name: found.name || member.name,
          color: found.color ?? member.color,
          icon_name: found.icon_name ?? member.icon_name,
          icon_url: found.icon_url ?? member.icon_url,
          state: found.state || member.state,
        };
      }),
    [teamMembers, agents],
  );

  const reloadSubagents = useCallback(async () => {
    if (!agent) return;
    try {
      const rows = await listAgentSubagents(agent.agent_id);
      setSubagents(rows);
    } catch {
      /* non-critical */
    }
  }, [agent]);

  useEffect(() => {
    if (!open || !agent) return;
    let cancelled = false;
    setLoading(true);
    setDetail(null);
    setWorkspaceFiles([]);
    setAgentSkills([]);
    setSubagents([]);
    setTeamMembers([]);
    setViewingFile(null);
    setFileContent("");

    const load = async () => {
      try {
        if (isTeamAgent(agent)) {
          try {
            const team = await teamsApi.get(agent.agent_id);
            if (cancelled) return;
            setDetail({
              name: team.name,
              description: team.description ?? null,
            });
            setTeamMembers(team.members);
          } catch {
            if (cancelled) return;
            setDetail({
              name: agent.name,
              description: agent.description ?? null,
            });
            setTeamMembers(
              (agent.member_ids ?? []).map((id) => ({
                agent_id: id,
                name: id,
              })),
            );
          }
        } else {
          const ag = await request<AgentDetail>(`/agents/${agent.agent_id}`);
          if (cancelled) return;
          setDetail(ag);
        }
        if (cancelled) return;
        setLoading(false);

        if (isAgentChatReady(agent.state)) {
          setFilesLoading(true);
          void fetchConfigMdFiles(agent.agent_id)
            .then((files) => {
              if (!cancelled) setWorkspaceFiles(files);
            })
            .catch(() => {
              if (!cancelled) setWorkspaceFiles([]);
            })
            .finally(() => {
              if (!cancelled) setFilesLoading(false);
            });

          if (!isTeamAgent(agent)) {
            void request<SkillSummary[]>(`/agents/${agent.agent_id}/skills`)
              .then((skills) => {
                if (!cancelled) setAgentSkills(workspaceSkills(skills));
              })
              .catch(() => {
                if (!cancelled) setAgentSkills([]);
              });

            void listAgentSubagents(agent.agent_id)
              .then((rows) => {
                if (!cancelled) setSubagents(rows);
              })
              .catch(() => {
                if (!cancelled) setSubagents([]);
              });
          }
        }
      } catch {
        if (!cancelled) setLoading(false);
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [open, agent]);

  useEffect(() => {
    if (!open) {
      setViewingFile(null);
      setFileContent("");
      setSkillCatalogOpen(false);
      setSubagentCatalogOpen(false);
      setWorkspaceDrawerOpen(false);
    }
  }, [open]);

  const openFileView = async (filePath: string) => {
    if (!agent) return;
    const path = filePath.startsWith("/") ? filePath : `/${filePath}`;
    setViewingFile(path);
    setFileLoading(true);
    setFileContent("");
    try {
      const r = await request<{ content: string }>(
        withFromWorkspace(
          `/agents/${agent.agent_id}/workspace/file?path=${encodeURIComponent(
            path,
          )}`,
        ),
      );
      setFileContent(r.content ?? "");
    } catch {
      setFileContent("");
    } finally {
      setFileLoading(false);
    }
  };

  const closeFileView = () => {
    setViewingFile(null);
    setFileContent("");
  };

  const handleDrawerClose = () => {
    if (isMobile && viewingFile) {
      closeFileView();
      return;
    }
    onClose();
  };

  const displayName = (path: string) => path.replace(/^\//, "");

  const mobileDrawerStyles = {
    body: {
      padding: "12px 16px calc(16px + env(safe-area-inset-bottom))",
    },
  };

  const renderFileContent = () =>
    fileLoading ? (
      <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
        <Spin />
      </div>
    ) : (
      <pre className={styles.fileContent}>
        {fileContent || t("workspace.emptyFile")}
      </pre>
    );

  const renderProfileContent = () => {
    if (loading) {
      return (
        <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
          <Spin />
        </div>
      );
    }

    if (!agent) {
      return null;
    }

    const isTeam = isTeamAgent(agent);

    return (
      <>
        <div className={expertStyles.drawerSection}>
          <div className={expertStyles.drawerSectionTitle}>
            {t("experts.basicInfo")}
          </div>
          <div className={styles.nameRow}>
            <div className={styles.name}>{detail?.name ?? agent.name}</div>
            <CopyableResourceId
              label={isTeam ? t("experts.teamId") : t("experts.agentId")}
              value={agent.agent_id}
              copyTitle={
                isTeam ? t("experts.copyTeamId") : t("experts.copyAgentId")
              }
              className={styles.agentId}
            />
          </div>
          <p
            style={{
              margin: 0,
              fontSize: 13,
              lineHeight: 1.6,
              color: "var(--fn-text-secondary)",
              wordBreak: "break-word",
            }}
          >
            {detail?.description ||
              agent.description ||
              t("chat.agentNoDescription")}
          </p>
          {isTeam ? (
            <p
              style={{
                margin: "10px 0 0",
                fontSize: 12,
                lineHeight: 1.5,
                color: "var(--fn-text-tertiary)",
              }}
            >
              {t("chat.teamProfile.hostNote")}
            </p>
          ) : (
            <div
              style={{
                marginTop: 10,
                display: "flex",
                alignItems: "center",
                gap: 8,
                flexWrap: "wrap",
              }}
            >
              <span style={{ fontSize: 12, color: "var(--fn-text-tertiary)" }}>
                {t("experts.table.persona")}
              </span>
              <MbtiPersonaTag value={agent.persona_mbti} />
            </div>
          )}
        </div>

        {isTeam ? (
          <div className={expertStyles.drawerSection}>
            <div className={expertStyles.drawerSectionTitle}>
              {t("chat.teamProfile.members")}
              {visibleTeamMembers.length > 0
                ? ` · ${t("chat.teamProfile.memberCount", {
                    count: visibleTeamMembers.length,
                  })}`
                : ""}
            </div>
            <div className={expertStyles.fileList}>
              {visibleTeamMembers.length === 0 ? (
                <div
                  style={{
                    fontSize: 13,
                    color: "var(--fn-text-tertiary)",
                    padding: "8px 0",
                  }}
                >
                  {t("chat.teamProfile.emptyMembers")}
                </div>
              ) : (
                visibleTeamMembers.map((member) => {
                  const accent = member.color || "#0d9488";
                  const stateKey = member.state || "unknown";
                  return (
                    <ProfileEntityCard
                      key={member.agent_id}
                      icon={
                        <div
                          className={expertStyles.fileIcon}
                          style={{
                            color: accent,
                            background: `${accent}1a`,
                          }}
                        >
                          <ExpertIcon
                            iconUrl={member.icon_url}
                            iconName={member.icon_name}
                            size={16}
                          />
                        </div>
                      }
                      title={member.name}
                      trailing={
                        <span className={expertStyles.fileHint}>
                          {t(`common.agentState.${stateKey}`, {
                            defaultValue: stateKey,
                          })}
                        </span>
                      }
                    />
                  );
                })
              )}
            </div>
          </div>
        ) : null}

        <div className={expertStyles.drawerSection}>
          <Collapse
            ghost
            className={expertStyles.drawerCollapse}
            defaultActiveKey={["config"]}
            items={[
              {
                key: "config",
                label: (
                  <div className={styles.sectionTitleRow}>
                    <div className={expertStyles.drawerSectionTitle}>
                      {t("experts.configFiles", {
                        count: workspaceFiles.length,
                      })}
                    </div>
                    <button
                      type="button"
                      className={styles.viewMoreLink}
                      disabled={!isAgentChatReady(agent.state)}
                      title={
                        isAgentChatReady(agent.state)
                          ? undefined
                          : t("workspace.requiresRunning")
                      }
                      onClick={(event) => {
                        event.stopPropagation();
                        if (!isAgentChatReady(agent.state)) return;
                        setWorkspaceDrawerOpen(true);
                      }}
                    >
                      {t("common.viewMore")}
                    </button>
                  </div>
                ),
                children: (
                  <div className={expertStyles.fileList}>
                    {filesLoading ? (
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          padding: "16px 0",
                        }}
                      >
                        <Spin size="small" />
                      </div>
                    ) : workspaceFiles.length === 0 ? (
                      <div
                        style={{
                          fontSize: 13,
                          color: "var(--fn-text-tertiary)",
                          padding: "8px 0",
                        }}
                      >
                        {t("experts.noWorkspaceFiles")}
                      </div>
                    ) : (
                      workspaceFiles.map((file) => {
                        const basename = displayName(file);
                        const meta = metaForFile(basename, t);
                        return (
                          <div key={file} className={expertStyles.fileItem}>
                            <button
                              type="button"
                              className={expertStyles.fileItemMain}
                              onClick={() => void openFileView(file)}
                            >
                              <div
                                className={expertStyles.fileIcon}
                                style={{
                                  color: meta.color,
                                  background: `${meta.color}1a`,
                                }}
                              >
                                {meta.icon}
                              </div>
                              <div className={expertStyles.fileMeta}>
                                <div className={expertStyles.fileLabel}>
                                  {meta.label}
                                </div>
                                <div className={expertStyles.filePath}>
                                  {basename}
                                </div>
                              </div>
                              <span className={expertStyles.fileHint}>
                                {t("common.view")}
                              </span>
                            </button>
                          </div>
                        );
                      })
                    )}
                  </div>
                ),
              },
            ]}
          />
        </div>

        {!isTeam ? (
          <>
            <div className={expertStyles.drawerSection}>
              <Collapse
                ghost
                className={expertStyles.drawerCollapse}
                defaultActiveKey={["skills"]}
                items={[
                  {
                    key: "skills",
                    label: (
                      <div className={styles.sectionTitleRow}>
                        <div className={expertStyles.drawerSectionTitle}>
                          {t("experts.skillFilesTitle", {
                            count: agentSkills.length,
                          })}
                        </div>
                        <button
                          type="button"
                          className={styles.viewMoreLink}
                          onClick={(event) => {
                            event.stopPropagation();
                            setSkillCatalogOpen(true);
                          }}
                        >
                          {t("common.viewMore")}
                        </button>
                      </div>
                    ),
                    children: (
                      <>
                        <p
                          style={{
                            fontSize: 12,
                            color: "var(--fn-text-tertiary)",
                            margin: "0 0 8px",
                          }}
                        >
                          {t("experts.skillFilesHint")}
                        </p>
                        <div className={expertStyles.fileList}>
                          {agentSkills.length === 0 ? (
                            <div
                              style={{
                                fontSize: 13,
                                color: "var(--fn-text-tertiary)",
                                padding: "8px 0",
                              }}
                            >
                              {t("experts.noSkillFiles")}
                            </div>
                          ) : (
                            agentSkills.map((skill) => {
                              const iconUrl = skill.icon_url?.trim();
                              const label = skillDisplayName(skill);
                              return (
                                <ProfileEntityCard
                                  key={skill.slug ?? skill.name}
                                  icon={
                                    <div
                                      className={expertStyles.fileIcon}
                                      style={skillIconStyle(Boolean(iconUrl))}
                                    >
                                      {iconUrl ? (
                                        <img
                                          src={iconUrl}
                                          alt={label}
                                          className={expertStyles.fileIconImg}
                                        />
                                      ) : (
                                        skill.emoji?.trim() ||
                                        DEFAULT_SKILL_EMOJI
                                      )}
                                    </div>
                                  }
                                  title={label}
                                  trailing={
                                    <span className={expertStyles.fileHint}>
                                      {skill.enabled === false
                                        ? t("common.disabled")
                                        : t("common.enabled")}
                                    </span>
                                  }
                                  description={skill.description}
                                />
                              );
                            })
                          )}
                        </div>
                      </>
                    ),
                  },
                ]}
              />
            </div>

            <div className={expertStyles.drawerSection}>
              <Collapse
                ghost
                className={expertStyles.drawerCollapse}
                defaultActiveKey={["subagents"]}
                items={[
                  {
                    key: "subagents",
                    label: (
                      <div className={styles.sectionTitleRow}>
                        <div className={expertStyles.drawerSectionTitle}>
                          {t("experts.subagentFilesTitle", {
                            count: subagents.length,
                          })}
                        </div>
                        <button
                          type="button"
                          className={styles.viewMoreLink}
                          onClick={(event) => {
                            event.stopPropagation();
                            setSubagentCatalogOpen(true);
                          }}
                        >
                          {t("common.viewMore")}
                        </button>
                      </div>
                    ),
                    children: (
                      <>
                        <p
                          style={{
                            fontSize: 12,
                            color: "var(--fn-text-tertiary)",
                            margin: "0 0 8px",
                          }}
                        >
                          {t("experts.subagentFilesHint")}
                        </p>
                        <div className={expertStyles.fileList}>
                          {subagents.length === 0 ? (
                            <div
                              style={{
                                fontSize: 13,
                                color: "var(--fn-text-tertiary)",
                                padding: "8px 0",
                              }}
                            >
                              {t("experts.noSubagentFiles")}
                            </div>
                          ) : (
                            subagents.map((sub) => (
                              <ProfileEntityCard
                                key={sub.slug}
                                icon={
                                  <div
                                    className={expertStyles.fileIcon}
                                    style={subagentAccentIconStyle(
                                      resolveSubagentAccent(sub.color),
                                    )}
                                  >
                                    {sub.emoji ?? "🤖"}
                                  </div>
                                }
                                title={sub.name}
                                trailing={
                                  <Tag
                                    color="blue"
                                    style={{
                                      margin: 0,
                                      fontSize: 11,
                                      lineHeight: "18px",
                                    }}
                                  >
                                    {sub.slug}
                                  </Tag>
                                }
                                description={sub.description}
                              />
                            ))
                          )}
                        </div>
                      </>
                    ),
                  },
                ]}
              />
            </div>
          </>
        ) : null}
      </>
    );
  };

  const profileTitle = isTeamAgent(agent)
    ? t("chat.agentProfile.titleTeam")
    : t("chat.agentProfile.title");

  const mobileTitle =
    viewingFile !== null ? (
      <button
        type="button"
        className={styles.drawerTitleBack}
        onClick={closeFileView}
      >
        <ChevronLeft size={18} strokeWidth={2} />
        <span>{displayName(viewingFile)}</span>
      </button>
    ) : (
      profileTitle
    );

  if (isMobile) {
    return (
      <>
        <Drawer
          open={open}
          title={mobileTitle}
          width="100%"
          placement="bottom"
          height="82vh"
          rootClassName={styles.mobileDrawer}
          styles={mobileDrawerStyles}
          onClose={handleDrawerClose}
          destroyOnHidden
        >
          {viewingFile ? renderFileContent() : renderProfileContent()}
        </Drawer>

        {!isTeamAgent(agent) ? (
          <>
            <SkillCatalogDrawer
              agentId={agent?.agent_id ?? ""}
              open={skillCatalogOpen}
              onClose={() => setSkillCatalogOpen(false)}
            />
            <SubagentCatalogDrawer
              agentId={agent?.agent_id ?? ""}
              agentState={agent?.state ?? "stopped"}
              open={subagentCatalogOpen}
              installedSlugs={installedSlugs}
              onClose={() => setSubagentCatalogOpen(false)}
              onInstalled={() => void reloadSubagents()}
            />
          </>
        ) : null}
        <WorkspaceDrawer
          agentId={agent?.agent_id ?? ""}
          open={workspaceDrawerOpen}
          onClose={() => setWorkspaceDrawerOpen(false)}
        />
      </>
    );
  }

  return (
    <>
      <Drawer
        open={open}
        title={profileTitle}
        width={420}
        onClose={onClose}
        destroyOnHidden
      >
        {renderProfileContent()}
      </Drawer>

      <Drawer
        open={viewingFile !== null}
        title={viewingFile ? displayName(viewingFile) : ""}
        width={480}
        onClose={closeFileView}
        destroyOnHidden
      >
        {renderFileContent()}
      </Drawer>

      {!isTeamAgent(agent) ? (
        <>
          <SkillCatalogDrawer
            agentId={agent?.agent_id ?? ""}
            open={skillCatalogOpen}
            onClose={() => setSkillCatalogOpen(false)}
          />
          <SubagentCatalogDrawer
            agentId={agent?.agent_id ?? ""}
            agentState={agent?.state ?? "stopped"}
            open={subagentCatalogOpen}
            installedSlugs={installedSlugs}
            onClose={() => setSubagentCatalogOpen(false)}
            onInstalled={() => void reloadSubagents()}
          />
        </>
      ) : null}
      <WorkspaceDrawer
        agentId={agent?.agent_id ?? ""}
        open={workspaceDrawerOpen}
        onClose={() => setWorkspaceDrawerOpen(false)}
      />
    </>
  );
}
